import java.util.*;

public class Organization extends Asset implements Comparable{
	protected String m_formalName;
	protected String m_shortName;
	protected String m_adjective;
	protected List m_orders;
	protected List m_actions;
	protected final int SHORTNAMEMAXLENGTH = 30;
	
	protected List m_assets;
	
	public Organization(){
		m_formalName = new String();
		m_adjective = new String();
		m_shortName = new String();
		m_assets = new LinkedList();
		m_deJureOwners = new HashMap();
		m_orders = new LinkedList();
	}
	public Organization(Organization parent, String formal, String adj, String shortName){	
		m_formalName = formal;
		m_adjective = adj;
		m_shortName = shortName;
		m_assets = new LinkedList();
		m_deFactoOwner = parent;
		m_deJureOwners = new HashMap();
		m_orders = new LinkedList();
	}
	public String getFormalName(){return m_formalName;}
	public String getShortName(){return m_shortName;}
	public String getAdjective(){return m_adjective;}
	public List getAssets(){return m_assets;}

	public List getOrders(){return m_orders;}
	public List getActions(){return m_actions;}

	public boolean addOrder(Order order){
		if(m_actions.contains(order.getAction())){
			m_orders.add(order);
			return true;
		}
		return false;
	}
	public void removeOrder(Order order){
		if(m_orders.contains(order)){
			m_orders.remove(order);
		}
	}
	public boolean addAction(Action action){m_actions.add(action);return true;}
	public boolean addAsset(Asset asset){m_assets.add(asset); return true;}
	public boolean setFormalName(String formalName){m_formalName = formalName;return true;}
	public boolean setAdjective(String adj){m_adjective = adj; return true;}
	public boolean setShortName(String name){
		if(name.length() > SHORTNAMEMAXLENGTH && m_formalName == null){
			return false;
		}
		m_shortName = name;
		return true;
	}
	public boolean equals(Object org){
		return (m_formalName == ((Organization)org).getFormalName());
	}
	public int compareTo(Object org){
		return m_formalName.compareTo(((Organization)org).getFormalName());
	}
	
	public void iterate(){
	}
	public String toString(){
		String string = new String();

		string += "Organization: " + m_formalName + "\n";
		string += "Short: " + m_shortName + "\n";
		string += "Adjective: " + m_adjective + "\n";
		string += "\n" + RiffToolbox.printUnderline("Actions:", "-");
		for(int i = 0;i<m_actions.size();i++){
			string += ((Action)m_actions.get(i)) + "\n";
		}
		string += "\n" + RiffToolbox.printUnderline("Orders:", "-");
		for(int i = 0;i<m_orders.size();i++){
			string += ((Order)m_orders.get(i)) + "\n";
		}
		
		string += "\n" + RiffToolbox.printUnderline("Assets:", "-");
		for(int i = 0;i<m_assets.size();i++){
			string += ((Asset)m_assets.get(i)) + "\n";
		}
		return string;
	}
}
