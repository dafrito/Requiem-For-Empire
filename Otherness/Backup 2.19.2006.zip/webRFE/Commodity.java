import java.util.*;

public class Commodity{
	private Map m_prerequisites;
	private String m_name;
	public Commodity(){
		m_prerequisites = new HashMap();
	}
	public Commodity(String name){
		m_name = name;
		m_prerequisites = new HashMap();
	}
	public String getName(){return m_name;}
	public Map getPrerequisites(){return m_prerequisites;}
	public boolean addPrerequisite(Commodity prereq, Integer quantity){
		m_prerequisites.put(prereq, quantity);
		return true;
	}
}
