public class IdentityLoyalty{
	private Identity m_identity;
	private float m_loyalty;
	private IdentityLoyalty(){}
	public IdentityLoyalty(Identity identity, float loyalty){
		m_identity = identity;
		m_loyalty = loyalty;
	}
	public Identity getIdentity(){return m_identity;}
	public float getLoyalty(){return m_loyalty;}
	public boolean setLoyalty(float loyalty){m_loyalty = loyalty;return true;}
}
