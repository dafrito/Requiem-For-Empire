import java.util.*;

public class Relationship{
	protected List m_signers;
	protected List m_stipulations;
	public Relationship(){
		m_signers = new LinkedList();
		m_stipulations = new LinkedList();
	}
	public List getSigners(){return m_signers;}
	public List getStipulations(){return m_stipulations;}
	public boolean addSigner(Organization signer){m_signers.add(signer);return true;}
	public boolean addStipulation(Stipulation stip){m_stipulations.add(stip);return true;}
	public boolean isOrganizationSigned(Organization testOrganization){
		if(m_signers.indexOf(testOrganization) == -1){
			return false;
		}
		return true;
	}
	public boolean isStipulationPresent(Stipulation testStipulation){
		if(m_stipulations.indexOf(testStipulation) == -1){
			return false;
		}
		return true;
	}
	public Organization getFirstSigner(){return (Organization)m_signers.firstElement();}
}
