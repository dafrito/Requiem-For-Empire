import java.util.*;

public class Structure extends Organization{
	
	private Personality m_manager;
	protected List m_inventory;
	public Structure(){
		m_orders = new LinkedList();
		m_actions = new LinkedList();
		m_inventory = new LinkedList();
		m_formalName = new String();
		m_adjective = new String();
		m_shortName = new String();
	}
	public Structure(Organization owner, String formal, String adj, String shortName){	
		m_orders = new LinkedList();
		m_actions = new LinkedList();
		m_inventory = new LinkedList();
		m_deFactoOwner = owner;
		m_formalName = formal;
		m_adjective = adj;
		m_shortName = shortName;
	}	
	public List getInventory(){return m_inventory;}
	public boolean addInventory(Lot lot){m_inventory.add(lot); return true;}
	public boolean assertInventoryLevel(Brand brand, int quantity){
		int level = 0;
		for(int i=0;i<m_inventory.size();i++){
			Lot lot = (Lot)m_inventory.get(i);
			if(brand == lot.getBrand()){
				level += lot.getQuantity();
				if(level > quantity){return true;}
			}
		}
		return false;
	}
	public boolean expendInventoryLevel(Brand brand, int quantity){
		int level = quantity;
		for(int i=0;i<m_inventory.size();i++){
			Lot lot = (Lot)m_inventory.get(i);
			if(brand == lot.getBrand()){
				if(lot.getQuantity() > level){
					lot.setQuantity(lot.getQuantity() - level);
					return true;
				}
				level -= lot.getQuantity();
				lot.setQuantity(0);
			}
		}
		return false;
	}
	public Personality getManager(){return m_manager;}
	public boolean setManager(Personality manager){m_manager = manager;return true;}
	public void iterate(){
		for(int i=0;i<m_orders.size();i++){
			((Order)m_orders.get(i)).execute(this);
		}
	}
	public String toString(){
		String string = new String();
		string += "Manager: " + m_manager + "\n";
		string += "Inventory:\n";
		for(int i =0;i<m_inventory.size();i++){
			string += ((Lot)m_inventory.get(i)).toString();
		}
		return super.toString() + string;
	}
}
