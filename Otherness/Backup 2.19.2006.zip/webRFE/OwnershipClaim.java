public class OwnershipClaim extends Stipulation{
	protected Location m_ownershipClaim;
	public static final String m_stipulationType = "Ownership Claim";
	public Location getClaimedLocation(){return m_ownershipClaim;}
	public Organization getClaimer(){return m_relationship.getFirstSigner();}
	public String getStipulationType(){return m_stipulationType;}
	public String toString(){
		String string = new String();
		if(m_relationship.getFirstSigner() == null && m_ownershipClaim == null){return "No signers and/or no claimed locations";}
		string += m_relationship.getFirstSigner().getFormalName();
		string += " claims the " + m_ownershipClaim.getFormalName() + ".";
		return string;
	}
	public boolean equals(Object stip){
		if(m_stipulationType != ((Stipulation)stip).getStipulationType()){
			return false;
		}
		if(getClaimer() != ((OwnershipClaim)stip).getClaimer()){
			return false;
		}
		if(getClaimedLocation() != ((OwnershipClaim)stip).getClaimedLocation()){
			return false;
		}
		return true;
	}
	public int compareTo(Object stip){
		if(m_stipulationType.compareTo(((Stipulation)stip).getStipulationType()) != 0){
			return m_stipulationType.compareTo(((Stipulation)stip).getStipulationType());
		}
		if(getClaimer().compareTo(((OwnershipClaim)stip).getClaimer()) != 0){
			return getClaimer().compareTo(((OwnershipClaim)stip).getClaimer());
		}
		if(getClaimedLocation().compareTo(((OwnershipClaim)stip).getClaimedLocation()) != 0){
			return getClaimedLocation().compareTo(((OwnershipClaim)stip).getClaimedLocation());
		}
		return 0;
	}
}
