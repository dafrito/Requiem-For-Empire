import java.util.*;

public class Enclave implements Comparable{
	private List m_populations;
	private Planet m_planet;
	private List m_assets;
	private Map m_retailedLots;
	private String m_name;
	public Enclave(String name, Planet planet){
		m_planet = planet;
		m_name = name;
		m_assets = new LinkedList();
		m_retailedLots = new HashMap();
		m_populations = new LinkedList();
	}
	private Enclave(){}; // explicitly forbidden
	public List getPopulations(){return m_populations;}
	public Population getLastPopulation(){return (Population)m_populations.get(m_assets.size()-1);}
	public boolean addPopulation(Population population){
		m_populations.add(population);
		population.setEnclave(this);
		return true;
	}
	public Planet getPlanet(){return m_planet;}
	public String getName(){return m_name;}
	public boolean setName(String name){m_name = name; return true;}
	public List getRetailLots(Brand brand){return (List)m_retailedLots.get(brand);}
	public List getAssets(){return m_assets;}
	public Asset getLastAsset(){return (Asset)m_assets.get(m_assets.size()-1);}
	public boolean addAsset(Asset asset){m_assets.add(asset); return true;}
	public boolean equals(Object o){
		if(m_name.equals(((Enclave)o).getName()) && m_planet.equals(((Enclave)o).getPlanet())){
			return true;
		}
		return false;
	}
	public int compareTo(Object o){
		if(m_planet.compareTo(((Enclave)o).getPlanet()) == 0){
			return m_name.compareTo(((Enclave)o).getName());
		}
		return m_planet.compareTo(((Enclave)o).getPlanet());
	}
	public void iterate(){
		for(int i=0;i<m_assets.size();i++){
			((Asset)m_assets.get(i)).iterate();
		}
		for(int i=0;i<m_populations.size();i++){
			((Population)m_populations.get(i)).iterate();
		}
	}
	public String toString(){
		String string = new String();
		string += "The enclave, " + m_name + ", of the planet " + m_planet.getName() + "\n";
		string += "Assets:\n";
		for(int i=0;i<m_assets.size();i++){
			string += ((Asset)m_assets.get(i)).toString() + "\n";
		}
		string += "Populations:\n";
		for(int i=0;i<m_populations.size();i++){
			string += ((Population)m_populations.get(i)).toString() + "\n";
		}
		return string;
	}
}
