import java.util.*;

public class ProductionAction extends Action{
	private Brand m_brand;
	private int m_quantity;
	public ProductionAction(Brand brand, int quantity){
		m_brand = brand;
		m_quantity = quantity;
	}
	public Brand getBrand(){return m_brand;}
	public int getQuantity(){return m_quantity;}
	public boolean setQuantity(int q){m_quantity = q;return true;}
	public String getActionType(){return "Production action";}
	public boolean execute(Organization org){
		Iterator iter = m_brand.getCommodity().getPrerequisites().entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			if(!((Structure)org).assertInventoryLevel((Brand)entry.getKey(),m_quantity * ((Integer)entry.getValue()).intValue())){
				return false;
			}
		}
		iter = m_brand.getCommodity().getPrerequisites().entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			if(!((Structure)org).expendInventoryLevel((Brand)entry.getKey(),m_quantity * ((Integer)entry.getValue()).intValue())){
				return false;
			}
			
		}
		org.addAsset(new Lot(m_brand, 50, m_quantity));
		return true;
	}
	public String toString(){
		String string = new String();
		string += getActionType() + "\n";
		string += "Produce " + m_quantity + " amount of " + m_brand.getName();
		return string;
	}
	public String toShortString(){
		return "Produce " + m_quantity + " amount of " + m_brand.getName();
	}
	public boolean equals(Object obj){
		if(((Action)obj).getActionType() != getActionType()){
			return false;
		}
		if(((ProductionAction)obj).getBrand() == m_brand){
			return true;
		}return false;
	}
	public int compareTo(Object obj){
		if(((Action)obj).getActionType() != getActionType()){
			return getActionType().compareTo(((Action)obj).getActionType());
		}
		return m_brand.compareTo(((ProductionAction)obj).getBrand());
	}
}
