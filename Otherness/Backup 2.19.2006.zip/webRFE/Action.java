public abstract class Action implements Comparable{
	public abstract String getActionType();
	public abstract boolean execute(Organization organization);
	public abstract String toString();
	public abstract String toShortString();
	public abstract boolean equals(Object e);
	public abstract int compareTo(Object e);
}
