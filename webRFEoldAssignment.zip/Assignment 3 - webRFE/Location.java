import java.util.*;

// Location
// This class is the node of our physical tree. It handles x,y,z coordinates in two ways, depending on the m_isRelativePoint flag.
// If this flag is set as true, then this Location is merely logical, meaning that its children add the parent's point to their own,
// but the scale is still of this parent's parent; its children are visible from above the tree. By having this flag as false, the
// children adopt a new x,y,z scale that is not dependent on the location of this object because the children are not visible from beyond
// this object. We use this to simulate dramatic changes in scale (Cluster -> System, Planet -> Enclave, System -> Planet) where the difference
// in points between two objects is too small to be readable based on the parent scale.

public class Location implements Comparable{
	public static final LocationType GALAXY = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX, "Galaxy");
	public static final LocationType CLUSTER = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX, "Cluster");
	public static final LocationType SYSTEM = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX, "System");
	public static final LocationType PLANET = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DONOTDISPLAY, "Planet");
	protected String m_name, m_adjective;
	protected LocationType m_locationType;
	protected List m_children;
	protected boolean m_canHaveChildren;
	protected Point3d m_point;
	protected boolean m_isRelativePoint;
	protected Location m_parent;
	protected Location(){} // explicitly forbidden
	public Location(LocationType locationType, String name, String adjective, boolean canHaveChildren, Point3d point, boolean isRelativePoint){
		m_locationType = locationType;
		m_name = name;
		m_adjective = adjective;
		m_canHaveChildren = canHaveChildren;
		m_point = point;
		m_children = new Vector();
		m_isRelativePoint = isRelativePoint;
	}
	public Location getParent(){return m_parent;}
	public boolean setParent(Location parent){m_parent = parent; return true;}
	public boolean setCanHaveChildren(boolean haveChildren){m_canHaveChildren = haveChildren;return true;}
	public boolean getCanHaveChildren(){return m_canHaveChildren;}
	public boolean setName(String name){m_name = name;return true;}
	public String getName(){return m_name;}
	public String getFormalName(){return m_locationType.formatString(m_adjective);}
	public Point3d getPoint(){return m_point;}
	public boolean setPoint(Point3d newPoint){m_point = newPoint; return true;}
	public boolean setAdjective(String adj){m_adjective = adj;return true;}
	public String getAdjective(){return m_adjective;}
	public LocationType getType(){return m_locationType;}
	public boolean getIsRelativePoint(){return m_isRelativePoint;}
	public String toString(){
		String string = new String("\n");
		string += RiffToolbox.printUnderline(m_locationType.formatString(m_adjective), "-");
		string += "Location: " + m_point + "\n";
		if(m_isRelativePoint){string += "This point is relative to its parent.\n";
		}else{string += "This location is not visible from beyond its parent.\n";}
		if(m_canHaveChildren){
			if(!m_children.isEmpty()){
				string += "Children of " + m_locationType.formatString(m_adjective) + ":\n";
				for(int i = 0; i < m_children.size(); i++){
					string += (Location)m_children.get(i);
				}
			}
		}else{string += "This location can have no children.\n";}
		return string;
	}
	public int compareTo(Object otherLocation){
		return m_name.compareTo(((Location)otherLocation).getName());
	}	
	public boolean equals(Object otherLocation){
		if(compareTo(otherLocation) == 0){return true;}
		return false;
	}
	public Location getLastChild(){
		if(m_children.isEmpty()){return null;}
		return (Location)m_children.get(m_children.size() - 1);
	}
	public Location getChild(String childName){
		if(m_name.equals(childName)){
			return this;
		}
		for(int i = 0; i < m_children.size(); i++){
			if(((Location)m_children.get(i)).getChild(childName) != null){
				return ((Location)m_children.get(i)).getChild(childName);
			}
		}
		return null;
	}
	public Location getChild(String childName, LocationType locationType){
		if(m_name.equals(childName) && locationType.equals(m_locationType)){
			return this;
		}
		for(int i = 0; i < m_children.size(); i++){
			if(((Location)m_children.get(i)).getChild(childName, locationType) != null){
				return ((Location)m_children.get(i)).getChild(childName);
			}
		}
		return null;
	}
	public boolean addChild(Location child){
		if(m_canHaveChildren){
			m_children.add(child);
			child.setParent(this);
			return true;
		}
		return false;
	}
	public void iterate(){
		for(int i =0; i<m_children.size();i++){
			((Location)m_children.get(i)).iterate();
		}
	}
}
