public class Point3d{
	double m_x;
	double m_y;
	double m_z;
	public Point3d(){
		m_x = 0.0d;
		m_y = 0.0d;
		m_z = 0.0d;
	}
	
	public Point3d(double x,double y,double z){
		m_x = x;
		m_y = y;
		m_z = z;
	}
	
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public boolean setX(double x){m_x = x; return true;}
	public boolean setY(double y){m_y = y; return true;}
	public boolean setZ(double z){m_z = z; return true;}

	public String toString(){
		return new String("(" + m_x + ", " + m_y + ", " + m_z + ")");
	}
}
