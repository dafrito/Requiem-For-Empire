import java.util.*;

public class Planet extends Location{
	private float m_fertility;
	private List m_enclaves;
	public Planet(String name, String adjective, Point3d point, float fertility){
		m_fertility = fertility;
		m_enclaves = new Vector();
		m_locationType = Location.PLANET;
		m_name = name;
		m_adjective = adjective;
		m_canHaveChildren = true;
		m_point = point;
		m_children = new Vector();
		m_isRelativePoint = false;
	}
	public float getFertility(){
		return m_fertility;
	}
	public List getEnclaves(){return m_enclaves;}
	public boolean addEnclave(Enclave enclave){m_enclaves.add(enclave);return true;}
	public void iterate(){
		for(int i=0;i<m_enclaves.size();i++){
			((Enclave)m_enclaves.get(i)).iterate();
		}
	}
	public String toString(){
		String string = new String("\n");
		string += RiffToolbox.printUnderline(m_locationType.formatString(m_adjective), "-");
		string += "Location: " + m_point + "\n";
		if(m_isRelativePoint){string += "This point is relative to its parent.\n";
		}else{string += "This location is not visible from beyond its parent.\n";}
		string += "Enclaves: \n";
		for(int i=0;i<m_enclaves.size();i++){
			string += ((Enclave)m_enclaves.get(i)).toString();
		}
		return string;
	}
}
