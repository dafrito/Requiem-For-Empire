import java.util.*;

public abstract class Asset{
	protected Organization m_deFactoOwner;
	protected Map m_deJureOwners;
	public boolean setDeFactoOwner(Organization owner){m_deFactoOwner = owner;return true;}
	public Organization getDeFactoOwner(){return m_deFactoOwner;}
	public Map getAllDeJureOwners(){return m_deJureOwners;}
	public OwnershipClaim getOwnershipContract(Organization owner){return (OwnershipClaim)m_deJureOwners.get(owner);}
	public boolean addOwnershipContract(OwnershipClaim claim){m_deJureOwners.put(claim.getClaimer(), claim);return true;}
	public OwnershipClaim removeOwnershipContract(Organization owner){return (OwnershipClaim)m_deJureOwners.remove(owner);}
	public abstract void iterate();
	public abstract String toString();
}
