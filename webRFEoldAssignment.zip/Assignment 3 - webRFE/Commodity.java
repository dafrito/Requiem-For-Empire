import java.util.*;

public class Commodity{
	private Map m_prerequisites;
	private String m_name;
	public Commodity(){
		m_prerequisites = new HashMap();
	}
	public Commodity(String name){
		m_name = name;
		m_prerequisites = new HashMap();
	}
	public String getName(){return m_name;}
	public Map getPrerequisites(){return m_prerequisites;}
	public boolean addPrerequisite(Commodity prereq, Integer quantity){
		m_prerequisites.put(prereq, quantity);
		return true;
	}
	public String toString(){
		String string = new String();
		string += "Commodity: " + m_name + "\n";
		string += "Prerequisites: \n";
		Iterator iter = m_prerequisites.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			string += ((Integer)entry.getValue()).intValue() + " amount of " + ((Commodity)entry).getName();
		}
		return string;
	}
}
