import java.util.*;

public class Structure extends Organization{
	protected Enclave m_enclave;
	private Personality m_manager;
	protected List m_inventory;
	public Structure(){
		m_orders = new LinkedList();
		m_actions = new LinkedList();
		m_inventory = new LinkedList();
		m_formalName = new String();
		m_adjective = new String();
		m_shortName = new String();
	}
	public Structure(Organization owner, Enclave enclave, String formal, String adj, String shortName){	
		m_orders = new LinkedList();
		m_actions = new LinkedList();
		m_inventory = new LinkedList();
		m_deFactoOwner = owner;
		m_formalName = formal;
		m_adjective = adj;
		m_enclave = enclave;
		m_shortName = shortName;
	}	
	public List getInventory(){return m_inventory;}
	public boolean addInventory(Lot lot){m_inventory.add(lot); return true;}
	public boolean assertInventoryLevel(Commodity comm, int quantity){
		int level = 0;
		for(int i=0;i<m_inventory.size();i++){
			Lot lot = (Lot)m_inventory.get(i);
			if(comm == lot.getBrand().getCommodity()){
				level += lot.getQuantity();
				if(level >= quantity){return true;}
			}
		}
		return false;
	}
	public Enclave getEnclave(){return m_enclave;}
	public boolean expendInventoryLevel(Commodity comm, int quantity){
		int level = quantity;
		for(int i=0;i<m_inventory.size();i++){
			Lot lot = (Lot)m_inventory.get(i);
			if(comm == lot.getBrand().getCommodity()){
				if(lot.getQuantity() >= level){
					lot.setQuantity(lot.getQuantity() - level);
					return true;
				}
				level -= lot.getQuantity();
				lot.setQuantity(0);
			}
		}
		return false;
	}
	public Personality getManager(){return m_manager;}
	public boolean setManager(Personality manager){m_manager = manager;return true;}
	public void iterate(){
		for(int i=0;i<m_orders.size();i++){
			if(((Order)m_orders.get(i)).execute(this) == false){
				System.out.println("Order failed\n" + ((Order)m_orders.get(i)));
			}
		}
	}
	public String toString(){
		String string = new String();
		string += "Manager: " + m_manager + "\n";
		string += "Inventory:\n";
		for(int i =0;i<m_inventory.size();i++){
			string += ((Lot)m_inventory.get(i)).toString();
		}
		return super.toString() + string;
	}
}
