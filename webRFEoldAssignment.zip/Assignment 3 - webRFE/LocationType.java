public class LocationType implements Comparable{
	private String m_locationType;
	private final int m_locationTypeDisplay;
	public LocationType(int locationTypeDisplay, String locationTypeName){
		m_locationTypeDisplay = locationTypeDisplay;
		m_locationType = locationTypeName;
	}
	public boolean setName(String newName){m_locationType = newName; return true;}
	public String getName(){return m_locationType;}
	public String formatString(String name){
		switch(m_locationTypeDisplay){
			case LocationTypeDisplay.LOCATIONTYPE_DONOTDISPLAY:
			return name;
			case LocationTypeDisplay.LOCATIONTYPE_DISPLAYASPREFIX:
			return m_locationType + " " + name;
			case LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX:
			return name + " " + m_locationType;
			default:
			return name;
		}
	}
	public int compareTo(Object otherLocationType){
		return m_locationType.compareTo(((LocationType)otherLocationType).getName());
	}
	public boolean equals(Object otherLocationType){
		if(compareTo(otherLocationType) != 0){
			return false;
		}
		return true;
	}
}