public class Brand implements Comparable{
	private int m_quality;
	private Organization m_organization;
	private Commodity m_commodity;
	private String m_name;
	public Brand(String name, Commodity commodity, int quality, Organization organization){
		m_name = name;
		m_quality = quality;
		m_organization = organization;
		m_commodity = commodity;
	}
	public String getName(){return m_name;}
	public int getQuality(){return m_quality;}
	public Organization getOrganization(){return m_organization;}
	public Commodity getCommodity(){return m_commodity;}
	public boolean equals(Object o){
		if(m_name.compareTo(((Brand)o).getName()) == 0){
			return true;
		}return false;
	}
	public int compareTo(Object o){
		return m_name.compareTo(((Brand)o).getName());
	}
}
