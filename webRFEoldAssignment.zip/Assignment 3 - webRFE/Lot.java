public class Lot extends Asset{
	private Brand m_brand;
	private int m_quality;
	private int m_quantity;
	public Lot(Brand brand, int quality, int quantity){
		m_brand = brand;
		m_quality = quality;
		m_quantity = quantity;
	}
	public int getQuality(){return m_quality;}
	public int getQuantity(){return m_quantity;}
	public boolean setQuantity(int quantity){m_quantity = quantity;return true;}
	public Brand getBrand(){return m_brand;}
	public void iterate(){
		return;
	}
	public String toString(){
		String string = new String();
		string += "\n" + RiffToolbox.printUnderline("Lot of " + m_brand.getName(), "-");
		string += "Commodity: " + m_brand.getCommodity().getName() + "\n";
		string += "Quality: " + m_quality + " | Quantity: " + m_quantity;
		return string;
	}
}
