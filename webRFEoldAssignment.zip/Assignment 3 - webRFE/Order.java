public class Order{
	private Action m_action;
	private int m_numTimes;
	public Order(Action action, int numTimes){
		m_action = action;
		m_numTimes = numTimes;
	}
	public Action getAction(){return m_action;}
	public int getNumTimes(){return m_numTimes;}
	public boolean execute(Organization organization){
		if(m_numTimes != 0){
			if(m_numTimes > 0){m_numTimes--;}
			return m_action.execute(organization);
		}else{
			organization.removeOrder(this);
			return true;
		}
	}
	public String toString(){
		String string = new String();
		string += "Order:\n";
		string += m_action.toShortString() + " " + m_numTimes + " time(s)";
		return string;
	}
}
