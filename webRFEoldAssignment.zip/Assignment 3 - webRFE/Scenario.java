import java.util.*;
public class Scenario{
	private Location m_rootLocation;
	private String m_scenarioName;
	private GregorianCalendar m_gameCalendar;
	private int m_timeScale;
	private int m_numIterations;
	private Calendar m_endDate;	
	private Scenario(){} // explicitly forbidden.
	public Scenario(String scenarioName, Location rootLocation, int timeScale, GregorianCalendar startDate, Calendar endDate){
		/*if(startDate.getTime().compareTo(endDate.getTime()) < 0){
			Exception e = new Exception("End date is less than start-date");
			throw(e);}*/
		m_rootLocation = rootLocation;
		m_timeScale = timeScale;
		m_gameCalendar = startDate;
		m_gameCalendar.setLenient(true);
		m_endDate = endDate;
		m_scenarioName = scenarioName;
	}
	public Location getRootElement(){return m_rootLocation;}
	public boolean setEndDate(Calendar endDate){m_endDate = endDate;return true;}
	public Date getEndDate(){return m_endDate.getTime();}
	public Date getDate(){return m_gameCalendar.getTime();}
	
	public boolean iterate(){
		m_gameCalendar.add(GregorianCalendar.SECOND, m_timeScale);
		m_rootLocation.iterate();
		m_numIterations++;
		return true;
	}
	
	public String toString(){
		String string = new String();
		string += RiffToolbox.printBorder(m_scenarioName, "-");
		string += "Current date: " + m_gameCalendar.getTime() + "\n";
		string += "End date: " + m_endDate.getTime() + "\n";
		string += "Timescale: " + m_timeScale + "\n";
		string += "Number of iterations: " + m_numIterations + "\n";
		string += "Root element data follows: \n";
		string += m_rootLocation;
		return string;
	}
}