import java.util.*;

public class Population{
	private Map m_identities;
	private int m_size;
	private Map m_consumptionLevels;
	private Enclave m_enclave;
	public Population(){
		m_identities = new HashMap();
		m_consumptionLevels = new HashMap();
	}
	public Population(int size){
		m_size = size;
		m_identities = new HashMap();
		m_consumptionLevels = new HashMap();
	}
	public Population(int size, Enclave enclave){
		m_enclave = enclave;
		m_size = size;
		m_identities = new HashMap();
		m_consumptionLevels = new HashMap();
	}
	public Map getIdentities(){return m_identities;}
	public Map getConsumptionLevels(){return m_consumptionLevels;}
	public int getSize(){return m_size;}
	public Enclave getEnclave(){return m_enclave;}
	public boolean setEnclave(Enclave enclave){m_enclave = enclave; return true;}
	public boolean addIdentity(Identity ident, Integer loyalty){m_identities.put(ident, loyalty);return true;}
	public Integer getLoyalty(Identity identity){return (Integer)m_identities.get(identity);}
	public Integer getConsumptionLevel(Brand comm){return (Integer)m_consumptionLevels.get(comm);}
	public boolean addConsumptionLevel(Brand comm, Integer level){m_consumptionLevels.put(comm, level);return true;}
	public void iterate(){
		Iterator iter = m_consumptionLevels.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			List list = m_enclave.getRetailLots((Brand)entry.getKey());
			if(list == null){
				continue;
			}
			int level = m_size * ((Integer)entry.getValue()).intValue();
			int q = 0;
			while(level != 0 && list.size() > 0){
				if(q > 100){break;}
				if(((Lot)list.get(0)).getQuantity() >= level){
					System.out.println("\nA population is consuming this lot...");
					System.out.println(((Lot)list.get(0)) + "\n");
					((Lot)list.get(0)).setQuantity(((Lot)list.get(0)).getQuantity()-level);
					break;
				}
				level -= ((Lot)list.get(0)).getQuantity();
				list.remove(0);
			}
		}
	}
	public String toString(){
		String string = new String();
		string += "Population of " + m_size + " people\n";
		return string;
	}
}
