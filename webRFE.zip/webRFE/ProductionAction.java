import java.util.*;

public class ProductionAction extends Action{
	public static String m_actionName = new String("Production Action");
	public String toString(){return m_actionName;}
	public static void execute(Order superOrder)throws FailedActionException{
		assert Debugger.printDebug("ProductionAction/execute", "(execute)\nProduction action now executing...");
		QuantityProductionOrder order = (QuantityProductionOrder)superOrder;
		List<Lot>totalList = new LinkedList<Lot>();
		double maxQuantity = order.getRemainingQuantity();
		double quantity=0;
		assert Debugger.printDebug("ProductionAction/execute", "Finding necessary assets for production...");
		for(PrerequisiteLevel level:order.getCommodity().getAllPrerequisiteLevels()){
			assert Debugger.printDebug("ProductionAction/execute", "Finding this commodity: " + level.getCommodity());
			List<Lot>commList=null;
			if(maxQuantity == -1){
				commList=order.getActiveAsset().getAssets(level.getCommodity());
			}else{
				commList=order.getActiveAsset().getAssets(level.getCommodity(), level.getQuantity()* maxQuantity);
			}
			if(commList==null){
				assert Debugger.printDebug("ProductionAction/execute", "None found, returning.");
				return;
			}
			totalList.addAll(commList);
			for(Lot lot:commList){quantity+=lot.getQuantity();}
			assert Debugger.printDebug("ProductionAction/execute", "Number of items found matching commodity-type: " + quantity);
			double previous=maxQuantity;
			if(maxQuantity == -1){
				maxQuantity=quantity/level.getQuantity();
			}else{
				if(quantity/(level.getQuantity() * maxQuantity) != 1){
					maxQuantity *= quantity/(level.getQuantity() * maxQuantity);
				}
			}
			if(previous!=maxQuantity){
				assert Debugger.printDebug("ProductionAction/execute", "Maximum quantity produceable is now: " + maxQuantity);
			}
		}
		if(order.getTotalQuantity() != -1 && maxQuantity != order.getRemainingQuantity()){
			totalList=new LinkedList<Lot>();
			for(PrerequisiteLevel level:order.getCommodity().getAllPrerequisiteLevels()){
				List<Lot>commList=order.getActiveAsset().getAssets(level.getCommodity(),level.getQuantity()*maxQuantity);
				if(commList==null){return;}
				totalList.addAll(commList);
				for(Lot lot:commList){quantity+=lot.getQuantity();}
				if(quantity/(level.getQuantity()*maxQuantity)!=1){
					maxQuantity*=quantity/(level.getQuantity()*maxQuantity);
				}
			}
		}
		order.getActiveAsset().removeAll(totalList);
		try{
			order.getActiveAsset().add(new Lot(order.getActiveAsset(),null,order.getBrand(),1.0d,maxQuantity));
		}catch(CommodityMapException ex){
			throw new FailedActionException(ex);
		}
	}
}
