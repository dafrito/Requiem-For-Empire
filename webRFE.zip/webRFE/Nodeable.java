public interface Nodeable{
	public boolean nodificate();
}
