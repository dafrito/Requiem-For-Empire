public class CollectResourceOrder extends Order{
	private ResourcePoint m_point;
	private double m_quantity;
	private double m_minimumQuality;
	private Population m_population;
	public CollectResourceOrder(Population population, ResourcePoint point, double quantity, double minQuality){
		super();
		m_population=population;
		m_point=point;
		m_quantity=quantity;
		m_minimumQuality=minQuality;
	}
	public ResourcePoint getResourcePoint(){return m_point;}
	public double getQuantity(){return m_quantity;}
	public double getMinimumQuality(){return m_minimumQuality;}
	public Population getPopulation(){return m_population;}
	public void execute(double iterationTime) throws OrderException{
		super.execute(iterationTime);
		CollectResourceAction.execute(this);
		setStatus(OrderStatus.COMPLETE);
	}
	public String toString(){
		String string = new String();
		string += "Order: CollectResourceOrder";
		string += "\nThe population is to collect a minimum of " + m_quantity + " units of minimum quality, " + m_minimumQuality + ", of the good listed below.";
		string += "\nResourcePoint: " + m_point;
		return string;
	}
}
