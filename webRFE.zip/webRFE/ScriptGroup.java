import java.util.List;
public class ScriptGroup extends ScriptElement implements Nodeable{
	public enum GroupType{curly,parenthetical}
	protected List<Object>m_elements;
	private GroupType m_type;
	public ScriptGroup(Referenced ref,List<Object>elements,GroupType type){
		super(ref);
		m_elements=elements;
		m_type=type;
	}
	public GroupType getType(){return m_type;}
	public List<Object>getElements(){return m_elements;}
	public void setElements(List<Object>list){m_elements=list;}
	public boolean nodificate(){
		assert Debugger.openNode("Script Group ("+m_type+")");
		assert Debugger.addSnapNode("Elements",m_elements);
		assert Debugger.closeNode();
		return true;
	}
}
