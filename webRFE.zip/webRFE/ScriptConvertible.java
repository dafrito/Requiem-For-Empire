public interface ScriptConvertible{
	public Object convert();
}
