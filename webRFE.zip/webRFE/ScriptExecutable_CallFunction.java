import java.util.List;
import java.util.Vector;
public class ScriptExecutable_CallFunction extends ScriptElement implements ScriptExecutable,ScriptValue_Abstract,Nodeable{
	private String m_functionName;
	private List<ScriptValue_Abstract>m_params;
	private ScriptValue_Abstract m_object;
	public ScriptExecutable_CallFunction(Referenced ref,ScriptValue_Abstract object,String functionName,List<ScriptValue_Abstract>params){
		super(ref);
		m_object=object;
		m_functionName=functionName;
		m_params=params;
	}
	public static ScriptValue_Abstract callFunction(ScriptEnvironment env,Referenced ref,ScriptValue_Abstract object,String name,List<ScriptValue_Abstract>params)throws Exception_Nodeable{
		assert Debugger.openNode("Function Calls","Calling Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		// Get our object
		if(object==null){object=env.getCurrentObject();}else{object=object.getValue();}
		assert Debugger.addSnapNode("Template ("+object.getType()+")",object);
		// Convert our values of questionable nestingness down to pure values
		Vector<ScriptValue_Abstract>baseList=new Vector<ScriptValue_Abstract>();
		for(int i=0;i<params.size();i++){baseList.add(params.get(i).getValue());}
		// Display those params
		if(params==null){assert Debugger.addNode("Parameters (0 parameter(s))");
		}else{assert Debugger.addSnapNode("Parameters ("+baseList.size()+" parameter(s))",baseList);}
		// Get our function
		ScriptFunction_Abstract function=((ScriptTemplate_Abstract)object).getFunction(name,baseList);
		assert function!=null:"Function to call is null ("+ScriptFunction.getDisplayableFunctionName(name)+")";
		// Execute that function
		env.advanceStack((ScriptTemplate_Abstract)object,function);
		env.getCurrentFunction().execute(ref,baseList);
		ScriptValue_Abstract returning=env.getCurrentFunction().getReturnValue();
		if(returning==null){
			if(!env.getCurrentFunction().getReturnType().equals(ScriptValueType.VOID)){throw new Exception_Nodeable_IllegalNullReturnValue(ref,env.getCurrentFunction());}
		}else{
			returning=returning.castToType(ref,env.getCurrentFunction().getReturnType());
		}
		env.retreatStack();
		assert Debugger.closeNode();
		return returning;
	}
	// ScriptExecutable implementation
	public ScriptValue_Abstract execute()throws Exception_Nodeable{return callFunction(getEnvironment(),this,m_object,m_functionName,m_params);}
	// ScriptValue_Abstract implementation
	public ScriptValueType getType(){
		try{
			return ((ScriptTemplate_Abstract)m_object.getValue()).getFunction(m_functionName,m_params).getReturnType();
		}catch(Exception_Nodeable ex){
			throw new Exception_InternalError(getEnvironment(),ex.toString());
		}
	}
	public boolean isConvertibleTo(ScriptValueType type){return ScriptValueType.isConvertibleTo(getEnvironment(),getType(),type);}
	public ScriptValue_Abstract castToType(Referenced ref,ScriptValueType type)throws Exception_Nodeable{return getValue().castToType(ref,type);}
	public ScriptValue_Abstract getValue()throws Exception_Nodeable{return execute();}
	public ScriptValue_Abstract setValue(Referenced ref,ScriptValue_Abstract value)throws Exception_Nodeable{return getValue().setValue(ref,value);}
	public boolean valuesEqual(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{return getValue().valuesEqual(ref,rhs);}
	public int valuesCompare(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{return getValue().valuesCompare(ref,rhs);}
	// Nodeable implementation
	public boolean nodificate(){
		assert Debugger.openNode("Function Call ("+ScriptFunction.getDisplayableFunctionName(m_functionName)+")");
		assert super.nodificate();
		assert Debugger.addSnapNode("Parameters", m_params);
		assert Debugger.closeNode();
		return true;
	}
}
