// Requiem for Empire
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import java.awt.*;

public class RiffDeveloper extends JFrame{
	private static final int HEIGHT=600;
	private static final int WIDTH=800;
	private Debug_Environment m_debugger;
	private ScriptEnvironment m_environment;
	private InterfaceElement_Page m_pageElement;
	public RiffDeveloper(){
		super("Requiem for Empire");
		setSize(RiffDeveloper.WIDTH, RiffDeveloper.HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		m_debugger=new Debug_Environment(this,WIDTH,HEIGHT);
		m_pageElement=new InterfaceElement_Page(m_environment);
		m_environment=new ScriptEnvironment(this);
	}
	public Debug_Environment getDebugger(){return m_debugger;}
	public InterfaceElement_Root getRoot(){return m_pageElement.getRoot();}
	public ScriptEnvironment getEnvironment(){return m_environment;}
	public void reset(){
		m_pageElement.getRoot().clear();
	}
	public void createWindow(){
		assert Debugger.openNode("Creating Developer Environment");
		getContentPane().add(m_pageElement=new InterfaceElement_Page(getEnvironment()));
		m_environment.initialize();
		assert Debugger.addSnapNode("Environment Initialized",m_environment);
		assert Debugger.closeNode();
		setVisible(true);
	}
	public static void main(String[] args) {
	 	RiffDeveloper studio=new RiffDeveloper();
		studio.createWindow();
	}
}
