public interface Transport{
	public void expendFuel(double time);
	public void setPosition(Point position);
	public double getVelocity(double time);
	public Double getValue(Point source, Point tempDestination, Point destination, DiscreteRegion region);
}
