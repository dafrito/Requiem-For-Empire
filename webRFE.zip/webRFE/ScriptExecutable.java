public interface ScriptExecutable{
	// ScriptExecutable implementation
	public ScriptValue_Abstract execute()throws Exception_Nodeable;
	public ScriptElement getDebugReference();
}
