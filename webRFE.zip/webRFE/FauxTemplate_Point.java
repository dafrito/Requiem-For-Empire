import java.util.*;
public class FauxTemplate_Point extends FauxTemplate implements ScriptConvertible,Nodeable{
	public static final String POINTSTRING="Point";
	public double m_x,m_y,m_z;
	public FauxTemplate_Point(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,POINTSTRING),ScriptValueType.getObjectType(env),new LinkedList<ScriptValueType>());
	}
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public void setX(double x){m_x=x;}
	public void setY(double y){m_y=y;}
	public void setZ(double z){m_z=z;}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Point Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_Point template=(FauxTemplate_Point)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_Point(getEnvironment());}
			((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
			template.addFauxFunction("getX",ScriptValueType.DOUBLE,ScriptValueType.createEmptyParamList(),ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("getY",ScriptValueType.DOUBLE,ScriptValueType.createEmptyParamList(),ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("getZ",ScriptValueType.DOUBLE,ScriptValueType.createEmptyParamList(),ScriptKeywordType.PUBLIC,false);
			List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
			template.addFauxFunction("setX",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("setY",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("setZ",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			if(params.size()==0){
				assert Debugger.closeNode();
				return template;
			}else if(params.size()==3){
				template.setX(Parser.getDouble(params.get(0)).doubleValue());
				template.setY(Parser.getDouble(params.get(1)).doubleValue());
				template.setZ(Parser.getDouble(params.get(2)).doubleValue());
				assert Debugger.closeNode();
				return template;
			}
			assert false:"Faux function undefined";
		}if(name.equals("getX")){return Parser.getRiffDouble(getEnvironment(),((FauxTemplate_Point)template).getX());
		}else if(name.equals("getY")){return Parser.getRiffDouble(getEnvironment(),((FauxTemplate_Point)template).getY());
		}else if(name.equals("getZ")){return Parser.getRiffDouble(getEnvironment(),((FauxTemplate_Point)template).getZ());
		}else if(name.equals("setX")){((FauxTemplate_Point)template).setX(Parser.getDouble(params.get(0)).doubleValue());
		}else if(name.equals("setY")){((FauxTemplate_Point)template).setY(Parser.getDouble(params.get(0)).doubleValue());
		}else if(name.equals("setZ")){((FauxTemplate_Point)template).setZ(Parser.getDouble(params.get(0)).doubleValue());
		}else{return ((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);}
		return null;
	}
	// ScriptConvertible and Nodeable implementations
	public Object convert(){return new Point_Euclidean(m_x,m_y,m_z);}
	public boolean nodificate(){
		assert Debugger.openNode("Point Faux Template");
		assert super.nodificate();
		assert Debugger.addNode("X: "+m_x);
		assert Debugger.addNode("Y: "+m_y);
		assert Debugger.addNode("Z: "+m_z);
		assert Debugger.closeNode();
		return true;
	}
}
