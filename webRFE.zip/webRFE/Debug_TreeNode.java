import java.util.*;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.DefaultListModel;
class Incrementor{
	private int m_value;
	public Incrementor(){this(0);}
	public Incrementor(int initial){m_value=initial;}
	public void increment(){increment(1);}
	public void increment(int value){m_value+=value;}
	public int getValue(){return m_value;}
}
public class Debug_TreeNode implements MutableTreeNode{
	private static int m_identifier=0;
	private static Vector<Object>m_cacheData=new Vector<Object>(1000,50);
	private static Vector<Incrementor>m_cacheDataRepetitions=new Vector<Incrementor>(1000,50);
	private static java.util.Map<Object,Integer>m_cacheMap=new HashMap<Object,Integer>(300);
	protected final int m_dataCode,m_unique;
	protected MutableTreeNode m_parent,m_practicalParent;
	protected String m_group;
	protected List<Debug_TreeNode>m_children=new LinkedList<Debug_TreeNode>();
	public Debug_TreeNode(int dataCode){this(null,dataCode);}
	public Debug_TreeNode(String group,int dataCode){
		this(m_identifier++,group,dataCode);
	}
	public Debug_TreeNode(int unique,String group,int dataCode){
		m_unique=unique;
		m_group=group;
		m_dataCode=dataCode;
	}
	public Debug_TreeNode(Object data){this((String)null,data);}
	public Debug_TreeNode(String group,Object data){
		m_unique=m_identifier++;
		m_group=group;
		assert data!=null;
		if(m_cacheMap.containsKey(data)){
			m_dataCode=m_cacheMap.get(data);
			m_cacheDataRepetitions.get(m_dataCode).increment();
		}else{
			m_cacheData.add(data);
			m_cacheMap.put(data,new Integer(m_cacheData.size()-1));
			m_cacheDataRepetitions.add(new Incrementor(1));
			m_dataCode=m_cacheData.size()-1;
		}
	}
	public boolean equals(Object o){
		return m_unique==((Debug_TreeNode)o).getUnique();
	}
	public int getUnique(){return m_unique;}
	public Debug_TreeNode duplicate(){
		Debug_TreeNode node=new Debug_TreeNode(getUnique(),getGroup(),getDataCode());
		for(Debug_TreeNode child:getChildren()){
			node.addChild(child.duplicate());
		}
		return node;
	}
	public Debug_TreeNode getNode(Debug_TreeNode node){
		for(Debug_TreeNode child:m_children){
			if(child.equals(node)){return child;}
		}
		return null;
	}
	public List<Debug_TreeNode> getNodesByData(Object data){
		List<Debug_TreeNode>nodes=new LinkedList<Debug_TreeNode>();
		for(Debug_TreeNode child:m_children){
			if(child.getData().equals(data)){
				nodes.add(child);
			}
		}
		return nodes;
	}
	// TreeNode functions
	public List<Debug_TreeNode>getChildren(){return Collections.unmodifiableList(m_children);}
	public Enumeration children(){return Collections.enumeration(m_children);}
	public boolean getAllowsChildren(){return true;}
	public TreeNode getChildAt(int x){return (TreeNode)m_children.get(x);}
	public int getChildCount(){return m_children.size();}
	public int getIndex(TreeNode node){return m_children.indexOf(node);}
	public TreeNode getParent(){return m_parent;}
	public boolean isLeaf(){return m_children.size()==0;}
	// MutableTreeNode functions
	public void remove(int index){m_children.remove(index);}
	public void remove(MutableTreeNode node){m_children.remove(node);}
	public void removeFromParent(){m_parent.remove(this);m_parent=null;}
	public void setParent(MutableTreeNode parent){assert parent!=this;m_parent=parent;}
	public void setPracticalParent(MutableTreeNode parent){m_practicalParent=parent;}
	public TreeNode getPracticalParent(){return m_practicalParent;}
	public void setUserObject(Object data){throw new Exception_InternalError("Unimplemented feature");}
	public void insert(MutableTreeNode child, int index){throw new Exception_InternalError("Unimplemented feature");}
	// Debug_TreeNode extensions
	public TreePath getTreePath(){return getTreePath(getData().toString());}
	public TreePath getTreePath(String name){
		return new NamedTreePath(name,getPathFromRoot(new LinkedList<MutableTreeNode>()).toArray());
	}
	public TreePath getRelativeTreePath(){return getRelativeTreePath(getData().toString());}
	public TreePath getRelativeTreePath(String name){
		return new NamedTreePath(name,getRelativePathFromRoot(new LinkedList<MutableTreeNode>()).toArray());
	}
	public List<MutableTreeNode>getPathFromRoot(List<MutableTreeNode>list){
		list.add(0,this);
		if(!isRoot()){((Debug_TreeNode)getParent()).getPathFromRoot(list);}
		return list;
	}
	public List<MutableTreeNode>getRelativePathFromRoot(List<MutableTreeNode>list){
		list.add(0,this);
		if(!isRoot()){((Debug_TreeNode)getParent()).getRelativePathFromRoot(list);}
		return list;
	}
	public String getGroup(){return m_group;}
	public boolean hasChildren(){return m_children.size()>0;}
	public int getTotalChildren(){
		Iterator iter=m_children.iterator();
		int value=m_children.size()+1;
		while(iter.hasNext()){
			value+=((Debug_TreeNode)iter.next()).getChildCount();
		}
		return value;
	}
	public void addAll(List<Debug_TreeNode> nodes){
		for(Debug_TreeNode node:nodes){addChild(node);}
	}
	public Debug_TreeNode addChild(Object data){return addChild(new Debug_TreeNode(data));}
	public Debug_TreeNode addChild(Debug_TreeNode node){
		m_children.add(node);
		if(node.getParent()==null){node.setParent(this);}
		if(node.getPracticalParent()==null){node.setPracticalParent(this);}
		return node;
	}
	public Debug_TreeNode getRoot(){
		if(m_parent==null){
			return this;
		}
		assert m_parent!=this:"Node's parent is itself.";
		return ((Debug_TreeNode)getParent()).getRoot();
	}
	public Debug_TreeNode filterByData(DefaultListModel data){
		if(!isRoot()){return getRoot().filterByData(data);}
		Debug_TreeNode filterNode=new Debug_TreeNode("Filtered List: " + data.get(0));
		filterNode.addAll(getChildrenByFilter(data));
		return filterNode;
	}
	public List<Debug_TreeNode> getChildrenByFilter(DefaultListModel data){
		List<Debug_TreeNode> filtered=new LinkedList<Debug_TreeNode>();
		boolean flag=false;
		for(Debug_TreeNode node:m_children){
			for(int i=0;i<data.size();i++){
				if(node.getData().equals(data.get(i))||(node.getGroup()!=null&&node.getGroup().equals(data.get(i)))){
					filtered.add(new Debug_TreeNode_Orphaned(node));flag=true;break;
				}
			}
			if(!flag){filtered.addAll(node.getChildrenByFilter(data));}
		}
		return filtered;
	}
	public Object getData(){return m_cacheData.get(m_dataCode);}
	public int getDataCode(){return m_dataCode;}
	public boolean isRoot(){return m_parent==null;}
	public Debug_TreeNode getLastChild(){return (Debug_TreeNode)m_children.get(m_children.size()-1);}
	public Debug_TreeNode removeLastChild(){return (Debug_TreeNode)m_children.remove(m_children.size()-1);}
	public String toString(){if(getData()!=null){return getData().toString();}return null;}
}
class Debug_TreeNode_Orphaned extends Debug_TreeNode{
	private List<MutableTreeNode> m_pathList=new LinkedList<MutableTreeNode>();
	public Debug_TreeNode_Orphaned(Debug_TreeNode node){
		super(node.getUnique(),node.getGroup(),node.getDataCode());
		Object[]array=node.getTreePath("Path to Orphan").getPath();
		for(Object elem:array){
			m_pathList.add((MutableTreeNode)elem);
		}
		for(Debug_TreeNode child:node.getChildren()){
			addChild(child.duplicate());
		}
	}
	public List<MutableTreeNode>getRelativePathFromRoot(List<MutableTreeNode>list){
		for(int i=0;i<m_pathList.size();i++){
			list.add(i,m_pathList.get(i));
		}
		return list;
	}
}
