import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.*;
public class InterfaceElement_Panel extends InterfaceElement implements Interface_Container,RiffInterface_MouseListener,Nodeable{
	private List<GraphicalElement> m_elements;
	private Point_Euclidean m_offset;
	public InterfaceElement_Panel(ScriptEnvironment env, Stylesheet uniqueStyle,Stylesheet classStyle,List<GraphicalElement>list){
		super(env,uniqueStyle,classStyle);
		m_elements=list;
		m_offset=new Point_Euclidean(0,0,0);
		for(GraphicalElement elem:m_elements){
			elem.setParent(this);
		}
	}
	public InterfaceElement_Panel(ScriptEnvironment env, Stylesheet uniqueStyle, Stylesheet classStyle){
		this(env,uniqueStyle,classStyle,new LinkedList<GraphicalElement>());
	}
	public InterfaceElement getContainerElement(){return this;}
	public void clear(){m_elements.clear();}
	public void add(GraphicalElement element){
		m_elements.add(element);
		element.setParent(this);
	}
	public List<GraphicalElement>getElements(){return Collections.unmodifiableList(m_elements);}
	public void setPreferredWidth(int width){}
	public Point_Absolute getOffset(){return m_offset;}
	public void paint(Graphics2D g2d){
		assert Debugger.openNode("Painting Panel Elements: "+m_elements.size()+" element(s)");
		super.paint(g2d);
		assert Debugger.addNode("X-offset: "+m_offset.getX());
		assert Debugger.addNode("Y-offset: "+m_offset.getY());
		assert Debugger.addNode("Zoom factor: "+m_offset.getZ());
		for(GraphicalElement elem:m_elements){
			elem.paint(g2d);
		}
		assert Debugger.closeNode();
	}
	public boolean isFocusable(){return true;}
	public void riffMouseEvent(RiffInterface_MouseEvent event){
		if(event instanceof RiffInterface_DragEvent){
			if(event.getButton()==RiffInterface_MouseListener.MouseButton.LEFT){
				m_offset.addX(-((RiffInterface_DragEvent)event).getXOffset()/Math.pow(2,m_offset.getZ()));
				m_offset.addY(-((RiffInterface_DragEvent)event).getYOffset()/Math.pow(2,m_offset.getZ()));
				getRoot().repaint();
			}
			if(event.getButton()==RiffInterface_MouseListener.MouseButton.RIGHT){
				m_offset.addZ(((RiffInterface_DragEvent)event).getDistance()/50);
				getRoot().repaint();
			}
		}
	}
	public boolean nodificate(){
		assert Debugger.openNode("Panel Interface Element");
		assert super.nodificate();
		assert Debugger.addSnapNode("Graphical Elements: (" + m_elements.size() +" element(s))",m_elements);
		assert Debugger.closeNode();
		return true;
	}
}
