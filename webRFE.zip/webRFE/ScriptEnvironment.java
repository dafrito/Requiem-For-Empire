import java.util.*;
import javax.swing.JOptionPane;
public class ScriptEnvironment implements Nodeable{
	private Map<String,ScriptValueType>m_variableTypes=new HashMap<String,ScriptValueType>(); // Map of variable-Types(Variable-type-name, short)
	private Map<String,ScriptTemplate_Abstract>m_templates=new HashMap<String,ScriptTemplate_Abstract>(); // Map of object templates(Short,ScriptTemplate)
	private Stack<Stack<Map<String,ScriptValue_Variable>>>m_variableStack=new Stack<Stack<Map<String,ScriptValue_Variable>>>(); // Stack of maps of variables in use
	private Stack<ScriptTemplate_Abstract>m_objectStack=new Stack<ScriptTemplate_Abstract>(); // Stack of called objects
	private Stack<ScriptFunction_Abstract>m_functionStack=new Stack<ScriptFunction_Abstract>(); // Stack of called functions
	private RiffDeveloper m_developer;
	public ScriptEnvironment(RiffDeveloper developer){
		m_developer=developer;
	}
	public void resetEnvironment(){
		assert Debugger.openNode("Resetting Environment");
		m_developer.reset();
		
		m_variableTypes.clear();
		m_templates.clear();
		
		m_variableStack.clear();
		m_objectStack.clear();
		m_functionStack.clear();
		System.gc();
		initialize();
		assert Debugger.closeNode();
	}
	public void initialize(){
		try{
			assert Debugger.openNode("Initializing Script Environment");
			// Internal variables
			ScriptValueType.initialize(this);
			// Faux object templates
			FauxTemplate template=new FauxTemplate_Object(this);
			addType(null,FauxTemplate_Object.OBJECTSTRING,template);
			template=new FauxTemplate_Interface(this,m_developer.getRoot());
			addType(null,FauxTemplate_Interface.INTERFACESTRING,template);
			template=new FauxTemplate_InterfaceElement(this);
			addType(null,FauxTemplate_InterfaceElement.INTERFACEELEMENTSTRING,template);
			template=new FauxTemplate_Label(this);
			addType(null,FauxTemplate_Label.LABELSTRING,template);
			template=new FauxTemplate_Rectangle(this);
			addType(null,FauxTemplate_Rectangle.RECTANGLESTRING,template);
			template=new FauxTemplate_GraphicalElement(this);
			addType(null,FauxTemplate_GraphicalElement.GRAPHICALELEMENTSTRING,template);
			template=new FauxTemplate_Point(this);
			addType(null,FauxTemplate_Point.POINTSTRING,template);
			template=new FauxTemplate_Line(this);
			addType(null,FauxTemplate_Line.LINESTRING,template);
			template=new FauxTemplate_Panel(this);
			addType(null,FauxTemplate_Panel.PANELSTRING,template);
			template=new FauxTemplate_DiscreteRegion(this);
			addType(null,FauxTemplate_DiscreteRegion.DISCRETEREGIONSTRING,template);
			Iterator iter=m_templates.values().iterator();
			assert Debugger.closeNode();
		}catch(Exception_Nodeable ex){
			assert false:ex;
			assert Debugger.closeNodeTo("Initializing Script Environment");
		}
	}
	public void execute(){
		try{
			assert Debugger.openNode("Executing Script-Environment (Default Run)");
			Iterator iter=m_templates.values().iterator();
			while(iter.hasNext()){
				((ScriptTemplate_Abstract)iter.next()).initialize();
			}
			List<ScriptValue_Abstract>params=new LinkedList<ScriptValue_Abstract>();
			if(m_developer.getDebugger().getPriorityExecutingClass()!=null){
				if(getTemplate(m_developer.getDebugger().getPriorityExecutingClass())!=null&&getTemplate(m_developer.getDebugger().getPriorityExecutingClass()).getFunction("main",params)!=null){
					ScriptExecutable_CallFunction.callFunction(this,null,getTemplate(m_developer.getDebugger().getPriorityExecutingClass()),"main",params);
					return;
				}
			}
			ScriptFunction_Abstract function;
			List<String>templateNames=new LinkedList<String>();
			iter=m_templates.entrySet().iterator();
			while(iter.hasNext()){
				Map.Entry entry=(Map.Entry)iter.next();
				if((function=((ScriptTemplate_Abstract)entry.getValue()).getFunction("main",params))!=null){
					templateNames.add((String)entry.getKey());
				}
			}
			if(templateNames.size()==0){assert Debugger.closeNode();JOptionPane.showMessageDialog(null,"No classes compiled are executable.","No Executable Class",JOptionPane.WARNING_MESSAGE);return;}
			Object selection;
			if(templateNames.size()>1){
				selection=JOptionPane.showInputDialog(null,"Select the appropriate class to run from","Multiple Executable Classes",JOptionPane.QUESTION_MESSAGE,null,templateNames.toArray(),templateNames.get(0));
			}else{
				selection=templateNames.get(0);
			}
			if(selection==null){assert Debugger.closeNode();return;}
			m_developer.getDebugger().setPriorityExecutingClass((String)selection);
			assert Debugger.addNode(this);
			ScriptExecutable_CallFunction.callFunction(this,null,getTemplate((String)selection),"main",params);
			m_developer.repaint();
			assert Debugger.ensureCurrentNode("Executing Script-Environment (Default Run)");
			assert Debugger.closeNode();
		}catch(Exception_Nodeable ex){
			Debugger.printException(ex);
			assert Debugger.closeNodeTo("Executing Script-Environment (Default Run)");
		}catch(Exception_InternalError ex){
			Debugger.printException(ex);
			assert Debugger.closeNodeTo("Executing Script-Environment (Default Run)");
		}
	}
	// Stack functions
	public void advanceNestedStack()throws Exception_Nodeable{
		assert Debugger.openNode("Stack Advancements and Retreats","Advancing Nested Stack (Nested stack size before advance: " + m_variableStack.peek().size()+")");
		m_variableStack.peek().push(new HashMap<String,ScriptValue_Variable>());
		assert Debugger.closeNode();
	}
	public void retreatNestedStack()throws Exception_Nodeable{
		assert m_variableStack.size()>0;
		assert Debugger.openNode("Stack Advancements and Retreats","Retreating Nested Stack (Nested stack size before retreat: " + m_variableStack.peek().size()+")");
		m_variableStack.peek().pop();
		assert Debugger.closeNode();
	}
	public void advanceStack(ScriptTemplate_Abstract template,ScriptFunction_Abstract fxn)throws Exception_Nodeable{
		assert Debugger.openNode("Stack Advancements and Retreats","Advancing Stack (Stack size before advance: " + m_functionStack.size()+")");
		assert (m_functionStack.size()==m_objectStack.size())&&(m_objectStack.size()==m_variableStack.size()):"Stacks unequal: Function-stack: " + m_functionStack.size() + " Object-stack: " + m_objectStack.size() + " Variable-stack: " + m_variableStack.size();
		if(template!=null){assert Debugger.addSnapNode("Advancing object",template);}
		assert Debugger.addSnapNode("Advancing function",fxn);
		if(template==null){template=getCurrentObject();}
		if(template!=null){m_objectStack.push((ScriptTemplate_Abstract)template.getValue());
		}else{m_objectStack.push(null);}
		m_functionStack.push(fxn);
		m_variableStack.push(new Stack<Map<String,ScriptValue_Variable>>());
		m_variableStack.peek().push(new HashMap<String,ScriptValue_Variable>());
		assert Debugger.closeNode();
	}
	public void retreatStack(){
		assert Debugger.openNode("Stack Advancements and Retreats","Retreating Stack (Stack size before retreat: " + m_functionStack.size()+")");
		assert (m_functionStack.size()==m_objectStack.size())&&(m_objectStack.size()==m_variableStack.size()):"Stacks unequal: Function-stack: " + m_functionStack.size() + " Object-stack: " + m_objectStack.size() + " Variable-stack: " + m_variableStack.size();
		if(m_variableStack.size()>0){m_variableStack.pop();}
		if(m_objectStack.size()>0){m_objectStack.pop();}
		if(m_functionStack.size()>0){m_functionStack.pop();}
		if(m_objectStack.size()>0){assert Debugger.addSnapNode("New Current Object",m_objectStack.peek());}
		if(m_functionStack.size()>0){assert Debugger.addSnapNode("New Current Function",m_functionStack.peek());}
		assert Debugger.closeNode();
	}
	public ScriptFunction_Abstract getCurrentFunction(){
		if(m_functionStack.size()==0){throw new Exception_InternalError("No call stack");}
		return m_functionStack.peek();
	}
	public ScriptTemplate_Abstract getCurrentObject(){
		if(m_objectStack.size()==0){throw new Exception_InternalError("No call stack");}
		return m_objectStack.peek();
	}
	public Map<String,ScriptValue_Variable>getCurrentVariableStack(){
		if(m_variableStack.size()==0){throw new Exception_InternalError("No call stack");}
		return m_variableStack.peek().peek();
	}
	public ScriptValue_Variable getVariableFromStack(String name){
		Iterator iter=((Stack)m_variableStack.peek()).iterator();
		while(iter.hasNext()){
			Map map=(Map)iter.next();
			if(map.containsKey(name)){return (ScriptValue_Variable)map.get(name);}
		}
		return null;
	}
	public void addVariableToStack(String name,ScriptValue_Variable var)throws Exception_Nodeable{
		if(var==null){assert Debugger.openNode("Undefined Variable Stack Additions","Adding Undefined Variable to the Stack ("+name+")");
		}else{
			assert Debugger.openNode("Variable Stack Additions","Adding Variable to the Stack ("+name+")");
			assert Debugger.addNode(var);
		}
		assert Debugger.addSnapNode("Current Stack Status",m_variableStack);
		getCurrentVariableStack().put(name,var);
		assert Debugger.closeNode();
	}
	// Variable functions
	public ScriptValue_Variable retrieveVariable(String name)throws Exception_Nodeable{
		assert Debugger.openNode("Variable Retrievals","Retrieving Variable ("+name+")");
		ScriptValue_Variable value=null;
		if(value==null){
			assert Debugger.addSnapNode("Checking current variable stack",m_variableStack);
			value=getVariableFromStack(name);
		}
 		if(value==null){
			assert Debugger.openNode("Checking current object for valid variable");
			assert Debugger.addNode(getCurrentObject());
			value=getCurrentObject().getVariable(name);
			assert Debugger.closeNode();
		}
		if(value==null){
			assert Debugger.openNode("Checking static template stack");
			assert Debugger.addNode(getTemplate(name));
			if(getTemplate(name)!=null){value=getTemplate(name).getStaticReference();}
			assert Debugger.closeNode();
		}
		if(value==null){assert Debugger.addNode("Value not found");
		}else{assert Debugger.addSnapNode("Value found",value);}
		assert Debugger.closeNode();
		return value;
	}
	// Variable-type functions
	public void addType(Referenced ref,String name)throws Exception_Nodeable{addType(ref,name,new ScriptValueType(this));}
	public void addType(Referenced ref,String name,ScriptValueType keyword) throws Exception_Nodeable{
		assert Debugger.addNode("Variable-Type Additions","Adding variable type name to the variable-map ("+name+")");
		if(m_variableTypes.get(name)!=null){throw new Exception_Nodeable_VariableTypeAlreadyDefined(ref,name);}
		m_variableTypes.put(name,keyword);
	}
	public ScriptValueType getType(String name){return m_variableTypes.get(name);}
	public String getName(ScriptValueType keyword){
		assert keyword!=null;
		Iterator iter=m_variableTypes.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry=(Map.Entry)iter.next();
			if(keyword.equals(entry.getValue())){return(String)entry.getKey();}
		}
		throw new Exception_InternalError(this,"Name not found for keyword");
	}
	public void addType(Referenced ref,String name,ScriptTemplate_Abstract template)throws Exception_Nodeable{
		addType(ref,name);
		addTemplate(ref,name,template);
	}
	// Template functions
	public void addTemplate(Referenced ref,String name,ScriptTemplate_Abstract template)throws Exception_Nodeable{
		if(m_templates.get(name)!=null){throw new Exception_Nodeable_TemplateAlreadyDefined(ref,name);}
		m_templates.put(name,template);
	}
	public ScriptTemplate_Abstract getTemplate(ScriptValueType code){return getTemplate(getName(code));}
	public ScriptTemplate_Abstract getTemplate(String name){return m_templates.get(name);}
	public boolean isTemplateDefined(String name){return m_templates.get(name)!=null;}
	// Miscellaneous functions
	public boolean nodificate(){
		assert Debugger.openNode("Script Environment");
		assert Debugger.addSnapNode("Templates: " + m_templates.size() + " templates(s)",m_templates);
		assert Debugger.openNode("Current variable-stack (" + m_variableStack.size() + " variable stack(s))");
		for(Stack<Map<String,ScriptValue_Variable>>varStack:m_variableStack){
			assert Debugger.openNode("Variable Stack ("+varStack.size()+" nested stack(s))");
			for(Map<String,ScriptValue_Variable>varMap:varStack){
				assert Debugger.addSnapNode("Nested Variable Stack ("+varMap.entrySet().size()+" variable(s))",varMap);
			}
			assert Debugger.closeNode();
		}
		assert Debugger.closeNode();
		assert Debugger.addSnapNode("Current object-stack (" + m_objectStack.size() + " called-object(s))",m_objectStack);
		assert Debugger.addSnapNode("Current function-stack (" + m_functionStack.size() + " called-function(s))",m_functionStack);
		assert Debugger.closeNode();
		return true;
	}
}
