public class ScriptExecutable_AddFunctionToObject extends ScriptElement implements ScriptExecutable,Nodeable{
	private ScriptFunction_Abstract m_function;
	private String m_name;
	public ScriptExecutable_AddFunctionToObject(Referenced ref,String name,ScriptFunction_Abstract fxn){
		super(ref);
		m_name=name;
		m_function=fxn;
	}
	// ScriptExecutable implementation
	public ScriptValue_Abstract execute()throws Exception_Nodeable{
		getEnvironment().getCurrentObject().addFunction(this,m_name,m_function);
		return null;
	}
	// Nodeable implementation
	public boolean nodificate(){
		assert Debugger.openNode("Member-Function Addition ("+ScriptFunction.getDisplayableFunctionName(m_name)+")");
		assert super.nodificate();
		assert Debugger.addSnapNode("Function",m_function);
		assert Debugger.closeNode();
		return true;
	}
}
