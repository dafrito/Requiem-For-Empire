import java.util.*;

public class Stylesheet extends FauxTemplate implements Nodeable,ScriptValue_Abstract{
	private Map<StylesheetElementType,StylesheetElement>m_styleElements=new HashMap<StylesheetElementType,StylesheetElement>(); // element code, element
	private ScriptEnvironment m_environment;
	private String m_name;
	private boolean m_isUnique;
	public Stylesheet(ScriptEnvironment env, String name,boolean isUnique){
		super(env,ScriptValueType.STYLESHEET,ScriptValueType.getObjectType(env),new LinkedList<ScriptValueType>());
		m_environment=env;
		m_name=name;
		m_isUnique=isUnique;
	}
	public boolean isUnique(){return m_isUnique;}
	public ScriptValue_Abstract execute(Referenced ref, String name, List<ScriptValue_Abstract>params,ScriptTemplate_Abstract template)throws Exception_Nodeable{
		return null;
	}
	public void addElement(StylesheetElementType type, StylesheetElement element){
		assert Debugger.openNode("Stylesheet Element Additions", "Adding a" + element.getElementName() + " element to this stylesheet");
		assert Debugger.addNode(this);
		assert Debugger.addNode(element);
		m_styleElements.put(type,element);
		assert Debugger.closeNode();
	}
	public StylesheetElement getElement(StylesheetElementType elementCode){return m_styleElements.get(elementCode);}
	public String getName(){return m_name;}
	// Abstract-value implementation
	public ScriptEnvironment getEnvironment(){return m_environment;}
	public ScriptValueType getType(){return ScriptValueType.STYLESHEET;}
	public boolean isConvertibleTo(ScriptValueType type){return type.equals(getType());}
	public ScriptValue_Abstract castToType(Referenced ref,ScriptValueType type)throws Exception_Nodeable{
		if(!type.equals(getType())){throw new Exception_Nodeable_ClassCast(ref,this,type);}
		return this;
	}
	public ScriptValue_Abstract getValue()throws Exception_Nodeable{return this;}
	public boolean nodificate(){
		if(m_name==null){assert Debugger.openNode("Anonymous stylesheet (" + m_styleElements.size() + " element(s))");
		}else{assert Debugger.openNode("Stylesheet: " + m_name + " ("  + m_styleElements.size() + " element(s))");}
		assert Debugger.addNode(m_styleElements.values());
		assert Debugger.closeNode();
		return true;
	}
}
