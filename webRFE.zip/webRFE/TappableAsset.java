import java.util.*;
public class TappableAsset extends ActiveAsset{
	private Brand m_lotToCreate;
	private List<Asset>m_returnableAssets;
	public TappableAsset(ActiveAsset asset, Point point, Brand brand, List<Asset>returnables){
		super(asset,point);
		m_lotToCreate=brand;
		if(returnables==null){
			m_returnableAssets=new LinkedList<Asset>();
		}else{
			m_returnableAssets=new LinkedList<Asset>(returnables);
		}
	}
	public TappableAsset(ActiveAsset asset, Brand brand){
		this(asset,asset.getPosition(),brand,null);
	}
	public TappableAsset(Point point,Brand brand){
		this(null,point,brand,null);
	}
	public TappableAsset(TappableAsset otherAsset){
		this(otherAsset.getParent(), otherAsset.getPosition(), otherAsset.getBrand(), otherAsset.getReturnableAssets());
	}
	public Integer getAssetType(){return Asset.TAPPABLEASSET;}
	public boolean isAssetOfType(Integer type){return(type.equals(getAssetType())||super.isAssetOfType(type));}
	public List<Asset> getReturnableAssets(){return m_returnableAssets;}
	public boolean isUnique(){return false;}
	public Brand getBrand(){return m_lotToCreate;}
	public Object clone(){return new TappableAsset(this);}
	public boolean mergeAsset(Asset asset){return false;}
	public void iterate(double iterationTime){}
	public List tap(double iterationTime) throws OrderException{
		if(m_returnableAssets != null){
			m_returnableAssets.clear();
		}
		QuantityProductionOrder order = new QuantityProductionOrder(this, m_lotToCreate, -1);
		order.execute();
		return m_returnableAssets;
	}
	/* TODO: Nodificate
	public String toString(){
		String string = new String();
		string += "Tappable Asset: ";
		string += "\nAssets: " + m_assetMap;
		string += "\nLot to create: " + m_lotToCreate;
		return string;
	}*/
}
