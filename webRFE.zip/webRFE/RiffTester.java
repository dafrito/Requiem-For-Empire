/*import java.util.*;
public class RiffTester{
	public static void print(String string){System.out.println(string);}
	public static void getIntersectionDiagnostic(){
		print("Testing getIntersection: getIntersection(RiffAbsolutePOint, Point_Absolute, Point_Absolute, Point_Absolute)");
		Point_Absolute pointA,pointB,pointC,pointD;
		IntersectionPoint intersectionPoint;
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==2.5d&&intersectionPoint.getPoint().getY()==2.5d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(intersectionPoint!=null){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		pointD = new Point_Euclidean(4.0d, 4.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(intersectionPoint!=null){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointD = new Point_Euclidean(10.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==5.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(2.5d, 2.5d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==2.5d&&intersectionPoint.getPoint().getY()==2.5d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointD = new Point_Euclidean(0.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointD = new Point_Euclidean(5.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointD = new Point_Euclidean(5.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(-2.0d, 2.0d, 0.0d);
		pointD = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 2.0d, 0.0d);
		pointD = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		pointC = new Point_Euclidean(2.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(2.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==0.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		pointC = new Point_Euclidean(2.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(2.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointC, pointD, pointA, pointB);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==0.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 2.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 2.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
		pointA = new Point_Euclidean(0.0d, 2.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 2.0d, 0.0d);
		pointC = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointC, pointD, pointA, pointB);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			print("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			print("Failed.");
			print("IntersectPoint: " + intersectionPoint);
		}
	}
	public static void testPointAgainstLineDiagnostic(){
		print("Testing one-line point-side test: testPointAgainstLine(Point_Absolute, Point_Absolute, Point_Absolute)");
		Point_Absolute pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		Point_Absolute pointB = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		Point_Absolute pointC = new Point_Euclidean(2.0d, 1.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(2.0d, 0.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(2.0d,-1.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = new Point_Euclidean(2.0d, 5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(2.0d, -5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointA = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointC = new Point_Euclidean(2.0d, 5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(2.0d, -5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointA = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointC = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(-2.0d, -2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
		pointC = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			print("failed.");
			print("Value: " + value);
			break;
		}
	}
	public static void getPointSideTest_RegionPointDiagnostic(){
		print("Testing region-point point-side test: getPointSideTest(DiscreteRegion, Point_Absolute)");
		DiscreteRegion region = new DiscreteRegion();
		region.addPoint(new Point_Euclidean(0.0d, 0.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 0.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 5.0d, 0.0d));
		region.addPoint(new Point_Euclidean(0.0d, 5.0d, 0.0d));
		Point_Absolute testPoint = new Point_Euclidean(2.0d, 2.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, testPoint);
			if(!array[0].isEmpty()&&array[1].isEmpty()&&array[2].isEmpty()){
				if(array[0].contains(testPoint)&&array[0].size()==4){break;}
			}
			print("Testing this point " + testPoint + " against this region: " + region);
			print("Failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
		testPoint = new Point_Euclidean(2.0d, 5.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, testPoint);
			if(array[0].size()==3&&array[2].size()==1&&array[1].isEmpty()){break;}
			print("Testing this point " + testPoint + " against this region: " + region);
			print("Failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
		testPoint = new Point_Euclidean(2.0d, 7.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, testPoint);
			if(array[0].size()==3&&array[2].size()==0&&array[1].size()==1){break;}
			print("Testing this point " + testPoint + " against this region: " + region);
			print("Failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
	}
	public static void getPointSideTest_RegionLineDiagnostic(){
		print("Testing region-line point-side test: getPointSideTest(DiscreteRegion, Point_Absolute, Point_Absolute)");
		DiscreteRegion region = new DiscreteRegion();
		region.addPoint(new Point_Euclidean(0.0d, 0.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 0.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 5.0d, 0.0d));
		region.addPoint(new Point_Euclidean(0.0d, 5.0d, 0.0d));
		Point_Absolute pointA = new Point_Euclidean(2.0d, 0.0d, 0.0d);
		Point_Absolute pointB = new Point_Euclidean(2.0d, 5.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, pointA, pointB);
			if(array[0].size()==2&&array[1].size()==2&&array[2].size()==0){break;}
			print("Testing these points (" + pointA + ", " + pointB + ") against this region: " + region);
			print("Failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, pointA, pointB);
			if(array[0].size()==1&&array[1].size()==1&&array[2].size()==2){break;}
			print("Testing these points (" + pointA + ", " + pointB + ") against this region: " + region);
			print("Failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
		pointA = new Point_Euclidean(0.0d, 7.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 7.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, pointA, pointB);
			if(array[0].size()==0&&array[1].size()==4&&array[2].size()==0){break;}
			print("Testing these points (" + pointA + ", " + pointB + ") against this region: " + region);
			print("Failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
	}
	public static void getPointSideTest_TwoLineDiagnostic(){
		print("Testing two-line point-side test: getPointSideTest(Point_Absolute, Point_Absolute, Point_Absolute, Point_Absolute)");
		Point_Absolute pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		Point_Absolute pointB = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		Point_Absolute pointC = new Point_Euclidean(2.0d, -1.0d, 0.0d);
		Point_Absolute pointD = new Point_Euclidean(7.0d, -1.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(pointA,pointB,pointC,pointD);
			if(array[0].isEmpty()&&!array[1].isEmpty()&&array[2].isEmpty()){
				if(array[1].contains(pointC)&&array[1].contains(pointD)&&array[1].size()==2){break;}
			}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ", " + pointD + ")...");
			print("failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
		pointC = new Point_Euclidean(2.0d, 0.0d, 0.0d);
		pointD = new Point_Euclidean(7.0d, 0.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(pointA,pointB,pointC,pointD);
			if(array[0].isEmpty()&&array[1].isEmpty()&&!array[2].isEmpty()){
				if(array[2].contains(pointC)&&array[2].contains(pointD)&&array[2].size()==2){break;}
			}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ", " + pointD + ")...");
			print("failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
		pointC = new Point_Euclidean(2.0d, 1.0d, 0.0d);
		pointD = new Point_Euclidean(7.0d, 1.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(pointA,pointB,pointC,pointD);
			if(!array[0].isEmpty()&&array[1].isEmpty()&&array[2].isEmpty()){
				if(array[0].contains(pointC)&&array[0].contains(pointD)&&array[0].size()==2){break;}
			}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ", " + pointD + ")...");
			print("failed.");
			print("Left-side list: " + array[0]);
			print("Right-side list: " + array[1]);
			print("Indeterminate-side list: " + array[2]);
			break;
		}
	}
	public static void getMidPointOfLineDiagnostic(){
		print("Testing midpoint-creation diagnostic: getMidPointOfLine(Point_Absolute, Point_Absolute)");
		Point_Absolute pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		Point_Absolute pointB = new Point_Euclidean(5.0d, 0.0d, 0.0d);
		Point_Absolute pointC = RiffPolygonToolbox.getMidPointOfLine(pointA, pointB);
		if(!(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getX(),2.5d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getY(),0.0d))){
			print("Finding the midpoint of these points: " + pointA + ", " + pointB);
			print("Failed.");
			print("Midpoint returned: " + pointC);
		}
		pointA = new Point_Euclidean(0.0d, 5.0d, 0.0d);
		pointB = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointC = RiffPolygonToolbox.getMidPointOfLine(pointA, pointB);
		if(!(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getX(),0.0d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getY(),2.5d))){
			print("Finding the midpoint of these points: " + pointA + ", " + pointB);
			print("Failed.");
			print("Midpoint returned: " + pointC);
		}
		pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		pointB = new Point_Euclidean(5.0d, 5.0d, 0.0d);
		pointC = RiffPolygonToolbox.getMidPointOfLine(pointA, pointB);
		if(!(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getX(),2.5d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getY(),2.5d))){
			print("Finding the midpoint of these points: " + pointA + ", " + pointB);
			print("Failed.");
			print("Midpoint returned: " + pointC);
		}
	}
	public static void assertCCWPolygonDiagnostic(){
		print("Testing region-line point-side test: assertCCWPolygon(DiscreteRegion)");
		DiscreteRegion region = new DiscreteRegion();
		Point_Absolute pointA = new Point_Euclidean(0.0d, 0.0d, 0.0d);
		region.addPoint(pointA);
		region.addPoint(new Point_Euclidean(0.0d, 0.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 0.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 5.0d, 0.0d));
		region.addPoint(new Point_Euclidean(0.0d, 5.0d, 0.0d));
		RiffPolygonToolbox.assertCCWPolygon(region);
		List points = region.getPoints();
		if(!points.get(0).equals(pointA)){
			print("Testing this region for CCW-behavior: " + region);
			print("Failed.");
		}
		region = new DiscreteRegion();
		region.addPoint(new Point_Euclidean(0.0d, 5.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 5.0d, 0.0d));
		region.addPoint(new Point_Euclidean(5.0d, 0.0d, 0.0d));
		region.addPoint(pointA);
		RiffPolygonToolbox.assertCCWPolygon(region);
		points = region.getPoints();
		if(!points.get(0).equals(pointA)){
			print("Testing this region for CCW-behavior: " + region);
			print("Failed.");
		}
	}
	public static void polygonDiagnostic(){
		print("Diagnostics now running for the module: Polygons");
		testPointAgainstLineDiagnostic();
		getPointSideTest_TwoLineDiagnostic();
		getPointSideTest_RegionPointDiagnostic();
		getPointSideTest_RegionLineDiagnostic();
		getMidPointOfLineDiagnostic();
		assertCCWPolygonDiagnostic();
		getIntersectionDiagnostic();
		//RiffPolygonToolbox.testForColinearity(new Point_Euclidean("A", null, 25.0, 25.0, 0), new Point_Euclidean("B", null, 75.0, 75.0, 0), new Point_Euclidean("C", null, 50.0, 50.0, 0), new Point_Euclidean("D", null, 100.0, 100.0, 0));
	}
	public static void main(String[]args){
		print(" *** Requiem for Empire Self-Diagnostic ***\n");
		polygonDiagnostic();
	}
}*/
