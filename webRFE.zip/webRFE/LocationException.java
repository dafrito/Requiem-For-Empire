public class LocationException extends Exception{};
