import java.util.*;
import java.awt.Color;
public class Pathfinder{
	private DiscreteRegion m_start, m_destination;
	private List<DiscreteRegion>m_usedList;
	private List<DiscreteRegion>m_pathList;
	private List<Point_Absolute>m_route;
	private Point_Absolute m_sourcePoint, m_destinationPoint;
	public Pathfinder(DiscreteRegionBSPNode root, Point_Absolute startPoint, Point_Absolute endPoint){
		this(root.findPolygon(startPoint), startPoint, root.findPolygon(endPoint), endPoint);
	}
	public Pathfinder(DiscreteRegion start, Point_Absolute startPoint, DiscreteRegion destination, Point_Absolute endPoint){
		m_start=start;
		m_destination=destination;
		m_sourcePoint=startPoint;
		m_destinationPoint=endPoint;
		m_usedList=new LinkedList<DiscreteRegion>();
		m_pathList=new LinkedList<DiscreteRegion>();
		m_route=new LinkedList<Point_Absolute>();
	}
	public List<Point_Absolute>getRoute(){
		assert Debugger.printDebug("Pathfinder/getRoute");
		DiscreteRegion chosenRegion = m_start;
		Point_Absolute currentPoint = m_sourcePoint;
		if(m_start.equals(m_destination)){
			assert Debugger.printDebug("Pathfinder/getRoute", "Start polygon and destination polygon are equal, returning empty list.");
			return m_route;
		}
		assert Debugger.printDebug("Pathfinder/getRoute", "Destination: " + m_destination);
		m_route.add(m_sourcePoint);
		int ticker=0;
		while(!chosenRegion.equals(m_destination)){
			if(ticker>100){
				assert Debugger.printDebug("Pathfinder/getRoute", "Emergency failure.");
				return null;
			}
			ticker++;
			assert Debugger.printDebug("Pathfinder/getRoute", "\n\nPathfinder is iterating...(Iteration " + ticker + ")");
			assert Debugger.printDebug("Pathfinder/getRoute/data", "Current region: " + chosenRegion);
			Iterator neighborIter = chosenRegion.getNeighbors().iterator();
			if(chosenRegion.getNeighbors().size()==0){
				return null;
			}
			Map<DiscreteRegion,Point_Absolute>neighborsMap = new HashMap<DiscreteRegion,Point_Absolute>();
			while(neighborIter.hasNext()){
				DiscreteRegion neighbor = (DiscreteRegion)neighborIter.next();
				if(m_usedList.contains(neighbor)){continue;}
				assert Debugger.printDebug("Pathfinder/getRoute", "Placing neighbor in neighbor-map: "+neighbor);
				Point_Absolute[]line=RiffPolygonToolbox.getAdjacentEdge(chosenRegion, neighbor);
				Point_Absolute point=RiffPolygonToolbox.getMinimumPointBetweenLine(line[0], line[1], currentPoint);
				if(!point.equals(currentPoint)){neighborsMap.put(neighbor, point);}
			}
			if(neighborsMap.isEmpty()){
				assert Debugger.printDebug("Pathfinder/getRoute", "Stepping back.");
				if(chosenRegion==m_start){return null;}
				m_route.remove(m_route.size()-1);
				m_usedList.add(chosenRegion);
				chosenRegion=m_pathList.get(m_pathList.size()-1);
				m_pathList.remove(m_pathList.size()-1);
				continue;
			}
			Map<DiscreteRegion,Double>valueMap = new HashMap<DiscreteRegion,Double>();
			for(Map.Entry entry:neighborsMap.entrySet()){
				valueMap.put((DiscreteRegion)entry.getKey(),getValue(currentPoint,(Point_Absolute)entry.getValue(),(DiscreteRegion)entry.getKey()));
			}
			double minimumValue=Double.POSITIVE_INFINITY;
			DiscreteRegion optimumRegion=null;
			for(Map.Entry entry:valueMap.entrySet()){
				DiscreteRegion contestingRegion=(DiscreteRegion)entry.getKey();
				double thisValue=((Double)entry.getValue()).doubleValue();
				assert Debugger.printDebug("Pathfinder/getRoute", contestingRegion.getName() + "'s Value: " + thisValue);
				if(RiffToolbox.isLessThan(thisValue,minimumValue)){
					minimumValue=thisValue;
					optimumRegion=(DiscreteRegion)contestingRegion;
				}else if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, thisValue,minimumValue)){
					assert Debugger.printDebug("Pathfinder/getRoute", "Contestng region: " + contestingRegion.getName() + ", " + optimumRegion.getName());
					if(RiffToolbox.isLessThan(getValue(currentPoint, contestingRegion.getBoundingRectMidPoint(),contestingRegion).doubleValue(),getValue(currentPoint, optimumRegion.getBoundingRectMidPoint(),optimumRegion).doubleValue())){
						optimumRegion=contestingRegion;
						minimumValue=((Double)entry.getValue()).doubleValue();
					}
				}
			}
			if(optimumRegion==null){
				assert Debugger.printDebug("Pathfinder/getRoute", "Stepping back.");
				if(chosenRegion==m_start){return null;}
				m_route.remove(m_route.size()-1);
				m_usedList.add(chosenRegion);
				chosenRegion=m_pathList.get(m_pathList.size()-1);
				m_pathList.remove(m_pathList.size()-1);
				continue;
			}
			currentPoint=neighborsMap.get(optimumRegion);
			m_route.add(currentPoint);
			assert Debugger.printDebug("Pathfinder/getRoute", "Adding to used list: " + chosenRegion);
			m_usedList.add(chosenRegion);
			m_pathList.add(chosenRegion);
			chosenRegion=optimumRegion;
		}
		m_route.add(m_destinationPoint);
		m_pathList.add(m_destination);
		for(DiscreteRegion region:m_pathList){region.setColor(Color.RED);}
		assert Debugger.printDebug("Pathfinder/getRoute",RiffToolbox.displayList(m_pathList));
		assert Debugger.printDebug("/Pathfinder/getRoute");
		return m_route;
	}
	private Double getValue(Point_Absolute source, Point_Absolute location, DiscreteRegion region){
		double sourceToLocation = RiffToolbox.getDistance(source, location);
		double locToDestination = RiffToolbox.getDistance(location, m_destinationPoint);
		assert Debugger.printDebug("Pathfinder/getValue", "SourceToLoc: " +sourceToLocation);
		assert Debugger.printDebug("Pathfinder/getValue", "LocToDest: " +locToDestination);
		if(((Terrain)region.getAssetMap().getAsset(Asset.TERRAIN)).getBrushDensity()>0.0d){
			locToDestination=Double.POSITIVE_INFINITY;
		}
		return new Double(sourceToLocation+locToDestination);
	}
	/*public List getRoute(){
		assert Debugger.printDebug("Pathfinder/getRoute", "(getRoute)");
		DiscreteRegion chosenRegion = m_start;
		List route = new LinkedList();
		if(m_start.equals(m_destination)){
			assert Debugger.printDebug("Pathfinder/getRoute", "Start polygon and destination polygon are equal, returning empty list.");
			return route;
		}
		assert Debugger.printDebug("Pathfinder/getRoute", "Destination: " + m_destination);
		route.add(chosenRegion.getInteriorPoint());
		int ticker=0;
		while(!chosenRegion.equals(m_destination)){
			if(ticker>20){
				assert Debugger.printDebug("Pathfinder/getRoute", "Pathfinding iterator exceeded loop tolerance.");
				route.clear();break;
			}
			ticker++;
			assert Debugger.printDebug("Pathfinder/getRoute", "\nPathfinder is iterating...(Iteration " + ticker + ")");
			assert Debugger.printDebug("Pathfinder/getRoute/data", "Current region: " + chosenRegion);
			Map slopeList = new HashMap();
			Set neighbors = chosenRegion.getNeighbors();
			if(neighbors.size()==0){
				assert Debugger.printDebug("Pathfinder/getRoute", "No path available.");
				break;
			}else if(neighbors.contains(m_destination)){
				m_pathList.add(chosenRegion);
				chosenRegion=m_destination;
				m_pathList.add(chosenRegion);
				break;
			}
			assert Debugger.printDebug("Pathfinder/getRoute/data", "Neighbors list: " + RiffToolbox.displayList(neighbors));
			Iterator iter=neighbors.iterator();
			double optimumTheta = Math.tan((m_destination.getInteriorPoint().getY()-chosenRegion.getInteriorPoint().getY())/(m_destination.getInteriorPoint().getX()-chosenRegion.getInteriorPoint().getX()));
			assert Debugger.printDebug("Pathfinder/getRoute/data", "Optimum theta: " + optimumTheta + ", now generating delta-from-theta list.");
			assert Debugger.printDebug("Pathfinder/getRoute/data", "Interior point of destination: " + m_destination.getInteriorPoint());
			while(iter.hasNext()){
				DiscreteRegion region = (DiscreteRegion)iter.next();
				assert Debugger.printDebug("Pathfinder/getRoute/data", "Current region: " + region);
				assert Debugger.printDebug("Pathfinder/getRoute/data", "Interior point of current: " + region.getInteriorPoint());
				double regionsTheta = Math.tan((m_destination.getInteriorPoint().getY()-region.getInteriorPoint().getY())/(m_destination.getInteriorPoint().getX()-region.getInteriorPoint().getX()));
				assert Debugger.printDebug("Pathfinder/getRoute/data", "Current region's theta: " + regionsTheta);
				slopeList.put(new Double(Math.abs(optimumTheta-regionsTheta)), region);
			}
			double minValue = Double.POSITIVE_INFINITY;
			Double minimumTheta=null;
			iter=slopeList.entrySet().iterator();
			assert Debugger.printDebug("Pathfinder/getRoute", "Finding minimum-delta polygon..." + slopeList.size());
			while(iter.hasNext()){
				Map.Entry entry = (Map.Entry)iter.next();
				Double keyValue = ((Double)entry.getKey());
				assert Debugger.printDebug("Pathfinder/getRoute", "Region: " + slopeList.get(keyValue));
				if(minValue >= keyValue.doubleValue()){
					if(m_usedList.contains(entry.getValue())){
						assert Debugger.printDebug("Pathfinder/getRoute", "Used-list contains neighbor, continuing...");
						continue;
					}
					minimumTheta = keyValue;
					minValue = keyValue.doubleValue();
					assert Debugger.printDebug("Pathfinder/getRoute", "New minimum: " + minValue);
				}
			}
			if(minimumTheta==null){
				if(m_pathList.size()<=1){
					assert Debugger.printDebug("Pathfinder/getRoute", "All paths attempted, but none successful, returning.");
					route.clear();break;
				}
				chosenRegion=(DiscreteRegion)m_pathList.remove(m_pathList.size()-2);
				m_pathList.remove(m_pathList.size()-1);
				assert Debugger.printDebug("Pathfinder/getRoute", "Stepping back...");
				continue;
			}
			assert Debugger.printDebug("Pathfinder/getRoute", "Potential polygon found, setting chosen-region to it, and adding this region to our used list...");
			m_usedList.add(chosenRegion);
			m_pathList.add(chosenRegion);
			assert Debugger.printDebug("Pathfinder/getRoute", "Polygon list: " +RiffToolbox.displayList(m_pathList));
			chosenRegion=(DiscreteRegion)slopeList.get(minimumTheta);
		}
		if(chosenRegion.equals(m_destination)){
			assert Debugger.printDebug("Pathfinder/getRoute", "Route found.");
		}
		Iterator routeIter = m_pathList.iterator();
		while(routeIter.hasNext()){
			route.add(((DiscreteRegion)routeIter.next()).getInteriorPoint());
		}
		assert Debugger.printDebug("Pathfinder/getRoute", "Final route: " + route);
		assert Debugger.printDebug("Pathfinder/getRoute", "Final polygon list: " +RiffToolbox.displayList(m_pathList));
		assert Debugger.printDebug("Pathfinder/getRoute", "(/getRoute)");
		return route;
	}*/
}
