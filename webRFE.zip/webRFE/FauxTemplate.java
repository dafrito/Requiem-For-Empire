import java.util.*;
public abstract class FauxTemplate extends ScriptTemplate implements ScriptValue_Abstract{
	public FauxTemplate(ScriptEnvironment env,ScriptValueType type,ScriptValueType extended,List<ScriptValueType>implemented){
		super(env,type,extended,implemented);
	}
	public static List<ScriptValue_Abstract> createEmptyParamList(){return new LinkedList<ScriptValue_Abstract>();}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing INSERTFAUXTEMPLATENAMEHERE Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_InterfaceElement template=(FauxTemplate_InterfaceElement)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		assert false;return null;
	}
	public boolean nodificate(){
		assert Debugger.addNode("Notice: Non-static member functions and variables are not visible from uninstantiated faux templates.");
		super.nodificate();
		return true;
	}
	public void addConstructor(ScriptValueType returnType,List<ScriptValue_Abstract>params)throws Exception_Nodeable{addFauxFunction("",returnType,params,ScriptKeywordType.PUBLIC,false);}
	public void addFauxFunction(String name,ScriptValueType returnType,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)throws Exception_Nodeable{
		addFunction(null,name,new ScriptFunction_Faux(this,name,returnType,params,permission,isAbstract));
	}
	public void initializeFunctions()throws Exception_Nodeable{}
	public void addTemplatePreconstructorExpression(ScriptExecutable exec)throws Exception_Nodeable{throw new Exception_InternalError(getEnvironment(),"Invalid call in FauxTemplate");}
	public void addPreconstructorExpression(ScriptExecutable exec)throws Exception_Nodeable{throw new Exception_InternalError(getEnvironment(),"Invalid call in FauxTemplate");}
	public ScriptTemplate createObject(Referenced ref,ScriptTemplate object)throws Exception_Nodeable{return object;}
	public boolean valuesEqual(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{throw new Exception_InternalError(getEnvironment(),"Invalid call in FauxTemplate");}
	public int valuesCompare(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{throw new Exception_InternalError(getEnvironment(),"Invalid call in FauxTemplate");}
	public ScriptValue_Abstract setValue(Referenced ref, ScriptValue_Abstract value)throws Exception_Nodeable{throw new Exception_InternalError(getEnvironment(),"Invalid call in FauxTemplate");}
}
