	import java.util.*;
public class FauxTemplate_List extends FauxTemplate implements ScriptConvertible,Nodeable{
	public static final String LISTSTRING="List";
	private List<ScriptValue_Abstract>m_list=new LinkedList<ScriptValue_Abstract>();
	public FauxTemplate_List(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,LISTSTRING),ScriptValueType.getObjectType(env),new LinkedList<ScriptValueType>());
	}
	public FauxTemplate_List(ScriptEnvironment env,List<ScriptValue_Abstract>list){
		this(env);
		m_list=list;
	}
	public List<ScriptValue_Abstract>getList(){return m_list;}
	public void add(ScriptValue_Abstract object){m_list.add(object);}
	public void addAll(List<ScriptValue_Abstract>list){m_list.addAll(list);}
	public ScriptValue_Abstract get(int i){return m_list.get(i);}
	public int size(){return m_list.size();}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing List Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_List template=(FauxTemplate_List)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_List(getEnvironment());}
			((FauxTemplate)getExtendedClass()).execute(ref,name,new LinkedList<ScriptValue_Abstract>(),template);
			List<ScriptValue_Abstract>fxnParams=FauxTemplate.createEmptyParamList();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.getObjectType(getEnvironment())));
			template.addFauxFunction("add",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),getType()));
			template.addFauxFunction("addAll",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.INT));
			template.addFauxFunction("get",ScriptValueType.getObjectType(getEnvironment()),fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			template.addFauxFunction("size",ScriptValueType.INT,fxnParams,ScriptKeywordType.PUBLIC,false);
			assert Debugger.closeNode();
			return template;
		}else if(name.equals("add")){
			template.add(params.get(0).getValue());
			assert Debugger.closeNode();
			return null;
		}else if(name.equals("addAll")){
			template.addAll(Parser.getList(params.get(0)));
			assert Debugger.closeNode();
			return null;
		}else if(name.equals("get")){
			assert Debugger.closeNode();
			return template.get(Parser.getInteger(params.get(0)));
		}else if(name.equals("size")){
			assert Debugger.closeNode();
			return Parser.getRiffInt(getEnvironment(),template.size());
		}
		returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	// Convertible and Nodeable implementations
	public Object convert(){List<ScriptValue_Abstract>list=new LinkedList<ScriptValue_Abstract>();list.addAll(m_list);return list;}
	public boolean nodificate(){
		assert Debugger.openNode("List Faux Template");
		assert super.nodificate();
		assert Debugger.addSnapNode("Elements",m_list);
		assert Debugger.closeNode();
		return true;
	}
}
