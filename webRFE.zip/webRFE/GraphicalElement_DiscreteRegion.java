import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.util.*;
public class GraphicalElement_DiscreteRegion extends InterfaceElement implements GraphicalElement,ScriptConvertible,Nodeable{
	private DiscreteRegion m_region;
	private java.awt.Color m_color;
	public GraphicalElement_DiscreteRegion(ScriptEnvironment env,DiscreteRegion region){
		super(env,null,null);
		m_region=region;
	}
	public void setColor(java.awt.Color color){m_color=color;}
	public Rectangle getDrawingBounds(){
		return new Rectangle(getXAnchor()+getLeftMarginMagnitude()+getLeftBorderMagnitude(),getYAnchor()+getTopMarginMagnitude()+getTopBorderMagnitude(),getInternalWidth(),getInternalHeight());
	}
	public boolean isFocusable(){return false;}
	public void paint(Graphics2D g2d){
		assert Debugger.openNode("Discrete-Region Painting","Painting Discrete Region");
		assert Debugger.addNode(this);
		Point_Absolute offset;
		if(getParent()instanceof InterfaceElement_Panel){
			offset=((InterfaceElement_Panel)getParent()).getOffset();
		}else{
			offset=new Point_Euclidean(getXAnchor(),getYAnchor(),0.0d);
		}
		// Offset translation
		List<Point_Absolute>points=new LinkedList<Point_Absolute>(m_region.getPoints());
		DiscreteRegion transformedRegion=new DiscreteRegion();
		double width=(getParent().getContainerElement().getDrawingBounds().getWidth()-getParent().getContainerElement().getDrawingBounds().getX())/2;
		double height=(getParent().getContainerElement().getDrawingBounds().getHeight()-getParent().getContainerElement().getDrawingBounds().getY())/2;
		for(Point_Absolute point:points){
			double ax=point.getX()-offset.getX();
			double ay=point.getY()-offset.getY();
			// Orthographic zoom
			ax=ax*Math.pow(2,offset.getZ());
			ay=ay*Math.pow(2,offset.getZ());
			Point_Absolute translatedPointA=new Point_Euclidean(ax+getParent().getContainerElement().getDrawingBounds().getX()+width,ay+getParent().getContainerElement().getDrawingBounds().getY()+height,0.0d);
			transformedRegion.addPoint(translatedPointA);
		}
		assert Debugger.addSnapNode("Transformed Region",transformedRegion);
		RiffPolygonToolbox.optimizePolygon(transformedRegion);
		transformedRegion=RiffPolygonToolbox.clip(transformedRegion,RiffJavaToolbox.convertToRegion(getParent().getContainerElement().getDrawingBounds()));
		if(transformedRegion!=null){
			// Draw transformed line
			assert Debugger.addSnapNode("Clipped Region",transformedRegion);
			if(m_color==null){m_color=java.awt.Color.WHITE;}
			g2d.setColor(m_color);
			g2d.fillPolygon(RiffJavaToolbox.convertToPolygon(transformedRegion));
		}
		assert Debugger.closeNode();
	}
	public Object convert(){
		FauxTemplate_DiscreteRegion regionTemplate=new FauxTemplate_DiscreteRegion(getEnvironment());
		regionTemplate.setRegion(m_region);
		return regionTemplate;
	}
	public boolean nodificate(){
		assert Debugger.openNode("Discrete Region Graphical Element");
		assert Debugger.addNode(m_region);
		assert Debugger.closeNode();
		return true;
	}
}
