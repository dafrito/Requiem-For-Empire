import java.util.*;

public abstract class ActiveAsset extends Asset implements Tangible{
	protected AssetMap m_assetMap = new AssetMap();
	protected ActiveAsset m_parent;
	protected Point m_position;
	public ActiveAsset(ActiveAsset parent, Point position){
		super();
		m_parent=parent;
		if(m_parent!=null){
			m_position=m_parent.getPosition();
		}else{
			m_position=position;
		}
	}
	public abstract boolean isUnique();
	public boolean isTangible(){return true;}
	public Integer getAssetType(){return Asset.ACTIVEASSET;}
	public boolean isAssetOfType(Integer type){
		return(type.equals(getAssetType())||super.isAssetOfType(type));
	}
	public void setPosition(Point location){m_position=location;}
	public Point getPosition(){return m_position;}
	public ActiveAsset getParent(){return m_parent;}
	public Asset getAsset(Integer type){
		return m_assetMap.getAsset(type);
	}
	public void physicalIterate(double iterationTime){
		List assets=m_assetMap.getAllAssets();
		Iterator iter=assets.iterator();
		while(iter.hasNext()){
			((Asset)iter.next()).physicalIterate(iterationTime);
		}
	}
	public List<Lot>getAssets(Commodity comm){return m_assetMap.getAssets(comm);}
	public List<Lot>getAssets(Commodity comm, double quantity){
		List<Lot>list=getAssets(comm);
		List<Lot>returningList = new LinkedList<Lot>();
		for(Lot lot:list){
			if(quantity<=0){break;}
			if(lot.getQuantity()<=quantity){
				returningList.add(lot);
			}else{
				returningList.add(lot.getSlice(quantity));
			}
			quantity-=lot.getQuantity();
		}
		return returningList;
	}
	public void removeAll(Collection assets){
		Iterator iter=assets.iterator();
		while(iter.hasNext()){
			remove((Asset)iter.next());
		}
	}
	public void remove(Asset asset){
		m_assetMap.remove(asset);
	}
	public void add(Asset asset) throws CommodityMapException{
		m_assetMap.add(asset);
	}
	public void addAll(Collection<Asset>assets) throws CommodityMapException{
		m_assetMap.addAll(assets);
	}
	public void setParent(ActiveAsset parent){m_parent=parent;}
	public AssetMap getAssetMap(){return m_assetMap;}
	public String toString(){
		String string = new String();
		string += "Active Asset: ";
		return string;
	}
}
