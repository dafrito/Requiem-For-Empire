import java.lang.Math;

public class RiffSpherePoint extends Point_Absolute{
	private double m_latitude;
	private double m_longitude;
	private double m_magnitude;
	public static final double LATITUDEMAXIMUM=180;
	public static final double LONGITUDEMAXIMUM=360;
	public RiffSpherePoint(String name, double longitude, double latitude, double magnitude){
		super(null);
		setName(name);
		m_latitude=latitude%LATITUDEMAXIMUM;
		m_longitude=longitude%LONGITUDEMAXIMUM;
		m_magnitude=magnitude;
	}
	public RiffSpherePoint(double longitude, double latitude, double magnitude){
		super(null);
		m_latitude=latitude%LATITUDEMAXIMUM;
		m_longitude=longitude%LONGITUDEMAXIMUM;
		m_magnitude=magnitude;
	}
	public double getX(){return getLongitudeDegrees();}
	public double getY(){return getLatitudeDegrees();}
	public double getZ(){return m_magnitude;}
	public void setX(double x){setLatitudeDegrees(x);}
	public void setY(double y){setLongitudeDegrees(y);}
	public void setZ(double z){m_magnitude=z;}
	public double getLatitudeDegrees(){return m_latitude;}
	public double getLongitudeDegrees(){return m_longitude;}
	public boolean setLatitudeDegrees(double latitude){m_latitude = latitude%LATITUDEMAXIMUM;return true;}
	public boolean setLongitudeDegrees(double longitude){m_longitude = longitude%LONGITUDEMAXIMUM;return true;}
	public void setPosition(double lat, double longit){
		m_latitude = lat%LATITUDEMAXIMUM;
		m_longitude = longit%LONGITUDEMAXIMUM;
	}
	public void setLocation(Point point){
		m_latitude = ((RiffSpherePoint)point.getAbsolutePosition()).getLatitudeDegrees();
		m_longitude = ((RiffSpherePoint)point.getAbsolutePosition()).getLongitudeDegrees();
	}
	public double getLatitudeRadians(){return Math.toRadians(m_latitude);}
	public double getLongitudeRadians(){return Math.toRadians(m_longitude);}
	public boolean setLatitudeRadians(double latitude){m_latitude = Math.toDegrees(latitude);return true;}
	public boolean setLongitudeRadians(double longitude){m_longitude = Math.toDegrees(longitude);return true;}
	public int compareTo(Object o){
		if(getLatitudeDegrees()>((RiffSpherePoint)o).getLatitudeDegrees()){return 1;}
		if(getLatitudeDegrees()<((RiffSpherePoint)o).getLatitudeDegrees()){return -1;}
		if(getLongitudeDegrees()>((RiffSpherePoint)o).getLongitudeDegrees()){return 1;}
		if(getLongitudeDegrees()<((RiffSpherePoint)o).getLongitudeDegrees()){return -1;}
		return 0;
	}
	public boolean equals(Object o){
		RiffSpherePoint testPoint = ((RiffSpherePoint)o);
		if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,getLatitudeDegrees(),90.0d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,testPoint.getLatitudeDegrees(),90.0d)){return true;}
		if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,getLatitudeDegrees(),-90.0d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,testPoint.getLatitudeDegrees(),-90.0d)){return true;}
		return(RiffToolbox.areEqual(RiffToolbox.SPHERICAL,getLongitudeDegrees(),((RiffSpherePoint)o).getLongitudeDegrees())&&RiffToolbox.areEqual(RiffToolbox.SPHERICAL,getLatitudeDegrees(),((RiffSpherePoint)o).getLatitudeDegrees()));
	}
	public String toString(){
		String string = new String();
		if(m_name!=null){string += m_name;}
		string += "(" + m_longitude + " degrees longitude, " + m_latitude + " degrees latitude, " + m_magnitude + ")";
		return string;
	}
}
