import java.util.*;

public class Region{
	protected List<Point>m_locationPoints;
	public Region(){
		m_locationPoints = new LinkedList<Point>();
	}
	public Map<Point,Double>getOverlap(Point point){
		Map<Point,Double>map=new HashMap<Point,Double>();
		for(Point thisPoint:m_locationPoints){
			Double myDouble = new Double(thisPoint.getOverlap(point));
			if(myDouble.doubleValue() == 0.0d){continue;}
			map.put(thisPoint,myDouble);
		}
		return map;
	}
	public boolean addPoint(Point point){m_locationPoints.add(point);return true;}
	public List<Point>getPoints(){return m_locationPoints;}
	/* TODO: Nodificate
	public String toString(){
		String string = new String();
		string += "Region\n";
		string += "Points in region:\n";
		for(int i=0;i<m_locationPoints.size();i++){
			string += ((Point)m_locationPoints.get(i));
		}
		return string;
	}*/
}
