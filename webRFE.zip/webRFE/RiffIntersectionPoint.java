public class RiffIntersectionPoint implements Nodeable{
	private Point_Absolute m_intersect;
	private int m_location;
	public RiffIntersectionPoint(Point_Absolute intersect, int location){
		m_intersect=intersect;
		m_location=location;
	}
	public int getLocation(){return m_location;}
	public Point_Absolute getIntersection(){return m_intersect;}
	public boolean nodificate(){
		assert Debugger.openNode("Intersection-Point Struct");
		assert Debugger.addNode("Intersection-Point: " + m_intersect);
		assert Debugger.addNode("Point-list offset of intersection: " + m_location);
		assert Debugger.closeNode();
		return true;
	}
}
