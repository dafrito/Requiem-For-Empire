import java.util.*;
import java.awt.Color;
public class DiscreteRegion implements Comparable,Nodeable{
	private List<Point_Absolute>m_points;
	private Set<DiscreteRegion>m_neighbors;
	private Map<DiscreteRegion,Integer>m_intersectionMap=new HashMap<DiscreteRegion,Integer>();
	private double m_leftExtreme, m_rightExtreme, m_topExtreme, m_bottomExtreme;
	private Point_Absolute m_midPoint, m_interiorPoint;
	private Integer m_version= new Integer(0);
	private boolean m_isOptimized=false;
	private AssetMap m_assetMap;
	private Color m_color;
	private String m_name;
	private static int m_polyNum=0;
	public boolean nodificate(){
		assert Debugger.openNode("Discrete Region");
		if(m_name!=null){assert Debugger.addNode("Name: "+m_name);}
		assert Debugger.addSnapNode("Points: " + m_points.size()+" points",m_points);
		assert Debugger.addNode(m_assetMap);
		assert Debugger.openNode("Details");
		assert Debugger.openNode("Bounds");
		assert Debugger.addNode("Left bound: " + m_leftExtreme);
		assert Debugger.addNode("Right bound: " + m_rightExtreme);
		assert Debugger.addNode("Top bound: " + m_topExtreme);
		assert Debugger.addNode("Bottom bound: " + m_bottomExtreme);
		assert Debugger.closeNode();
		assert Debugger.addNode("Version: "+m_version);
		assert Debugger.addNode("Optimized: "+m_isOptimized);
		if(m_color!=null){assert Debugger.addNode("Color: "+RiffJavaToolbox.getColorName(m_color));}
		assert Debugger.addSnapNode("Neighbors",m_neighbors);
		assert Debugger.addSnapNode("Intersection Map",m_intersectionMap);
		assert Debugger.addNode("Mid-point: "+m_midPoint);
		assert Debugger.addNode("Interior point: "+m_interiorPoint);
		assert Debugger.closeNode();
		assert Debugger.closeNode();
		return true;
	}
	public DiscreteRegion(){
		assert Debugger.printDebug("DiscreteRegion/constructor", "(DiscreteRegionConstructor/)Creating new, empty DiscreteRegion.");
		m_points=new Vector<Point_Absolute>();
		m_neighbors=new HashSet<DiscreteRegion>();
		m_assetMap=new AssetMap();
		resetExtrema();
	}
	public DiscreteRegion(AssetMap assets){
		assert Debugger.printDebug("DiscreteRegion/constructor/assetData", "(DiscreteRegionConstructor/)Creating new DiscreteRegion with a provided asset-list.");
		assert Debugger.printDebug("DiscreteRegion/constructor/assetData", "Provided asset-list: " + assets);
		m_points=new Vector<Point_Absolute>();
		m_neighbors=new HashSet<DiscreteRegion>();
		m_assetMap=assets;
	}
	public DiscreteRegion(List<Point_Absolute>points){this();setPointList(points);}
	public DiscreteRegion(DiscreteRegion otherRegion){
		assert Debugger.printDebug("DiscreteRegion/constructor", "(DiscreteRegionConstructor/)Creating a new DiscreteRegion with a region provided to duplicate.");
		assert Debugger.printDebug("DiscreteRegion/constructor/data", "Provided DiscreteRegion: " + otherRegion);
		m_neighbors=new HashSet<DiscreteRegion>();
		m_points=new Vector<Point_Absolute>(otherRegion.getPoints());
		m_leftExtreme=otherRegion.getLeftExtreme();
		m_rightExtreme=otherRegion.getRightExtreme();
		m_topExtreme=otherRegion.getTopExtreme();
		m_bottomExtreme=otherRegion.getBottomExtreme();
		m_isOptimized=otherRegion.isOptimized();
		m_version=otherRegion.getVersion();
		m_assetMap = otherRegion.getAssetMap();
	}
	public int getNextNum(){return m_polyNum++;}
	public void setName(String name){m_name=name;}
	public void resetNeighbors(){m_neighbors.clear();}
	public Color getColor(){return m_color;}
	public void setColor(Color color){m_color=color;}
	public double getLeftExtreme(){return m_leftExtreme;}
	public double getRightExtreme(){return m_rightExtreme;}
	public double getTopExtreme(){return m_topExtreme;}
	public double getBottomExtreme(){return m_bottomExtreme;}
	public Point_Absolute getBoundingRectMidPoint(){
		if(m_midPoint==null){
			m_midPoint = RiffPolygonToolbox.createPoint(m_points.get(0), null, getLeftExtreme()+((getRightExtreme()-getLeftExtreme())/2),  getBottomExtreme()+((getTopExtreme()-getBottomExtreme())/2), 0.0d);
		}
		return m_midPoint;
	}
	public Point_Absolute getInteriorPoint(){
		return getBoundingRectMidPoint();
		//RiffPolygonToolbox.getMidPointOfLine(RiffPolygonToolbox.getMidPointOfLine(m_points.get(0), m_points.get(1)), RiffPolygonToolbox.getMidPointOfLine(m_points.get(1), m_points.get(2)));
		//return m_interiorPoint;
	}
	public Set<DiscreteRegion>getNeighbors(){return new HashSet<DiscreteRegion>(m_neighbors);}
	public List<Point_Absolute>getPoints(){return new LinkedList<Point_Absolute>(m_points);}
	public void addPoint(Point_Absolute point){
		testExtrema(point);
		m_points.add(point);
		assert Debugger.printDebug("DiscreteRegion/addPoint", "(addPoint/)Adding this point: " + point);
		assert Debugger.printDebug("DiscreteRegion/addPoint/data", "New point-list: " + RiffToolbox.displayList(m_points, "point"));
		resetIntersectionMap();
	}
	public void addPointAt(int location, Point_Absolute point){
		testExtrema(point);
		m_points.add(location, point);
		assert Debugger.printDebug("DiscreteRegion/addPointAt", "(addPointAt/)Adding at this location, " + location + ", this point: " + point);
		assert Debugger.printDebug("DiscreteRegion/addPointAt/data", "New point-list: " + RiffToolbox.displayList(m_points, "point"));
		resetIntersectionMap();
	}
	public void reversePoints(){
		assert Debugger.printDebug("DiscreteRegion/reversePoints", "(reversePoints/)Reversing points.");
		Collections.reverse(m_points);
	}
	public void removePoint(int pointNum){
		Point_Absolute point = (Point_Absolute)m_points.get(pointNum);
		removePoint(point);
	}
	public void removePoint(Point_Absolute point){
		if(!m_points.contains(point)){return;}
		assert Debugger.printDebug("DiscreteRegion/removePoint", "Removing this point: " + point);
		m_points.remove(point);
		if(point.getX()==m_leftExtreme||point.getX()==m_rightExtreme||point.getY()==m_topExtreme||point.getY()==m_bottomExtreme){
			recalculateExtrema();
		}
		assert Debugger.printDebug("DiscreteRegion/removePoint/data", "New point-list: " + RiffToolbox.displayList(m_points, "point"));
		resetIntersectionMap();
	}
	public void setPointList(List<Point_Absolute>pointList){
		assert Debugger.printDebug("DiscreteRegion/setPointList", "(setPointList/)Setting this region's pointList to a provided pointList.");
		assert Debugger.printDebug("DiscreteRegion/setPointList/data", "Old point-list: " + RiffToolbox.displayList(m_points));
		assert Debugger.printDebug("DiscreteRegion/setPointList/data", "New point-list: " + RiffToolbox.displayList(pointList));
		m_points=pointList;
		recalculateExtrema();
		resetIntersectionMap();
	}
	private void testExtrema(Point_Absolute point){
		if(point.getX()<m_leftExtreme){
			m_leftExtreme=point.getX();
		}
		if(point.getX()>m_rightExtreme){
			m_rightExtreme=point.getX();
		}
		if(point.getY()<m_bottomExtreme){
			m_bottomExtreme=point.getY();
		}
		if(point.getY()>m_topExtreme){
			m_topExtreme=point.getY();
		}
	}
	private void resetExtrema(){
		assert Debugger.printDebug("DiscreteRegion/resetExtrema", "(resetExtrema/)Resetting extrema.");
		m_leftExtreme=java.lang.Double.POSITIVE_INFINITY;
		m_rightExtreme=java.lang.Double.NEGATIVE_INFINITY;
		m_topExtreme=m_rightExtreme;
		m_bottomExtreme=m_leftExtreme;
	}
	private void recalculateExtrema(){
		assert Debugger.printDebug("DiscreteRegion/recalculateExtrema", "(recalculateExtrema/)Recalculating extrema.");
		resetExtrema();
		for(int i=0;i<m_points.size();i++){
			testExtrema((Point_Absolute)m_points.get(i));
		}
	}
	public AssetMap getAssetMap(){return m_assetMap;}
	public Integer getVersion(){return m_version;}
	public void resetIntersectionMap(){
		assert Debugger.printDebug("DiscreteRegion/resetIntersectionMap", "(resetIntersectionMap/)Resetting intersection map.");
		m_intersectionMap.clear();
		m_interiorPoint=m_midPoint=null;
		m_version=new Integer(m_version.intValue()+1);
		m_isOptimized=false;
		recheckNeighbors();
	}
	public void addRegionToMap(DiscreteRegion region){
		assert Debugger.printDebug("DiscreteRegion/addRegionToMap", "(addRegionToMap/)\nAdding region to intersection map.");
		assert Debugger.printDebug("DiscreteRegion/addRegionToMap/data", "Region to add: " + region + "\n(/addRegionMap)");
		m_intersectionMap.put(region, region.getVersion());
	}
	public boolean isOptimized(){return m_isOptimized;}
	public void setOptimized(boolean optimized){m_isOptimized=optimized;}
	public boolean checkClearedRegionMap(DiscreteRegion region){
		assert Debugger.printDebug("DiscreteRegion/checkClearedRegionMap", "(checkClearedRegionMap)\nChecking cleared region map.");
		assert Debugger.printDebug("DiscreteRegion/checkClearedRegionMap/data", "Region to check for: " + region);
		if(m_intersectionMap.get(region)==null){
			assert Debugger.printDebug("DiscreteRegion/checkIntersectionMap", "Cannot find region, returning false.\n(checkIntersectionMap/)");
			return false;
		}
		if(m_intersectionMap.get(region)==region.getVersion()){
			assert Debugger.printDebug("DiscreteRegion/checkClearedRegionMap", "Quick intersection test valid, returning true.\n(checkIntersectionMap/)");
			return true;
		}else{
			assert Debugger.printDebug("DiscreteRegion/checkClearedRegionMap", "Version difference, returning false.\n(checkIntersectionMap/)");
			return false;
		}
	}
	public void addNeighbor(DiscreteRegion region){
		if(region.equals(this)){return;}
		m_neighbors.add(region);
	}
	public void addRegionNeighbor(DiscreteRegion region){
		if(region.equals(this)){return;}
		assert Debugger.printDebug("DiscreteRegion/addRegionNeighbor/data", "Checking this region for neighbor status: " + region);
		List regionPoints = region.getPoints();
		for(int i=0;i<m_points.size();i++){
			Point_Absolute pointA = (Point_Absolute)m_points.get(i);
			Point_Absolute pointB = (Point_Absolute)m_points.get((i+1)%m_points.size());
			for(int j=0;j<regionPoints.size();j++){
				Point_Absolute testPoint = (Point_Absolute)regionPoints.get(j);
				Point_Absolute otherTestPoint = (Point_Absolute)regionPoints.get((j+1)%regionPoints.size());
				if(!RiffPolygonToolbox.testForColinearity(pointA, pointB, testPoint, otherTestPoint)){continue;}
				if(!RiffPolygonToolbox.getBoundingRectIntersection(pointA, pointB, testPoint, otherTestPoint)){continue;}
				region.addNeighbor(this);
				m_neighbors.add(region);
			}
		}
	}
	public void removeRegionNeighbor(DiscreteRegion region){
		m_neighbors.remove(region);
	}
	public void recheckNeighbors(){
		Set<DiscreteRegion>neighbors=new HashSet<DiscreteRegion>(m_neighbors);
		m_neighbors.clear();
		addRegionNeighbors(neighbors);
	}
	public String getName(){return m_name;}
	public void addRegionNeighbors(Collection<DiscreteRegion>regions){
		assert Debugger.printDebug("DiscreteRegion/addRegionNeighbors", "(addRegionNeighbors)\nChecking these regions for neighbor status.");
		for(DiscreteRegion region:regions){addRegionNeighbor(region);}
		assert Debugger.printDebug("DiscreteRegion/addRegionNeighbors", "(/addRegionNeighbors)");
	}
	public boolean equals(Object o){
		DiscreteRegion otherRegion = (DiscreteRegion)o;
		List<Point_Absolute>pointList=otherRegion.getPoints();
		return(m_points.containsAll(pointList)&&pointList.containsAll(m_points));
	}
	public int compareTo(Object o){
		return getBoundingRectMidPoint().compareTo(((DiscreteRegion)o).getBoundingRectMidPoint());
	}
	public int hashCode(){
		return m_points.hashCode();
	}
	/* TODO: Nodificate
	public String toString(){
		String string = new String();
		string += "Discrete Region: " + m_name;
		string += "\nPoints list: " + RiffToolbox.displayList(m_points, "point");
		string += "\nAssets: " + RiffToolbox.displayList(m_assets, "asset");
		string += "\nLeft Extrema: " + m_leftExtreme;
		string += "\nRight Extrema: " + m_rightExtreme;
		string += "\nTop Extrema: " + m_topExtreme;
		string += "\nBottom Extrema: " + m_bottomExtreme;
		string += "\nThis region has " + m_neighbors.size() + " neighbors.";
		return string;
	}*/
}
