public abstract class Point_Absolute extends Point implements Comparable{
	public Point_Absolute(){}
	public Point_Absolute(String name, String formalName, String adj){
		this(name,formalName,adj, null);
	}
	public Point_Absolute(String name, String formalName, String adj, Point point){
		super(name, formalName, adj, point);
	}
	public Point_Absolute(Point point){
		super(point);
	}
	public void duplicate(Point_Absolute point){
		setX(point.getX());
		setY(point.getY());
		setZ(point.getZ());
		setName(point.getName());
	}
	public void translate(double x, double y, double z){
		setX(getX()+x);
		setY(getY()+y);
		setZ(getZ()+z);
	}
	public void setPosition(double x, double y, double z){
		setX(x);
		setY(y);
		setZ(z);
	}
	public abstract double getX();
	public abstract double getY();
	public abstract double getZ();
	public abstract void setX(double x);
	public abstract void setY(double y);
	public abstract void setZ(double z);
	public abstract int compareTo(Object o);
	public void iterate(int iterationTime){}
	public boolean equals(Object o){
		Point_Absolute testPoint = (Point_Absolute)o;
		return(getY()==((Point_Absolute)o).getY()&&getX()==((Point_Absolute)o).getX());
	}
	public Point_Absolute getAbsolutePosition(){return this;}
}
