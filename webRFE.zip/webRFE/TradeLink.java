import java.util.*;

public class TradeLink{
	private Double m_currentRouteDistance;
	private Point m_currentStartingPoint;
	private Point m_currentEndingPoint;
	private List<Point>m_route;
	public TradeLink(){
		m_route=new LinkedList<Point>();
		m_currentStartingPoint=null;
		m_currentEndingPoint=null;
	}
	public Point getCurrentStartingPoint(){return m_currentStartingPoint;}
	public Point getCurrentEndingPoint(){return m_currentEndingPoint;}
	public void goToNextRoute(){
		m_route.remove(0);
		m_currentStartingPoint=(Point)m_route.get(0);
		m_currentEndingPoint=(Point)m_route.get(1);
		m_currentRouteDistance=null;
		getCurrentRouteDistance();
	}
	public double getCurrentRouteDistance(){
		if(m_currentRouteDistance==null){
			m_currentRouteDistance=new Double(RiffToolbox.getDistance(m_currentStartingPoint,m_currentEndingPoint));
		}
		return m_currentRouteDistance.doubleValue();
	}
	public boolean hasNext(){
		return(m_route.size()>2);
	}
	public List<Point>getFullRoute(){return m_route;}
	public String toString(){
		String string = new String();
		string += "TradeLink: ";
		return string;
	}
}
