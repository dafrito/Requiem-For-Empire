import java.util.*;

public class RiffBrands{
	private static Map<String,Brand>m_brands = new HashMap<String,Brand>(); // BrandName, Brand
	public static void addBrand(Brand brand){
		RiffBrands.m_brands.put(brand.getName(), brand);
	}
	public static Brand getBrand(String name){
		return RiffBrands.m_brands.get(name);
	}
}
