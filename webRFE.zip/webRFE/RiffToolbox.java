import java.lang.Math;
import java.util.Random;
import java.util.*;
import java.io.*;

public class RiffToolbox{
	public final static double DOUBLE_MIN = 1 * Math.pow(10, -10);
	public static final int EUCLIDEAN=0;
	public static final int SPHERICAL=1;
	private static Random m_random;
	private static boolean m_toggleDebugSpew;
	/******************************************************************************************/
	/************************ FILE I/0 ********************************************************/
	// Gets a single line from the provided stream. Returns null if at the end of the file.
	public static String getLineFromStream(FileReader stream){
		if(stream==null){return null;}
		String string = new String();
		try{
		while(true){
			int inputNum = stream.read();
			if(inputNum==-1){
				if(string.length()==0){
					return null;
				}else{
					return string;
				}
			}
			char inputChar = (char)inputNum;
			if(Character.isISOControl(inputChar)){
				if(inputChar=='\n'){return string;}
				continue;
			}
			string += inputChar;
		}
		}catch(IOException e){
			Debugger.printException(e);
			return null;
		}
	}
	// Parses a file provided by the string and returns a list of DiscreteRegions. Null if file is invalid.
	public static Set<DiscreteRegion>getDiscreteRegionsFromFile(String fileName)throws CommodityMapException{
		Set<DiscreteRegion>regions = new HashSet<DiscreteRegion>();
		try{
			DiscreteRegion openRegion=null;
			FileReader reader = new FileReader(fileName);
			String string = RiffToolbox.getLineFromStream(reader);
			while(string != null){
				if(string.equals("DiscreteRegion")){
					if(openRegion!=null){regions.add(openRegion);}
					openRegion = new DiscreteRegion();
					string = RiffToolbox.getLineFromStream(reader);
				}else{
					String[] pointArray = string.split("\"");
					String name = null;
					if(pointArray.length==3){
						name = pointArray[1];
						string = pointArray[2];
					}
					pointArray = string.split(",");
					openRegion.addPoint(new Point_Euclidean(name, Double.parseDouble(pointArray[0]), Double.parseDouble(pointArray[1]), Double.parseDouble(pointArray[2])));
				}
				string = RiffToolbox.getLineFromStream(reader);
			}
			if(openRegion!=null){regions.add(openRegion);}
			assert Debugger.printDebug("FileIO/getDiscreteRegionsFromFile/data", RiffToolbox.displayList(regions));
			return regions;
		}catch(IOException ex){
			Debugger.printException(ex);
			return regions;
		}
	}
	public static boolean getDebugSpewToggle(){return RiffToolbox.m_toggleDebugSpew;}
	// Creates a string containing text that is parseable into DiscreteRegions
	public static String getParseableDiscreteRegions(Collection<DiscreteRegion>regions){
		String string = new String();
		for(DiscreteRegion region:regions){string+=getParseableDiscreteRegion(region);}
		return string;
	}
	// Creates a string containing text that is parseable into a DiscreteRegion
	public static String getParseableDiscreteRegion(DiscreteRegion region){
		String string = new String("DiscreteRegion\n");
		Terrain terrain = (Terrain)region.getAssetMap().getAsset(Asset.TERRAIN);
		if(terrain!=null){
			string += terrain.getBrushDensity();
			string += "\n";
		}
		List list = region.getPoints();
		for(int i=0;i<list.size();i++){
			Point_Euclidean point = (Point_Euclidean)list.get(i);
			string += "\"" + point.getName() + "\" " + point.getX() + "," + point.getY() + "," + point.getZ();
			string += "\n";
		}
		return string;
	}
	public static String getExtension(File f) {
		String ext = null;
		String s = f.getName();
		int i = s.lastIndexOf('.');
		if (i > 0 &&  i < s.length() - 1) {
			ext = s.substring(i+1).toLowerCase();
		}
		if(ext==null){ext=new String("");}
		return ext;
	}
	/******************************************************************************************/
	/************************ STRING FUNCTIONS ************************************************/
	public static String tab(int val){return tab(val,"   ");}
	public static String tab(int val, String tab){
		String string=new String();
		for(int i=0;i<val;i++){
			string += tab;
		}
		return string;
	}
	public static String displayList(Collection list, String singular, String plural){return displayList(list,singular,plural,0);}
	// Takes a list and returns a string containing its contents in a readable form.
	public static String displayList(Collection list, String singular, String plural, int nestedVal){
		String string = new String();
		if(list==null||list.isEmpty()){
			string += "\n" + tab(nestedVal) + "This list is empty.";
			return string;
		}else if(list.size()==1){
			string += "\n" + tab(nestedVal) + "This list contains one " + singular;
		}else{
			string += "\n" + tab(nestedVal) + "This list contains " + list.size() + " " + plural;
		}
		Iterator iter = list.iterator();
		int value=1;
		while(iter.hasNext()){
			Object obj = iter.next();
			string += "\n" + value + ". " + tab(nestedVal);
			value++;
			if(obj instanceof Collection){string += "Nested list:" + displayList((Collection)obj, singular, plural, nestedVal+1);
			}else{string += obj;}
		}
		return string;
	}
	public static String displayList(Object[] array){
		String string = new String();
		if(array.length==0){
			string += "\nThis list is empty.";
			return string;
		}else if(array.length==1){
			string += "\nThis list contains one item";
		}else{
			string += "\nThis list contains " + array.length + " items";
		}
		for(int i=0;i<array.length;i++){
			string+="\n"+array[i];
		}
		return string;
	}
	// Helper Function.
	public static String displayList(Collection list){return displayList(list, "item", "items");}
	// Helper Function.
	public static String displayList(Collection list, String singular){return displayList(list, singular, new String(singular + "s"));}
	// Takes a string and creates a new string with a underline beneath the string provided. The underline is formed by a string of the printChar the length of the baseString.
	public static String printUnderline(String baseString, String printChar){
		String string = new String(baseString + "\n");
		for(int i = baseString.length(); i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	// Prints a symbol n times.
	public static String printLine(String symbol, int times){
		String string = new String();
		for(int i=0;i<times;i++){
			string += symbol;
		}
		string += "\n";
		return string;
	}
	// Returns a string with a ASCII border around the baseString. The border consists of the character provided by printChar.
	public static String printBorder(String baseString, String printChar){
		String string = new String();
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n " + baseString + "\n";
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	/******************************************************************************************/
	/************************ MATH FUNCTIONS **************************************************/
	// Converts degress to radians.
	public static double convertDegreesToRadians(double degrees){return degrees * Math.PI/180;}
	// 2-dimensional distance formula for Point_Absolutes (Fallback distance formula when testing Sphere vs. Euclidean)
	public static double getDistance(Point_Absolute firstPoint, Point_Absolute secondPoint){
		return getDistance(firstPoint.getX(),firstPoint.getY(),secondPoint.getX(),secondPoint.getY());
	}
	public static double getDistance(double ax,double ay,double bx,double by){
		return Math.sqrt(Math.pow(bx-ax, 2) + Math.pow(by-ay,2));
	}
	// Helper function.
	public static double getDistance(Point firstPoint, Point secondPoint){
		return getDistance(firstPoint.getAbsolutePosition(), secondPoint.getAbsolutePosition());
	}
	// Spherical distance formula for RiffSpherePoints
	public static double getDistance(Terrestrial terrestrial, RiffSpherePoint firstPoint, RiffSpherePoint secondPoint){
		double firstLat = Math.toRadians(firstPoint.getLatitudeDegrees());
		double secondLat = Math.toRadians(secondPoint.getLatitudeDegrees());
		double firstLong = Math.toRadians(firstPoint.getLongitudeDegrees());
		double secondLong = Math.toRadians(secondPoint.getLongitudeDegrees());
		double temp = Math.pow(Math.sin((secondLat - firstLat)/2),2) + Math.cos(firstLat) * Math.cos(secondLat) * Math.pow(Math.sin((secondLong - firstLong)/2),2);
		return terrestrial.getRadius() * 2 * Math.asin(Math.min(1, Math.sqrt(temp)));
	}
	// 3-dimensional distance formula for Point_Euclideans
	public static double getDistance(Point_Euclidean firstPoint, Point_Euclidean secondPoint){
		//( (x-a)2 + (y - b)2 + (z - c)2 )1/2
		double testDouble = Math.sqrt(Math.pow((secondPoint.getX() - firstPoint.getX()), 2) + Math.pow((secondPoint.getY() - firstPoint.getY()), 2) + Math.pow((secondPoint.getZ() - firstPoint.getZ()), 2));
		return testDouble;
	}
	// Returns a static Random class.
	public static Random getRandom(){
		if(RiffToolbox.m_random == null){RiffToolbox.m_random = new Random();}
		return RiffToolbox.m_random;
	}
	public static boolean areEqual(Point_Absolute point, double a, double b){
		if(point instanceof RiffSpherePoint){
			return areEqual(SPHERICAL,a,b);
		}
		return areEqual(EUCLIDEAN,a,b);
	}
	public static boolean areEqual(int point, double a, double b){
		if(point==SPHERICAL){
			if((areEqual(EUCLIDEAN, a, 180.0d)||areEqual(EUCLIDEAN, a,0.0d))&&(areEqual(EUCLIDEAN,b,180.0d)||areEqual(EUCLIDEAN,b,0.0d))){return true;}
			return(Math.abs(a-b)<RiffToolbox.DOUBLE_MIN);
		}
		return (Math.abs(a-b)<RiffToolbox.DOUBLE_MIN);
	}
	public static boolean isGreaterThan(double greater, double less){
		return (greater-less>RiffToolbox.DOUBLE_MIN);
	}
	public static boolean isLessThan(double less, double greater){
		return(less-greater<-RiffToolbox.DOUBLE_MIN);
	}
	public static boolean isGreaterThanOrEqualTo(Object point, double greater, double less){
		if(point instanceof RiffSpherePoint){
			return isGreaterThanOrEqualTo(SPHERICAL,greater,less);
		}
		return isGreaterThanOrEqualTo(EUCLIDEAN,greater,less);
	}
	public static boolean isGreaterThanOrEqualTo(int point, double greater, double less){
		return(isGreaterThan(greater, less)||areEqual(point,greater,less));
	}
	public static boolean isLessThanOrEqualTo(Object point, double greater, double less){
		if(point instanceof RiffSpherePoint){
			return isLessThanOrEqualTo(SPHERICAL,greater,less);
		}
		return isLessThanOrEqualTo(EUCLIDEAN,greater,less);
	}
	public static boolean isLessThanOrEqualTo(int point, double less, double greater){
		return(isLessThan(less, greater)||areEqual(point,less, greater));
	}
	/******************************************************************************************/
	/************************ RANDOM STUFF ****************************************************/
	// Predefined region generator.
	public static DiscreteRegion createRegion(DiscreteRegion region, int regionNum){
		switch(regionNum){
		case 0:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 288,78,0));
			region.addPoint(new Point_Euclidean("B", 263,46,0));
			region.addPoint(new Point_Euclidean("C", 196,100,0));
			region.addPoint(new Point_Euclidean("D", 239,79,0));
			region.addPoint(new Point_Euclidean("E", 264,72,0));
			region.addPoint(new Point_Euclidean("F", 263,96,0));
			return region;
		case 1:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 516,239,0));
			region.addPoint(new Point_Euclidean("B", 488,230,0));
			region.addPoint(new Point_Euclidean("C", 502,192,0));
			region.addPoint(new Point_Euclidean("D", 456,163,0));
			region.addPoint(new Point_Euclidean("E", 456,246,0));
			region.addPoint(new Point_Euclidean("F", 384,265,0));
			region.addPoint(new Point_Euclidean("G", 460,104,0));
			region.addPoint(new Point_Euclidean("H", 523,145,0));
			return region;
		case 2:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 50,50,0));
			region.addPoint(new Point_Euclidean("B", 75,75,0));
			region.addPoint(new Point_Euclidean("C", 100,100,0));
			region.addPoint(new Point_Euclidean("D", 125,125,0));
			region.addPoint(new Point_Euclidean("E", 150,150,0));
			region.addPoint(new Point_Euclidean("F", 250,50,0));
			region.addPoint(new Point_Euclidean("G", 225,50,0));
			region.addPoint(new Point_Euclidean("H", 150,125,0));
			region.addPoint(new Point_Euclidean("I", 75,50,0));
			return region;
		case 3:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 300,158,0));
			region.addPoint(new Point_Euclidean("B", 328,73,0));
			region.addPoint(new Point_Euclidean("C", 226,140,0));
			region.addPoint(new Point_Euclidean("D", 346,219,0));
			region.addPoint(new Point_Euclidean("E", 445,110,0));
			return region;
		case 4:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 583,164,0));
			region.addPoint(new Point_Euclidean("B", 542,148,0));
			region.addPoint(new Point_Euclidean("C", 515,127,0));
			region.addPoint(new Point_Euclidean("D", 529,102,0));
			region.addPoint(new Point_Euclidean("E", 547,89,0));
			region.addPoint(new Point_Euclidean("F", 545,73,0));
			region.addPoint(new Point_Euclidean("G", 525,61,0));
			region.addPoint(new Point_Euclidean("H", 493,75,0));
			region.addPoint(new Point_Euclidean("I", 471,97,0));
			region.addPoint(new Point_Euclidean("J", 448,73,0));
			region.addPoint(new Point_Euclidean("K", 508,43,0));
			region.addPoint(new Point_Euclidean("L", 576,53,0));
			region.addPoint(new Point_Euclidean("M", 608,125,0));
			return region;
		case 5:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 175,150,0));
			region.addPoint(new Point_Euclidean("B", 325,125,0));
			region.addPoint(new Point_Euclidean("C", 250,200,0));
			return region;
		case 6: 
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("D", 150,150,0));
			region.addPoint(new Point_Euclidean("E", 375,5,0));
			region.addPoint(new Point_Euclidean("F", 200,200,0));
			return region;
		case 7:
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("A", 50,50,0));
			region.addPoint(new Point_Euclidean("B", 150,50,0));
			region.addPoint(new Point_Euclidean("C", 150,550,0));
			region.addPoint(new Point_Euclidean("D", 50,550,0));
			return region;
		case 8: 
			region = new DiscreteRegion();
			region.addPoint(new Point_Euclidean("E", 50,250,0));
			region.addPoint(new Point_Euclidean("F", 150,50,0));
			region.addPoint(new Point_Euclidean("G", 150,550,0));
			region.addPoint(new Point_Euclidean("H", 50,550,0));
			return region;
		default:
			return null;
		}
	}
	// Prints out memory usage of the program.
	public static void determineMemoryUsage()
	{
		System.gc();
		long free = Runtime.getRuntime().freeMemory();
		long total = Runtime.getRuntime().totalMemory();
		long max = Runtime.getRuntime().maxMemory();
		assert Debugger.printDebug("determineMemoryUsage", "Free memory in this chunk: " + (total-free));
		assert Debugger.printDebug("determineMemoryUsage", "Total memory chunk size: " + total);
	    	assert Debugger.printDebug("determineMemoryUsage", "Percentage used: " + 100*((double)total-(double)free)/(double)total);
		assert Debugger.printDebug("determineMemoryUsage", "Maximum memory: " + max);
	}
}
