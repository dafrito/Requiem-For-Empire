import javax.swing.*;
import javax.swing.tree.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.*;
import java.text.NumberFormat;
public class Debug_Environment extends JFrame implements ActionListener,ChangeListener{
	private RiffDeveloper m_studio;
	private JSplitPane m_vertSplitPane;
	private JTabbedPane m_tabbedPane,m_filteredPanes;
	private JLabel m_status;
	private JMenuItem m_newFile,m_openFile,m_closeFile,m_saveFile,m_saveFileAs,m_exit,m_compile,m_report,m_undo,m_redo,m_execute,m_compileAndRun;
	private JMenuItem m_removeTab,m_clearTab,m_createListener,m_renameTab;
	private JMenuBar m_menuBar;
	private JMenu m_parserMenu,m_editMenu,m_listenerMenu;
	private java.util.List<Debug_ScriptElement>m_scriptElements;
	private Debug_Listener m_capturingOutput,m_filtering;
	private java.util.List<Debug_Listener>m_filteredOutputs;
	private boolean m_canExecute=false;
	private String m_priorityExecutingClass;
	public Debug_Environment(RiffDeveloper studio,int width, int height){
		super("RFE Debugger");
		Debugger.setDebugger(this);
		m_studio=studio;
		m_scriptElements=new LinkedList<Debug_ScriptElement>();
		m_filteredOutputs=new LinkedList<Debug_Listener>();
		setLocation(0,height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(width,1000-height);
		// Menu bar
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(m_status=new JLabel(" Ready"),BorderLayout.SOUTH);
		getContentPane().add(m_tabbedPane=new JTabbedPane());
		m_tabbedPane.addChangeListener(this);
		m_menuBar=new JMenuBar();
		setJMenuBar(m_menuBar);
		JMenu fileMenu=new JMenu("File");
		m_menuBar.add(fileMenu);
		fileMenu.setMnemonic('F');
		m_editMenu=new JMenu("Edit");
		m_menuBar.add(m_editMenu);
		m_editMenu.setMnemonic('E');
		m_parserMenu=new JMenu("Parser");
		m_parserMenu.setMnemonic('P');
		m_menuBar.add(m_parserMenu);
		fileMenu.add(m_newFile=new JMenuItem("New Script",'N'));
		fileMenu.add(m_openFile=new JMenuItem("Open Script...",'O'));
		fileMenu.add(m_closeFile=new JMenuItem("Close Script",'C'));
		fileMenu.add(m_saveFile=new JMenuItem("Save Script",'S'));
		fileMenu.add(m_saveFileAs=new JMenuItem("Save Script As...",'A'));
		fileMenu.add(m_report=new JMenuItem("Report",'T'));
		fileMenu.add(m_exit=new JMenuItem("Exit",'X'));
		m_editMenu.add(m_undo=new JMenuItem("Undo",'U'));
		m_editMenu.add(m_redo=new JMenuItem("Redo",'R'));
		m_parserMenu.add(m_compile=new JMenuItem("Compile",'C'));
		m_parserMenu.add(m_execute=new JMenuItem("Execute",'X'));
		m_parserMenu.add(m_compileAndRun=new JMenuItem("Compile and Run",'R'));
		m_execute.setEnabled(false);
		m_listenerMenu=new JMenu("Listener");
		m_menuBar.add(m_listenerMenu);
		m_listenerMenu.setMnemonic('L');
		m_listenerMenu.add(m_createListener=new JMenuItem("Create Listener...",'C'));
		m_listenerMenu.add(m_renameTab=new JMenuItem("Rename Tab...",'N'));
		m_listenerMenu.add(m_clearTab=new JMenuItem("Clear Tab",'C'));
		m_listenerMenu.add(m_removeTab=new JMenuItem("Remove Tab",'R'));
		// Set up our debug spew and script tabs
		m_tabbedPane.add("Debug Output",m_filteredPanes=new JTabbedPane());
		m_filteredOutputs.add(new Debug_Listener(this,null,"Unfiltered Output"));
		m_filteredPanes.add("Unfiltered Output",m_filteredOutputs.get(0));
		// Accelerators
		m_clearTab.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,ActionEvent.CTRL_MASK));
		m_removeTab.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,ActionEvent.CTRL_MASK));
		m_newFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));
		m_openFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,ActionEvent.CTRL_MASK));
		m_closeFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,ActionEvent.CTRL_MASK));
		m_saveFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
		m_saveFileAs.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,ActionEvent.CTRL_MASK));
		m_exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,ActionEvent.CTRL_MASK));
		m_undo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,ActionEvent.CTRL_MASK));
		m_redo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,ActionEvent.CTRL_MASK));
		m_compile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5,0));
		m_execute.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F8,0));
		m_compileAndRun.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5,ActionEvent.CTRL_MASK));
		// Listeners
		m_renameTab.addActionListener(this);
		m_report.addActionListener(this);
		m_filteredPanes.addChangeListener(this);
		m_clearTab.addActionListener(this);
		m_removeTab.addActionListener(this);
		m_createListener.addActionListener(this);
		m_newFile.addActionListener(this);
		m_openFile.addActionListener(this);
		m_closeFile.addActionListener(this);
		m_saveFile.addActionListener(this);
		m_saveFileAs.addActionListener(this);
		m_exit.addActionListener(this);
		m_undo.addActionListener(this);
		m_redo.addActionListener(this);
		m_compile.addActionListener(this);
		m_execute.addActionListener(this);
		m_compileAndRun.addActionListener(this);
		// Open all valid scripts in our working directory
		File folder=new File(".");
		ExtensionFilter filter=new ExtensionFilter();
		filter.addExtension("RiffScript");
		File[]files=folder.listFiles(filter);
		for(File file:files){
			if(file.isFile()){addReferenced(new Debug_ScriptElement(this,file));}
		}
		// Finally, show the window.
		setVisible(true);
	}
	public void setFilteringOutput(Debug_Listener output){
		m_filtering=output;
	}
	public Debug_Listener getFilteringOutput(){
		return m_filtering;
	}
	public void setPriorityExecutingClass(String template){m_priorityExecutingClass=template;}
	public String getPriorityExecutingClass(){return m_priorityExecutingClass;}
	public Debug_Listener isFilterUsed(Object filter){
		for(Debug_Listener output:m_filteredOutputs){
			if(!output.isUnfiltered()&&output.getTreePanel().getFilter().isFilterUsed(filter)){
				return output;
			}
		}
		return null;
	}
	public void report(){
		System.gc();
		NumberFormat nf = NumberFormat.getInstance();
		double free=((double)Runtime.getRuntime().freeMemory())/((double)Runtime.getRuntime().totalMemory());
		free*=100;
		System.out.println("Used Memory: "+nf.format(Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())+" bytes");
		System.out.println("Total Memory Allocated: "+nf.format(Runtime.getRuntime().totalMemory())+" bytes ("+(int)free+"% free)");
	}
	public void removeOutputListener(Debug_Listener output){
		m_filteredPanes.removeTabAt(m_filteredPanes.getSelectedIndex());
		m_filteredOutputs.remove(output);
	}
	public Debug_Listener addOutputListener(Debug_Listener source,Object filter){
		if(filter==null||"".equals(filter)){return null;}
		if(null!=isFilterUsed(filter)){
			JOptionPane.showMessageDialog(this,"An output listener has an identical filter to the one provided.","Listener Already Exists",JOptionPane.INFORMATION_MESSAGE);
			focusOnOutput(isFilterUsed(filter));
			return null;
		}
		Debug_Listener output=new Debug_Listener(this,source,filter.toString());
		output.getTreePanel().getFilter().addFilter(filter);
		output.getTreePanel().refresh();
		source.addChildOutput(output);
		m_filteredPanes.add(filter.toString(),output);
		m_filteredPanes.setSelectedIndex(m_filteredPanes.getComponentCount()-1);
		m_filteredOutputs.add(output);
		return output;
	}
	public void focusOnOutput(Debug_Listener output){
		assert output!=null;
		m_filteredPanes.setSelectedIndex(m_filteredPanes.indexOfComponent(output));
	}
	public ScriptEnvironment getEnvironment(){return m_studio.getEnvironment();}
	public void addReferenced(Debug_ScriptElement element){
		m_tabbedPane.add(element.getName(),element);
		m_scriptElements.add(element);
		m_tabbedPane.setSelectedIndex(m_tabbedPane.getComponents().length-1);
	}
	// Node stuff
	public void openNode(Debug_TreeNode node){
		addNode(node,true);
	}
	public Debug_TreeNode getUnfilteredCurrentNode(){return getUnfilteredOutput().getTreePanel().getCurrentNode();}
	public void addNode(Debug_TreeNode node){addNode(node,false);}
	public void addNode(Debug_TreeNode node,boolean setAsCurrent){
		if(m_capturingOutput!=null){
			addNodeToOutput(node,setAsCurrent,m_capturingOutput);
			return;
		}
		for(Debug_Listener output:m_filteredOutputs){
			if(output.isCapturing()){
				output.getTreePanel().getFilter().sniffNode(node);
				if(output.getTreePanel().getFilter().isListening()){
					m_capturingOutput=output;
				}
			}
		}
		if(m_capturingOutput!=null){addNodeToOutput(node,setAsCurrent,m_capturingOutput);return;}
		for(Debug_Listener output:m_filteredOutputs){
			addNodeToOutput(node.duplicate(),setAsCurrent,output);
		}
	}
	private void addNodeToOutput(Debug_TreeNode node, boolean setAsCurrent,Debug_Listener output){
		if(!output.getTreePanel().getFilter().isListening()){
			output.getTreePanel().getFilter().sniffNode(node);
			if(!output.getTreePanel().getFilter().isListening()){return;}
			node=new Debug_TreeNode_Orphaned(output.getSource().getTreePanel().getLastNodeAdded());
		}
		if(output.getTreePanel().getCurrentNode().hasChildren()&&output.getTreePanel().getCurrentNode().getLastChild().getGroup()!=null&&node.getGroup()!=null&&output.getTreePanel().getCurrentNode().getLastChild().getGroup().equals(node.getGroup())){
			if(output.getTreePanel().getCurrentNode().getLastChild().getData().equals(node.getGroup())){
				output.getTreePanel().getCurrentNode().getLastChild().addChild(node);
				output.getTreePanel().reload();
				node.setPracticalParent(output.getTreePanel().getCurrentNode());
				if(setAsCurrent){output.getTreePanel().setAsCurrent(node);}
			}else{
				Debug_TreeNode lastNode=output.getTreePanel().getCurrentNode().removeLastChild();
				Debug_TreeNode groupNode=new Debug_TreeNode(node.getGroup(),node.getGroup());
				groupNode.addChild(lastNode);
				groupNode.addChild(node);
				lastNode.setPracticalParent(output.getTreePanel().getCurrentNode());
				node.setPracticalParent(output.getTreePanel().getCurrentNode());
				output.getTreePanel().addNode(groupNode);
				if(setAsCurrent){output.getTreePanel().setAsCurrent(node);}
			}
			return;
		}
		output.getTreePanel().addNode(node);
		if(setAsCurrent){output.getTreePanel().setAsCurrent(node);}
	}
	public void releaseCapture(){m_capturingOutput=null;}
	public void closeNode(){
		if(m_capturingOutput!=null){
			m_capturingOutput.getTreePanel().closeNode();
			return;
		}
		for(Debug_Listener output:m_filteredOutputs){
			if(output.getTreePanel().getFilter().isListening()){output.getTreePanel().closeNode();}
		}
	}
	public void closeNodeTo(String string){
		for(Debug_Listener output:m_filteredOutputs){
			while(output.getTreePanel().getFilter().isListening()&&!output.getTreePanel().getCurrentNode().getData().equals(string)){
				output.getTreePanel().closeNode();
			}
		}
	}
	public Debug_Listener getUnfilteredOutput(){return m_filteredOutputs.get(0);}
	public Debug_TreeNode getLastNodeAdded(){return getUnfilteredOutput().getTreePanel().getLastNodeAdded();}
	// Deprecated, deprecated, deprecated...
	public boolean printDebug(String category, Object obj){
		return true;
		/*String string=obj.toString();
		boolean flag=false;
		assert flag=true;
		if(flag){return true;}
		String tabValue="  ";
		String tabString;
		java.util.List<String>strings=null;
		if(string.charAt(0)=='('){
			if(string.charAt(1)=='/'){
				// Closing category - (/cat:fxn)
				assert string.substring(2,string.length()-1).equals(m_currentNode.getData()):"'" + obj + "' Debug printer error. Unclosed function: " + m_currentNode.getData();
				closeNode();
				return true;
			}else if(string.matches("[(]{1}[A-Za-z:]+[/]{1}[)]{1}.*")){
				// Inline category - (cat:fxn/)
				string=category+"|"+string;
			}else{
				// Open category - (cat:fxn)
				openNode(new Debug_TreeNode(getCurrentNode(),null,string.substring(1,string.length()-1)));
				return true;
			}
		}else{
			while(string.indexOf("\n")!=-1){
				int i=string.indexOf("\n");
				String left=string.substring(0,i);
				String right=string.substring(i+1);
				string=right;
				if(strings==null){strings=new LinkedList<String>();}
				strings.add(left);
			}
		}
		if(strings==null){
			addNode(new Debug_TreeNode(getCurrentNode(),null,string));
		}else{
			for(int i=0;i<strings.size();i++){
				addNode(new Debug_TreeNode(getCurrentNode(),null,(String)strings.get(i)));
			}
		}
		return true;*/
	}
	// Listeners
	public void actionPerformed(ActionEvent event){
		if(event.getActionCommand().equals("Exit")){
			java.util.List<Debug_ScriptElement>removedElements=new LinkedList<Debug_ScriptElement>();
			int index=m_tabbedPane.getSelectedIndex();
			for(;m_scriptElements.size()>0;){
				Debug_ScriptElement element=m_scriptElements.get(0);
				if(!element.closeFile()){
					for(Debug_ScriptElement added:removedElements){
						m_scriptElements.add(0,added);
						m_tabbedPane.add(added,1);
					}
					m_tabbedPane.setSelectedIndex(index);
					return;
				}
				m_tabbedPane.remove(1);
				m_scriptElements.remove(0);
				removedElements.add(element);
			}
			System.exit(0);
		}else if(event.getActionCommand().equals("New Script")){
			addReferenced(new Debug_ScriptElement(this,(String)null));
		}else if(event.getActionCommand().equals("Open Script...")){
			Debug_ScriptElement element=new Debug_ScriptElement(this);
			if(element.isValid()){addReferenced(element);}
		}else if(event.getActionCommand().equals("Close Script")){
			if(((Debug_ScriptElement)m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1)).closeFile()){
				int index=m_tabbedPane.getSelectedIndex();
				m_tabbedPane.remove(index);
				m_scriptElements.remove(index-1);
			}
		}else if(event.getSource().equals(m_renameTab)){
			Object text=JOptionPane.showInputDialog(null,"Insert new output name","Rename Output",JOptionPane.QUESTION_MESSAGE,null,null,m_filteredPanes.getTitleAt(m_filteredPanes.getSelectedIndex()));
			if(text!=null){m_filteredPanes.setTitleAt(m_filteredPanes.getSelectedIndex(),text.toString());}
		}else if(event.getSource().equals(m_createListener)){
			((Debug_Listener)m_filteredPanes.getSelectedComponent()).promptCreateListener();
		}else if(event.getActionCommand().equals("Save Script")){
			m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).saveFile();
		}else if(event.getActionCommand().equals("Clear Tab")){
			((Debug_Listener)m_filteredPanes.getSelectedComponent()).clearTab();
		}else if(event.getActionCommand().equals("Remove Tab")){
			((Debug_Listener)m_filteredPanes.getSelectedComponent()).removeTab();
		}else if(event.getActionCommand().equals("Save Script As...")){
			m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).saveFileAs();
		}else if(event.getActionCommand().equals("Undo")){
			m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).undo();
		}else if(event.getActionCommand().equals("Report")){
			report();
		}else if(event.getActionCommand().equals("Redo")){
			m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).redo();
		}else if(event.getActionCommand().equals("Compile")||event.getActionCommand().equals("Compile and Run")){
			setStatus("Compiling...");
			getEnvironment().resetEnvironment();
			Parser.clearPreparseLists();
			m_execute.setEnabled(false);
			setCanExecute(false);
			boolean quickflag=true;
			for(int i=0;i<m_scriptElements.size();i++){
				Debug_ScriptElement element=m_scriptElements.get(i);
				element.saveFile();
				if(!element.compile()){
					quickflag=false;
					m_tabbedPane.setTitleAt(i+1,element.getName());
				}
			}
			if(!quickflag){setStatus("One or more files had errors during compilation.");return;}
			Vector<Exception>exceptions=Parser.parseElements(getEnvironment());
			if(exceptions.size()==0){
				setCanExecute(true);
				m_execute.setEnabled(true);
				setStatus("All files compiled successfully.");
				Debugger.addSnapNode("Compile successful",getEnvironment());
				if(event.getActionCommand().equals("Compile and Run")){getEnvironment().execute();}
				return;
			}else{
				setStatus("One or more files had errors during compilation.");
				for(Exception rawEx:exceptions){
					if(rawEx instanceof Exception_Nodeable&&!((Exception_Nodeable)rawEx).isAnonymous()){
						Exception_Nodeable ex=(Exception_Nodeable)rawEx;
						getReferenced(ex.getFilename()).addException(ex);
						m_tabbedPane.setTitleAt(m_scriptElements.indexOf(getReferenced(ex.getFilename()))+1,getReferenced(ex.getFilename()).getName());
					}else{
						m_scriptElements.get(0).addException(rawEx);
					}
				}
			}
		}else if(event.getActionCommand().equals("Execute")){
			getEnvironment().execute();
		}
	}
	public void setStatus(String text){
		m_status.setText(" "+text);
	}
	public Debug_ScriptElement getReferenced(String name){
		for(Debug_ScriptElement element:m_scriptElements){
			if(element.getFilename().equals(name)){return element;}
		}
		assert false:"Script Element not found: " +name;
		return null;
	}
	public void resetTitle(Debug_ScriptElement element){
		m_tabbedPane.setTitleAt(m_scriptElements.indexOf(element)+1,element.getName());
	}
	public void showReferenced(Debug_ScriptElement element){
		m_tabbedPane.setSelectedIndex(m_scriptElements.indexOf(element)+1);
	}
	public void setCanExecute(boolean exec){m_execute.setEnabled(m_canExecute=exec);}
	public void setCanUndo(boolean canUndo){m_undo.setEnabled(canUndo);}
	public void setCanRedo(boolean canRedo){m_redo.setEnabled(canRedo);}
	public void setChanged(boolean changed){
		m_saveFile.setEnabled(changed);
		m_tabbedPane.setTitleAt(m_tabbedPane.getSelectedIndex(),m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).getName());
	}
	public void stateChanged(ChangeEvent e){
		if(m_filteredPanes.getSelectedIndex()==0){
			m_removeTab.setEnabled(false);
		}else{
			m_removeTab.setEnabled(true);
		}
		if(m_tabbedPane.getSelectedIndex()==0){
			m_closeFile.setEnabled(false);
			m_saveFile.setEnabled(false);
			m_saveFileAs.setEnabled(false);
			m_editMenu.setEnabled(false);
			m_listenerMenu.setEnabled(true);
		}else{
			m_listenerMenu.setEnabled(false);
			m_editMenu.setEnabled(true);
			m_saveFileAs.setEnabled(true);
			m_closeFile.setEnabled(true);
			setChanged(m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).hasChanged());
			setCanUndo(m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).canUndo());
			setCanRedo(m_scriptElements.get(m_tabbedPane.getSelectedIndex()-1).canRedo());
		}
	}
}

class Debugger{
	// Debug_Environment fxns
	private static Debug_Environment m_debugger;
	public static Debug_Environment getDebugger(){return m_debugger;}
	public static void setDebugger(Debug_Environment debugger){m_debugger=debugger;}
	public static void printException(Exception ex){
		System.out.println(ex);
		if(ex instanceof Exception_Nodeable||ex instanceof Exception_InternalError){
			assert addNode("Exceptions and Errors",ex);
		}else{
			assert addSnapNode("Exceptions and Errors","Exception",ex);
		}
	}
	// Noding functions.
	public static boolean openNode(String string){openNode(null,string);return true;}
	public static boolean openNode(String group,String string){getDebugger().openNode(new Debug_TreeNode(group,string));return true;}
	public static boolean addSnapNode(String name, Object o){return addSnapNode(null,name,o);}
	public static boolean addSnapNode(String group,String name, Object o){
		openNode(group,name);
		addNode(o);
		closeNode();
		return true;
	}
	public static boolean addNode(Object o){return addNode(null,o);}
	public static boolean addNode(String group,Object o){
		if(o==null){getDebugger().addNode(new Debug_TreeNode(group,"null"));return true;}
		if(o instanceof Nodeable){
			addNodeableNode(group,(Nodeable)o);
			if(o instanceof Exception){
				String exceptionName;
				if(o instanceof Exception_Nodeable){exceptionName=((Exception_Nodeable)o).getName();
				}else if(o instanceof Exception_InternalError){exceptionName=((Exception_InternalError)o).getMessage();
				}else{exceptionName="Exception";}
				getDebugger().getUnfilteredOutput().getHotspotPanel().createHotspot(getDebugger().getLastNodeAdded(),exceptionName);
			}
			return true;
		}
		if(o instanceof Collection){return addCollectionNode(group,(Collection)o);}
		if(o instanceof Map){return addMapNode(group,(Map)o);}
		getDebugger().addNode(new Debug_TreeNode(group,o.toString()));
		if(o instanceof Exception){
			String exceptionName;
			if(o instanceof Exception_Nodeable){exceptionName=((Exception_Nodeable)o).getName();
			}else if(o instanceof Exception_InternalError){exceptionName=((Exception_InternalError)o).getMessage();
			}else{exceptionName="Exception";}
			getDebugger().getUnfilteredOutput().getHotspotPanel().createHotspot(getDebugger().getLastNodeAdded(),exceptionName);
		}
		return true;
	}
	public static boolean addNodeableNode(String group,Nodeable nodeable){
		nodeable.nodificate();
		return true;
	}
	public static Debug_TreeNode getLastNodeAdded(){return getDebugger().getLastNodeAdded();}
	public static boolean addCollectionNode(String group,Collection list){
		if(list.size()==0){return true;}
		Iterator iter=list.iterator();
		while(iter.hasNext()){addNode(iter.next());}
		return true;
	}
	public static boolean addMapNode(String group,Map map){
		if(map.size()==0){return true;}
		Iterator iter=map.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry=(Map.Entry)iter.next();
			addSnapNode(entry.getKey().toString(),entry.getValue());
		}
		return true;
	}
	public static boolean closeNode(){getDebugger().closeNode();return true;}
	public static boolean closeNode(Object string){
		addNode(string);
		closeNode();
		return true;
	}
	public static boolean ensureCurrentNode(String string){
		assert getDebugger().getUnfilteredCurrentNode().getData().equals(string):getDebugger().getUnfilteredCurrentNode().getData();
		return true;
	}
	public static boolean closeNode(String string,Object object){
		addSnapNode(string,object);
		closeNode();
		return true;
	}
	public static boolean closeNodeTo(String string){
		getDebugger().closeNodeTo(string);
		return true;
	}
	public static boolean printDebug(String category, Collection list){
		return printDebug(category,RiffToolbox.displayList(list));
	}
	public static boolean printDebug(String category){
		String slash="";
		int offset=0;
		if(category.charAt(0)=='/'){slash="/";offset++;}
		String[] categoryArray = category.split("/");
		return printDebug(category, "("+slash+categoryArray[1+offset]+":"+categoryArray[0+offset]+")");
	}
	public static boolean printDebug(String category, Object obj){return getDebugger().printDebug(category,obj);}
}
