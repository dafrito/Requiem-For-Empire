import java.util.*;
public class FauxTemplate_Line extends FauxTemplate implements ScriptConvertible,Nodeable{
	public static final String LINESTRING="Line";
	public Point_Absolute m_pointA,m_pointB;
	public FauxTemplate_Line(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,LINESTRING),ScriptValueType.createType(env,FauxTemplate_GraphicalElement.GRAPHICALELEMENTSTRING),new LinkedList<ScriptValueType>());
		m_pointA=new Point_Euclidean(getEnvironment(),0,0,0);
		m_pointB=new Point_Euclidean(getEnvironment(),0,0,0);
	}
	public void setPointA(Point_Absolute point){m_pointA=point;}
	public void setPointB(Point_Absolute point){m_pointB=point;}
	public Point_Absolute getPointA(){return m_pointA;}
	public Point_Absolute getPointB(){return m_pointB;}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.createType(getEnvironment(),FauxTemplate_Point.POINTSTRING)));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.createType(getEnvironment(),FauxTemplate_Point.POINTSTRING)));
		addConstructor(getType(),fxnParams);
		fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STRING));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Line Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_Line template=(FauxTemplate_Line)rawTemplate;
		ScriptValue_Abstract returning=null;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_Line(getEnvironment());}
			((FauxTemplate)getExtendedClass()).execute(ref,name,new LinkedList<ScriptValue_Abstract>(),template);
			List<ScriptValue_Abstract>fxnParams=FauxTemplate.createEmptyParamList();
			params.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.createType(getEnvironment(),FauxTemplate_Point.POINTSTRING)));
			template.addFauxFunction("setPointA",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("setPointB",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			template.addFauxFunction("getPointA",ScriptValueType.createType(getEnvironment(),FauxTemplate_Point.POINTSTRING),fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("getPointB",ScriptValueType.createType(getEnvironment(),FauxTemplate_Point.POINTSTRING),fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			params.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.DOUBLE));
			template.addFauxFunction("setX1",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("setY1",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("setX2",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("setY2",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			template.addFauxFunction("getX1",ScriptValueType.DOUBLE,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("getY1",ScriptValueType.DOUBLE,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("getX2",ScriptValueType.DOUBLE,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.addFauxFunction("getY2",ScriptValueType.DOUBLE,fxnParams,ScriptKeywordType.PUBLIC,false);
			switch(params.size()){
				case 0:
				assert Debugger.closeNode();
				return template;
				case 2:
				((FauxTemplate_Line)template).setPointA(Parser.getPoint(params.get(0)));
				((FauxTemplate_Line)template).setPointB(Parser.getPoint(params.get(1)));
				assert Debugger.closeNode();
				return template;
				case 4:
				((FauxTemplate_Line)template).setPointA(new Point_Euclidean(getEnvironment(),Parser.getDouble(params.get(0)).doubleValue(),Parser.getDouble(params.get(1)).doubleValue(),0));
				((FauxTemplate_Line)template).setPointB(new Point_Euclidean(getEnvironment(),Parser.getDouble(params.get(2)).doubleValue(),Parser.getDouble(params.get(3)).doubleValue(),0));
				assert Debugger.closeNode();
				return template;
				default:
				assert false:"Faux function undefined";
			}
		}else if(name.equals("getX1")){returning=Parser.getRiffDouble(getEnvironment(),template.getPointA().getX());
		}else if(name.equals("getY1")){returning=Parser.getRiffDouble(getEnvironment(),template.getPointA().getY());
		}else if(name.equals("getX2")){returning=Parser.getRiffDouble(getEnvironment(),template.getPointB().getX());
		}else if(name.equals("getY2")){returning=Parser.getRiffDouble(getEnvironment(),template.getPointB().getY());
		}else if(name.equals("setX1")){template.getPointA().setX(Parser.getDouble(params.get(0)).doubleValue());
		}else if(name.equals("setY1")){template.getPointA().setY(Parser.getDouble(params.get(0)).doubleValue());
		}else if(name.equals("setX2")){template.getPointB().setX(Parser.getDouble(params.get(0)).doubleValue());
		}else if(name.equals("setY2")){template.getPointB().setY(Parser.getDouble(params.get(0)).doubleValue());
		}else if(name.equals("getPointA")){
			returning=Parser.getRiffPoint(getEnvironment(),template.getPointA());
		}else if(name.equals("getPointB")){
			returning=Parser.getRiffPoint(getEnvironment(),template.getPointB());
		}else if(name.equals("setPointA")){template.setPointA(Parser.getPoint(params.get(0)));
		}else if(name.equals("setPointB")){template.setPointB(Parser.getPoint(params.get(0)));
		}else{returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);}
		assert Debugger.closeNode();
		return returning;
	}
	// ScriptConvertible and Nodeable implementations
	public Object convert(){
		return new GraphicalElement_Line(getEnvironment(),getPointA(),getPointB());
	}
	public boolean nodificate(){
		assert Debugger.openNode("Line Faux-Template");
		assert super.nodificate();
		assert Debugger.addNode("Point A: "+getPointA());
		assert Debugger.addNode("Point B: "+getPointB());
		assert Debugger.closeNode();
		return true;
	}
}
