public class IntangibleAsset extends Lot{
	public IntangibleAsset(ActiveAsset parent, Point point, Brand brand, double quality, double quantity){
		super(parent,point, brand, quality, quantity);
	}
	public IntangibleAsset(IntangibleAsset otherLot){
		this(otherLot.getParent(), otherLot.getPosition(), otherLot.getBrand(), otherLot.getQuality(), otherLot.getQuantity());
	}
	public Integer getAssetType(){return Asset.INTANGIBLEASSET;}
	public boolean isAssetOfType(Integer type){
		return(type.equals(getAssetType())||super.isAssetOfType(type));
	}
	public Asset cloneAsset(){return new IntangibleAsset(this);}
	public boolean mergeAsset(Asset asset){
		if(!asset.getAssetType().equals(Asset.INTANGIBLEASSET)){return false;}
		IntangibleAsset lot = (IntangibleAsset)asset;
		if(!lot.getBrand().equals(getBrand())){return false;}
		double grossQuality = m_quantity * m_quality;
		double lotQuality = lot.getQuality() * lot.getQuantity();
		m_quantity = m_quantity + lot.getQuantity();
		m_quality = (grossQuality + lotQuality) / m_quantity;
		return true;
	}
}
