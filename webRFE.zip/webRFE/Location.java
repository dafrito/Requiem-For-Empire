import java.util.*;
import java.io.Serializable;

public interface Location{
	public Set<Asset>getAllAssets();
	public void iterate(double time);
}

