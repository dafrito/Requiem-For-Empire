import java.util.*;
public class FauxTemplate_Panel extends FauxTemplate_InterfaceElement implements ScriptConvertible,Nodeable{
	public static final String PANELSTRING="Panel";
	private List<GraphicalElement>m_graphics=new LinkedList<GraphicalElement>();
	public FauxTemplate_Panel(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,PANELSTRING),ScriptValueType.createType(env,FauxTemplate_InterfaceElement.INTERFACEELEMENTSTRING),new LinkedList<ScriptValueType>());
	}
	public void add(GraphicalElement element){m_graphics.add(element);}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		addConstructor(getType(),fxnParams);
		fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Panel Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_Panel template=(FauxTemplate_Panel)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_Panel(getEnvironment());}
			((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
			List<ScriptValue_Abstract>fxnParams=ScriptValueType.createEmptyParamList();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.createType(getEnvironment(),FauxTemplate_GraphicalElement.GRAPHICALELEMENTSTRING)));
			template.addFauxFunction("add",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			assert Debugger.closeNode();
			return template;
		}else if(name.equals("add")){
			template.add(Parser.getGraphicalElement(params.get(0)));
			assert Debugger.closeNode();
			return null;
		}
		returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	// Nodeable and ScriptConvertible implementations
	public Object convert(){return new InterfaceElement_Panel(getEnvironment(),getUniqueStylesheet(),getClassStylesheet(),m_graphics);}
	public boolean nodificate(){
		assert Debugger.openNode("Panel Faux Template");
		assert super.nodificate();
		assert Debugger.addSnapNode("Elements",m_graphics);
		assert Debugger.closeNode();
		return true;
	}
}
