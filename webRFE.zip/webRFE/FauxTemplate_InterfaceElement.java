import java.util.*;
public class FauxTemplate_InterfaceElement extends FauxTemplate implements Nodeable{
	public static final String INTERFACEELEMENTSTRING="InterfaceElement";
	private Stylesheet m_unique,m_class;
	public FauxTemplate_InterfaceElement(ScriptEnvironment env,ScriptValueType type,ScriptValueType extended,List<ScriptValueType>implemented){
		super(env,type,extended,implemented);
	}
	public FauxTemplate_InterfaceElement(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,INTERFACEELEMENTSTRING),ScriptValueType.getObjectType(env),new LinkedList<ScriptValueType>());
	}
	public Stylesheet getUniqueStylesheet(){return m_unique;}
	public Stylesheet getClassStylesheet(){return m_class;}
	public void setClassStylesheet(Stylesheet classSheet){m_class=classSheet;}
	public void setUniqueStylesheet(Stylesheet unique){m_unique=unique;}
	public String getID(){return m_unique.getName();}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		addConstructor(getType(),fxnParams);
		fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Interface Element Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_InterfaceElement template=(FauxTemplate_InterfaceElement)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		ScriptValue_Abstract value;
		if(name==null||name.equals("")){
			if(template==null){throw new Exception_Nodeable_InvalidAbstractFunctionCall(ref,this);}
			((FauxTemplate)getExtendedClass()).execute(ref,name,new LinkedList<ScriptValue_Abstract>(),template);
			switch(params.size()){
				case 0:
				assert Debugger.closeNode();
				return template;
				// Intentionally out of order to allow for case 2 to run case 1's code.
				case 2:
				value=params.get(1);
				template.setClassStylesheet((Stylesheet)value.getValue());
				case 1:
				value=params.get(0);
				template.setUniqueStylesheet((Stylesheet)value.getValue());
				assert Debugger.closeNode();
				return template;
				default:
				assert false:"Faux function undefined";
			}
		}
		returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	// Nodeable implementation
	public boolean nodificate(){
		assert Debugger.openNode("Interface Element Faux Template");
		assert super.nodificate();
		assert Debugger.addSnapNode("Unique Stylesheet",m_unique);
		assert Debugger.addSnapNode("Class Stylesheet",m_class);
		assert Debugger.closeNode();
		return true;
	}
}
