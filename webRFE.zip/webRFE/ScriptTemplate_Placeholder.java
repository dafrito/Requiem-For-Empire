import java.util.List;
public class ScriptTemplate_Placeholder extends ScriptTemplate_Abstract implements ScriptValue_Abstract,Nodeable{
	private String m_name;
	private ScriptTemplate_Abstract m_template;
	public ScriptTemplate_Placeholder(ScriptEnvironment env,String name){
		super(env,null,null,null);
		m_name=name;
	}
	private ScriptTemplate_Abstract getTemplate(){
		if(m_template==null){m_template=getEnvironment().getTemplate(m_name);}
		assert m_template!=null:"Template could not be retrieved ("+m_name+")";
		return m_template;
	}
	// Abstract-value implementation
	public ScriptValueType getType(){return getTemplate().getType();}
	public boolean isConvertibleTo(ScriptValueType type){return getTemplate().isConvertibleTo(type);}
	public ScriptValue_Abstract castToType(Referenced ref,ScriptValueType type)throws Exception_Nodeable{return getTemplate().castToType(ref,type);}
	public ScriptValue_Abstract getValue()throws Exception_Nodeable{return getTemplate().getValue();}
	public ScriptValue_Abstract setValue(Referenced ref, ScriptValue_Abstract value)throws Exception_Nodeable{return getTemplate().setValue(ref,value);}
	public boolean valuesEqual(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{return getTemplate().valuesEqual(ref,rhs);}
	public int valuesCompare(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{return getTemplate().valuesCompare(ref,rhs);}
	// Nodeable implementation
	public boolean nodificate(){
		assert Debugger.openNode("Template Placeholder ("+m_name+")");
		assert Debugger.addSnapNode("Referenced Template",getTemplate());
		assert Debugger.closeNode();
		return true;
	}
	// Abstract-template implementation
	public boolean isFullCreation(){return getTemplate().isFullCreation();}
	public void setFullCreation(boolean fullCreation){getTemplate().setFullCreation(fullCreation);}
	public boolean isConstructing()throws Exception_Nodeable{return getTemplate().isConstructing();}
	public void setConstructing(boolean constructing)throws Exception_Nodeable{getTemplate().setConstructing(constructing);}
	public boolean isObject(){return getTemplate().isObject();}
	public boolean isAbstract()throws Exception_Nodeable{return getTemplate().isAbstract();}
	public ScriptValue_Variable getStaticReference()throws Exception_Nodeable{return getTemplate().getStaticReference();}
	public ScriptTemplate createObject(Referenced ref,ScriptTemplate object)throws Exception_Nodeable{return getTemplate().createObject(ref,object);}
	public ScriptValue_Variable addVariable(Referenced ref,String name,ScriptValue_Variable value)throws Exception_Nodeable{return getTemplate().addVariable(ref,name,value);}
	public ScriptValue_Variable getVariable(String name)throws Exception_Nodeable{return getTemplate().getVariable(name);}
	public void addFunction(Referenced ref,String name,ScriptFunction_Abstract function)throws Exception_Nodeable{getTemplate().addFunction(ref,name,function);}
	public List<ScriptFunction_Abstract>getFunctions(){return getTemplate().getFunctions();}
	public ScriptFunction_Abstract getFunction(String name,List<ScriptValue_Abstract>params){return getTemplate().getFunction(name,params);}
	public void addTemplatePreconstructorExpression(ScriptExecutable exec)throws Exception_Nodeable{getTemplate().addTemplatePreconstructorExpression(exec);}
	public void addPreconstructorExpression(ScriptExecutable exec)throws Exception_Nodeable{getTemplate().addPreconstructorExpression(exec);}
	public void initialize()throws Exception_Nodeable{getTemplate().initialize();}
	public void initializeFunctions(Referenced ref)throws Exception_Nodeable{getTemplate().initializeFunctions(ref);}
	// Overloaded ScriptTemplate_Abstract fxns
	public ScriptTemplate_Abstract getExtendedClass(){return getTemplate().getExtendedClass();}
	public List<ScriptValueType>getInterfaces(){return getTemplate().getInterfaces();}
}
