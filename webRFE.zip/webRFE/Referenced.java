public interface Referenced{
	public ScriptElement getDebugReference();
	public ScriptEnvironment getEnvironment();
}
