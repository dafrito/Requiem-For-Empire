import java.util.*;

public class Identity{
	private Map<Personality,Integer>m_personalityAffinities;
	private Map<Identity,Integer>m_identityAffinities;
	private Map<Organization,Integer>m_organizationAffinities;
	private String m_name;
	public Identity(){
		m_name=new String();
		m_personalityAffinities = new HashMap<Personality,Integer>();
		m_identityAffinities = new HashMap<Identity,Integer>();
		m_organizationAffinities = new HashMap<Organization,Integer>();
	}
	public Identity(String name){
		m_name=name;
		m_personalityAffinities = new HashMap<Personality,Integer>();
		m_identityAffinities = new HashMap<Identity,Integer>();
		m_organizationAffinities = new HashMap<Organization,Integer>();
	}
	public String getName(){return m_name;}
	public boolean setName(String name){m_name = name; return true;}
	public Map<Personality,Integer>getPersonalityAffinities(){return m_personalityAffinities;}
	public Map<Identity,Integer>getIdentityAffinities(){return m_identityAffinities;}
	public Map<Organization,Integer>getOrganizationAffinities(){return m_organizationAffinities;}
	public boolean addAffinity(Personality personality, Integer affinity){
		m_personalityAffinities.put(personality, affinity);
		return true;
	}
	public boolean addAffinity(Identity identity, Integer affinity){
		m_identityAffinities.put(identity, affinity);
		return true;
	}
	public boolean addAffinity(Organization organization, Integer affinity){
		m_organizationAffinities.put(organization, affinity);
		return true;
	}
	/* TODO: Nodificate
	public String toString(){
		String string = new String();
		string += "Identity: " + m_name + "\n";
		string += "Personality Affinities:\n";
		Iterator iter = m_personalityAffinities.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			string += (Integer)entry.getValue() + " affinity for the personality, " + ((Personality)entry.getKey()).getFormalName() + "\n";
			
		}
		iter = m_identityAffinities.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			string += (Integer)entry.getValue() + " affinity for the identity, " + ((Identity)entry.getKey()).getName() + "\n";
		}
		iter = m_organizationAffinities.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			string += (Integer)entry.getValue() + " affinity for the organization, " + ((Organization)entry.getKey()).getFormalName() + "\n";
		}
		return string;
	}*/
}
