import java.util.*;

public class RiffCommodities{
	private static Map<String,Commodity>m_commodityMap = new HashMap<String,Commodity>(); // Commodity-name, Commodity
	public static void addCommodity(Commodity commodity){
		RiffCommodities.m_commodityMap.put(commodity.getName(),commodity);
	}
	public static Commodity getCommodity(String commodityName){
		return RiffCommodities.m_commodityMap.get(commodityName);
	}
}
