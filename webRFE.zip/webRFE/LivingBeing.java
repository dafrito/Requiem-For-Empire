import java.util.*;

public interface LivingBeing{
	public void iterate(double iterationTime);
	public void addOrder(Order order);
}
