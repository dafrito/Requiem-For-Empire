import java.util.*;
public class FauxTemplate_Label extends FauxTemplate_InterfaceElement implements ScriptConvertible,Nodeable{
	private String m_label;
	public static String LABELSTRING="Label";
	public FauxTemplate_Label(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,LABELSTRING),ScriptValueType.createType(env,FauxTemplate_InterfaceElement.INTERFACEELEMENTSTRING),new LinkedList<ScriptValueType>());
	}
	public void setLabel(String label){m_label=label;}
	public String getLabel(){return m_label;}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STRING));
		addConstructor(getType(),fxnParams);
		fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STRING));
		addConstructor(getType(),fxnParams);
		fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STRING));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref, String name, List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Label Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_Label template=(FauxTemplate_Label)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_Label(getEnvironment());}
			String label="";
			if(params.size()>0){
				label=Parser.getString(params.get(params.size()-1));
				params.remove(params.size()-1);
			}
			((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
			List<ScriptValue_Abstract>fxnParams=FauxTemplate.createEmptyParamList();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STRING));
			template.addFauxFunction("setLabel",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=FauxTemplate.createEmptyParamList();
			template.addFauxFunction("getLabel",ScriptValueType.STRING,fxnParams,ScriptKeywordType.PUBLIC,false);
			template.setLabel(label);
		}else if(name.equals("setLabel")){
			template.setLabel(Parser.getString(params.get(0)));
			assert Debugger.closeNode();
			return null;
		}else if(name.equals("getLabel")){
			returning=new ScriptValue_String(ref.getEnvironment(),template.getLabel());
			assert Debugger.closeNode();
			return returning;
		}
		returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	// Nodeable and ScriptConvertible implementations
	public Object convert(){return new InterfaceElement_Label(getEnvironment(),getUniqueStylesheet(),getClassStylesheet(),m_label);}
	public boolean nodificate(){
		assert Debugger.openNode("Label Faux-Template ("+getLabel()+")");
		assert super.nodificate();
		assert Debugger.closeNode();
		return true;
	}
}
