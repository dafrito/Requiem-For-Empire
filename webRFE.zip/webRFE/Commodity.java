import java.util.*;

public class Commodity extends UniqueObject{
	private Map<String,PrerequisiteLevel>m_prerequisites; // Commodity name, PrerequisiteLevel
	private final String m_name;
	private List<CommodityConversionEfficiency>m_parents; // list of CommodityConversionEfficiency's
	public Commodity(String name){
		m_name=name;
		m_prerequisites=new HashMap<String,PrerequisiteLevel>();
		m_parents=new Vector<CommodityConversionEfficiency>();
		RiffCommodities.addCommodity(this);
	}
	public String getName(){return m_name;}
	public List<PrerequisiteLevel>getAllPrerequisiteLevels(){return new LinkedList<PrerequisiteLevel>(m_prerequisites.values());}
	public PrerequisiteLevel getPrerequisiteLevel(String preString){return m_prerequisites.get(preString);}
	public void addPrerequisiteLevel(Commodity prereq, double quantity){
		m_prerequisites.put(prereq.getName(),new PrerequisiteLevel(prereq,quantity));
	}
	public void addPrerequisiteLevel(String prereq, double quantity){
		addPrerequisiteLevel(RiffCommodities.getCommodity(prereq),quantity);
	}
	public boolean hasParents(){if(m_parents==null||m_parents.size()==0){return false;}return true;}
	public void addParent(Commodity parent, double proficiency){m_parents.add(new CommodityConversionEfficiency(parent, proficiency));}
	public List<CommodityConversionEfficiency>getParentEfficiencies(){return m_parents;}
	public List<Commodity>getParentCommodities(){
		List<Commodity>list=new LinkedList<Commodity>();
		for(CommodityConversionEfficiency eff:m_parents){list.add(eff.getCommodity());}
		return list;
	}
	public int hashCode(){return m_name.hashCode();}
	/* TODO: Nodificate
	public String toString(){
		String string = new String();
		string += "Commodity: " + m_name + "\n";
		string += "Prerequisites: " + RiffToolbox.displayList(m_prerequisites.values());
		return string;
	}*/
}
