public class Brand extends UniqueObject implements Comparable{
	private double m_quality;
	private Commodity m_commodity;
	private String m_name;
	public Brand(String name, String commodityName, double quality){
		this(name, RiffCommodities.getCommodity(commodityName), quality);
	}
	public Brand(String name, Commodity commodity, double quality){
		super();
		m_name = name;
		m_quality = quality;
		if(RiffCommodities.getCommodity(commodity.getName()) != null){
			m_commodity = RiffCommodities.getCommodity(commodity.getName());
		}else{
			m_commodity = commodity;
		}
		RiffBrands.addBrand(this);
	}
	public String getName(){return m_name;}
	public double getQuality(){return m_quality;}
	public Commodity getCommodity(){return m_commodity;}
	public boolean equals(Object o){
		if(m_name.compareTo(((Brand)o).getName()) == 0){
			return true;
		}return false;
	}
	public int hashCode(){return m_name.hashCode();}
	public int compareTo(Object o){
		return m_name.compareTo(((Brand)o).getName());
	}
	public String toString(){return m_name;}
}
