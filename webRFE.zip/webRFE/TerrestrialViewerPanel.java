/*import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import java.lang.Math.*;
public class TerrestrialViewerPanel extends JPanel implements MouseMotionListener, MouseListener{
	private TerrestrialControllerPanel m_controller;
	private Terrestrial m_terrestrial;
	private Point_Absolute m_centerPoint;
	private java.util.Point m_initialClickPoint;
	private double m_zoomFactor;
	public TerrestrialViewerPanel(TerrestrialControllerPanel panel, Terrestrial terrestrial){
		m_controller=panel;
		m_terrestrial=terrestrial;
		m_terrestrial.addSurface(new RectangularArea(90.0d, 0.0d,90.0d,45.0d));
		m_terrestrial.addSurface(new RectangularArea(90.0d*3.0d, 0.0d,90.0d-RiffToolbox.DOUBLE_MIN,45.0d));
		m_centerPoint=new Point_Euclidean(0.0d,0.0d,0.0d);
		m_zoomFactor=1.0d;
		setBorder(BorderFactory.createLineBorder(Color.GRAY));
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	public void mouseMoved(MouseEvent e){}
	public void mouseDragged(MouseEvent e){
		double xOffset=e.getPoint().getX()-m_initialClickPoint.getX();
		double yOffset=e.getPoint().getY()-m_initialClickPoint.getY();
		m_initialClickPoint=e.getPoint();
		switch(m_controller.getSelectedTool()){
			case TerrestrialControllerPanel.HAND:
			m_centerPoint.translate(-xOffset, -yOffset, 0.0d);
		}
		repaint();
	}
	public void mouseClicked(MouseEvent e){
		switch(m_controller.getSelectedTool()){
			case TerrestrialControllerPanel.ZOOM:
			if(e.getButton()==MouseEvent.BUTTON1){
				m_zoomFactor*=2;
				double[]array=untransformPoint(e.getPoint().getX(), e.getPoint().getY());
				m_centerPoint.setPosition(array[0], array[1],0.0d);
				
			}
			if(e.getButton()==MouseEvent.BUTTON3){
				m_zoomFactor/=2;
				double[]array=untransformPoint(e.getPoint().getX(), e.getPoint().getY());
				m_centerPoint.setPosition(array[0], array[1],0.0d);
			}
			repaint();
		}
	}
	public double[] transformPoint(double x, double y){
		double[] array=new double[2];
		array[0]=m_zoomFactor*(x-m_centerPoint.getX())+getWidth()/2;
		array[1]=m_zoomFactor*(y-m_centerPoint.getY())+getHeight()/2;
		return array;
	}
	public double[] untransformPoint(double x, double y){
		double[] array=new double[2];
		array[0]=1*(x-getWidth()/2)/m_zoomFactor+m_centerPoint.getX();
		array[1]=1*(y-getHeight()/2)/m_zoomFactor+m_centerPoint.getY();
		return array;
	}
	public void mousePressed(MouseEvent e){m_initialClickPoint=e.getPoint();}
	public void mouseReleased(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	protected void clear(Graphics g){super.paintComponent(g);}
	private Polygon createPolygon(DiscreteRegion region){
		Iterator iter=region.getPoints().iterator();
		Polygon polygon=new Polygon();
		while(iter.hasNext()){
			Point_Absolute point=(Point_Absolute)iter.next();
			double[]array=transformPoint(point.getX(), point.getY());
			polygon.addPoint((int)array[0],(int)array[1]);
		}
		return polygon;
	}
	public void paintComponent(Graphics g){
		clear(g);
		if(m_terrestrial==null){
			g.dispose();return;
		}
		Graphics2D g2d = (Graphics2D)g;
		Iterator iter=m_terrestrial.getSurfaces().iterator();
		while(iter.hasNext()){
			g2d.setColor(new Color((float)Math.random(), (float)Math.random(), (float)Math.random()));
			RiffSurface surface=(RiffSurface)iter.next();
			java.util.List regions=surface.getPolygons(0.1d);
			Iterator regionIter=regions.iterator();
			while(regionIter.hasNext()){
				g2d.fillPolygon(createPolygon((DiscreteRegion)regionIter.next()));
			}
		}
		g2d.dispose();
	}
}*/
