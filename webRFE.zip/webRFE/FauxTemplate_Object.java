import java.util.*;
public class FauxTemplate_Object extends FauxTemplate implements ScriptConvertible,Nodeable{
	public static ScriptKeyword OBJECT;
	public static String OBJECTSTRING="Object";
	public FauxTemplate_Object(ScriptEnvironment env){
		super(env,ScriptValueType.getObjectType(env),null,new LinkedList<ScriptValueType>());
	}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract template)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Object Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){throw new Exception_Nodeable_InvalidAbstractFunctionCall(ref,this);}
			assert Debugger.closeNode();
			return template;
		}
		throw new Exception_Nodeable_FunctionNotFound(ref,name,params);
	}
	// ScriptConvertible and Nodeable implementations
	public Object convert(){return this;}
	public boolean nodificate(){
		assert Debugger.openNode("Object Faux Template");
		assert super.nodificate();
		assert Debugger.closeNode();
		return true;
	}
}
