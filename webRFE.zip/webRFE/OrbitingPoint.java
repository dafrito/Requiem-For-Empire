import java.lang.Math;

public class OrbitingPoint extends Point{
	private double m_xDistance, m_yDistance;
	private double m_yawVelocity;
	private double m_pitchVelocity;
	private double m_rollVelocity;
	//private float m_ellipseMagnitude; // From 0...1, 0 being a circle and 1 being a line.
	//private float m_ellipseRadian; // From 0...2*pi, the point at which the ellipse is at its maximum magnitude, irrelevant for circles.
	private double m_yaw; // The amount of rotation on the normal axis. (Spinning around its center is yaw.)
	private double m_pitch; // The amount of rotation on the transverse axis. (Pitching upwards, pitching downwards.)
	private double m_roll; // The amount of rotation on the longitudinal axis. (Banking to the left, to the right are rolling)
	public OrbitingPoint(Point focus, double xDistance, double yDistance, double yaw, double pitch, double roll, double yawVelocity, double pitchVelocity, double rollVelocity) throws LocationException{
		super(focus);
		m_xDistance = xDistance;
		m_yDistance = yDistance;
		m_yaw = yaw;
		m_pitch = pitch;
		m_roll = roll;
		m_yawVelocity = yawVelocity;
		m_pitchVelocity = pitchVelocity;
		m_rollVelocity = rollVelocity;
		calculateAbsolutePosition();
	}
	public void calculateAbsolutePosition(){
		/*Point3d point = new Point3d(0,0,0);
		point.setX((Math.cos(m_yaw) * m_xDistance) + m_focus.getAbsolutePosition().getX());
		point.setY((Math.sin(m_yaw) * m_yDistance) + m_focus.getAbsolutePosition().getY());
		Point3d point = new Point3d(0,0,0);
		point.setX(Math.cos(m_yaw) * m_distance);
		point.setY(Math.sin(m_yaw) * m_distance);
		m_point = point.addPoint(m_focus.getAbsolutePosition());
		/*point.setZ(Math.sin(m_pitch) * point.getX());
		point.setX(Math.cos(m_pitch) * point.getX());
		double holder = point.getZ();
		point.setZ(Math.sin(m_roll) * point.getY() + Math.cos(m_roll) * point.getZ());
		point.setY(Math.cos(m_roll) * point.getY() + Math.sin(m_roll) * holder);
		m_point = point;*/
		//m_point = point.addPoint(m_focus.getAbsolutePosition());
		Point_Absolute point = RiffPolygonToolbox.createPoint(m_point.getAbsolutePosition(), null, 0,0,0);
		point.setX((Math.cos(m_yaw) * m_xDistance) + ((Point_Euclidean)m_point.getAbsolutePosition()).getX());
		point.setY((Math.sin(m_yaw) * m_yDistance) + ((Point_Euclidean)m_point.getAbsolutePosition()).getY());
		m_point = point;
	}
	public void iterate(int iterationTime){
		m_yaw += m_yawVelocity * iterationTime;
		m_pitch += m_pitchVelocity * iterationTime;
		m_roll += m_rollVelocity * iterationTime;
		calculateAbsolutePosition();
	}
	public String toString(){
		String string = new String();
		string += super.toString();
		string += "\nOrbitingPoint";
		string += "\nX-Distance from focus: " + m_xDistance;
		string += "\nY-Distance from focus: " + m_yDistance;
		string += "\nYawing Speed in radians: " + m_yawVelocity;
		string += "\nPitching Speed in radians: " + m_pitchVelocity;
		string += "\nRolling speed in radians: " + m_rollVelocity;
		string += "\nYaw: " + m_yaw;
		string += "\nPitch: " + m_pitch;
		string += "\nRoll: " + m_roll;
		string += "\nCurrent point: " + getAbsolutePosition();
		return string;
	}
}
