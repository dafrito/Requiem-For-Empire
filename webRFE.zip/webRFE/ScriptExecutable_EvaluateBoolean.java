public class ScriptExecutable_EvaluateBoolean extends ScriptElement implements ScriptExecutable,ScriptValue_Abstract{
	private ScriptValue_Abstract m_lhs, m_rhs;
	private ScriptOperatorType m_comparison;
	public ScriptExecutable_EvaluateBoolean(Referenced ref,ScriptValue_Abstract lhs, ScriptValue_Abstract rhs, ScriptOperatorType comparison){
		super(ref);
		m_lhs=lhs;
		m_rhs=rhs;
		m_comparison=comparison;
	}
	// ScriptExecutable implementation
	public ScriptValue_Abstract execute()throws Exception_Nodeable{
		switch(m_comparison){
			case noneQUIVALENCY:return new ScriptValue_Boolean(getEnvironment(),!m_lhs.valuesEqual(this,m_rhs));
			case LESS:return new ScriptValue_Boolean(getEnvironment(),(m_lhs.valuesCompare(this,m_rhs)<0));
			case LESSEQUALS:return new ScriptValue_Boolean(getEnvironment(),(m_lhs.valuesCompare(this,m_rhs)<=0));
			case EQUIVALENCY:return new ScriptValue_Boolean(getEnvironment(),m_lhs.valuesEqual(this,m_rhs));
			case GREATEREQUALS:return new ScriptValue_Boolean(getEnvironment(),(m_lhs.valuesCompare(this,m_rhs)>=0));
			case GREATER:return new ScriptValue_Boolean(getEnvironment(),(m_lhs.valuesCompare(this,m_rhs)>0));
			default:assert false:"Invalid comparison";
		}
		return null;
	}
	// ScriptValue_Abstract implementation
	public ScriptValueType getType(){return ScriptValueType.BOOLEAN;}
	public boolean isConvertibleTo(ScriptValueType type){return getType().equals(type);}
	public ScriptValue_Abstract castToType(Referenced ref,ScriptValueType type)throws Exception_Nodeable{
		assert Debugger.addNode("Type Casting","Casting ("+getType()+" to "+type+")");
		if(getType().equals(type)){return this;}
		throw new Exception_Nodeable_ClassCast(ref,this,type);
	}
	public ScriptValue_Abstract getValue()throws Exception_Nodeable{return execute();}
	public ScriptValue_Abstract setValue(Referenced ref, ScriptValue_Abstract value)throws Exception_Nodeable{return getValue().setValue(ref,value);}
	public boolean valuesEqual(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{return getValue().valuesEqual(ref,rhs);}
	public int valuesCompare(Referenced ref, ScriptValue_Abstract rhs)throws Exception_Nodeable{return getValue().valuesCompare(ref,rhs);}
	// Nodeable implementation
	public boolean nodificate(){
		assert Debugger.openNode("Boolean Expression ("+ScriptOperator.getName(m_comparison)+")");
		assert super.nodificate();
		assert Debugger.addSnapNode("Left hand",m_lhs);
		assert Debugger.addSnapNode("Right hand",m_rhs);
		assert Debugger.closeNode();
		return true;
	}
}
