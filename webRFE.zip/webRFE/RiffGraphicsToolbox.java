import java.awt.Polygon;
import java.awt.geom.Line2D.Double;
import java.awt.Point;
import java.util.*;
import java.awt.Color;
import javax.swing.*;

public class RiffGraphicsToolbox{
	// Creates a Java-displayable polygon from the discreteRegion
	public static Polygon getPolygonFromDiscreteRegion(JPanel panel, DiscreteRegion region){
		Polygon poly = new Polygon();
		List pointList = region.getPoints();
		for(int i=0;i<pointList.size();i++){
			poly.addPoint((int)((Point_Absolute)pointList.get(i)).getX(),panel.getHeight()-(int)((Point_Absolute)pointList.get(i)).getY());
		}
		return poly;
	}
	// Converts a Java-point to a RiffPoint
	public static Point_Absolute convertPointToEuclidean(Point point){
		return new Point_Euclidean(point.getX(), point.getY(),0);
	}
	public static Color getDiscreteRegionColor(DiscreteRegion region){
		Terrain terrain = (Terrain)region.getAssetMap().getAsset(Asset.TERRAIN);
		if(terrain!=null){return new Color(0.8f- .7f*(float)terrain.getBrushDensity(), 1.0f, 0.0f);}
		return Color.BLUE;
	}
	public static java.awt.geom.Line2D.Double getLineFromPoints(Point_Absolute pointA, Point_Absolute pointB){
		return new java.awt.geom.Line2D.Double(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY());
	}
	// Creates a list of lines from the discreteRegion
	public static List<java.awt.geom.Line2D.Double> getLineListFromDiscreteRegion(DiscreteRegion region){
		List<java.awt.geom.Line2D.Double>list = new LinkedList<java.awt.geom.Line2D.Double>();
		for(int i=0;i<region.getPoints().size();i++){
			Point_Absolute pointA = (Point_Absolute)region.getPoints().get(i);
			Point_Absolute pointB = (Point_Absolute)region.getPoints().get((i+1)%region.getPoints().size());
			list.add(new java.awt.geom.Line2D.Double(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY()));
		}
		return list;
	}
}
