import java.util.*;
public class FauxTemplate_Interface extends FauxTemplate implements Nodeable{
	public static String INTERFACESTRING="Interface";
	private InterfaceElement_Root m_rootElement;
	public FauxTemplate_Interface(ScriptEnvironment env,InterfaceElement_Root rootElement){
		super(env,ScriptValueType.createType(env,INTERFACESTRING),ScriptValueType.getObjectType(env),new LinkedList<ScriptValueType>());
		m_rootElement=rootElement;
	}
	public InterfaceElement_Root getRootElement(){return m_rootElement;}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		List<ScriptValue_Abstract>fxnParams=FauxTemplate.createEmptyParamList();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.createType(getEnvironment(),FauxTemplate_InterfaceElement.INTERFACEELEMENTSTRING)));
		addFauxFunction("add",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Interface Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_Interface template=(FauxTemplate_Interface)rawTemplate;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name.equals("add")){
			template.getRootElement().add(Parser.getInterfaceElement(params.get(0)));
			assert Debugger.closeNode();
			return null;
		}
		ScriptValue_Abstract returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	public boolean nodificate(){
		assert Debugger.openNode("Interface Faux Template");
		assert super.nodificate();
		assert Debugger.addSnapNode("Root Element",getRootElement());
		assert Debugger.closeNode();
		return true;
	}
}
