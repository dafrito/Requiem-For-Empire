import java.awt.event.*;
import javax.swing.*; // For JPanel, etc.
import java.io.*;
import java.util.*;
import java.awt.*;

public class InterfaceElement_Page extends JPanel implements MouseListener,MouseMotionListener{
	private InterfaceElement_Root m_rootElement;
	private int m_lastX,m_lastY;
	private RiffInterface_MouseListener.MouseButton m_lastButton;
	public InterfaceElement_Page(ScriptEnvironment env){
		m_rootElement=new InterfaceElement_Root(env,this);
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	public InterfaceElement_Root getRoot(){return m_rootElement;}
	public void paintComponent(Graphics g){
		Graphics2D g2d=(Graphics2D)g;
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		m_rootElement.paint(g2d);
		g2d.dispose();
	}
	protected void clear(Graphics g){super.paintComponent(g);}
	public void mousePressed(MouseEvent e){
		RiffInterface_MouseDownEvent event=new RiffInterface_MouseDownEvent(e.getX(),e.getY(),RiffJavaToolbox.getRiffButton(e.getButton()));
		assert Debugger.addNode(event);
		m_rootElement.dispatchMouseEvent(event);
		m_lastX=e.getX();
		m_lastY=e.getY();
		m_lastButton=RiffJavaToolbox.getRiffButton(e.getButton());
	}
	public void mouseClicked(MouseEvent e){
		RiffInterface_ClickEvent event=new RiffInterface_ClickEvent(e.getX(),e.getY(),RiffJavaToolbox.getRiffButton(e.getButton()),e.getClickCount());
		assert Debugger.addNode(event);
		m_rootElement.dispatchMouseEvent(event);
		m_lastX=e.getX();
		m_lastY=e.getY();
		m_lastButton=RiffJavaToolbox.getRiffButton(e.getButton());
	}
	public void mouseReleased(MouseEvent e){
		RiffInterface_MouseUpEvent event=new RiffInterface_MouseUpEvent(e.getX(),e.getY(),RiffJavaToolbox.getRiffButton(e.getButton()));
		assert Debugger.addNode(event);
		m_rootElement.dispatchMouseEvent(event);
		m_lastX=-1;
		m_lastY=-1;
	}
	public void mouseDragged(MouseEvent e){
		double distance=RiffToolbox.getDistance(m_lastX,m_lastY,e.getX(),e.getY());
		if(e.getX()-m_lastX<0){distance*=-1;}
		if(e.getX()==m_lastX&&e.getY()-m_lastY<0&&distance>0){distance*=-1;}
		RiffInterface_DragEvent event=new RiffInterface_DragEvent(e.getX(),e.getY(),m_lastButton,e.getX()-m_lastX,e.getY()-m_lastY,distance);
		assert Debugger.addNode(event);
		m_rootElement.dispatchMouseEvent(event);
		m_lastX=e.getX();
		m_lastY=e.getY();
	}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseMoved(MouseEvent e){}
	
}
