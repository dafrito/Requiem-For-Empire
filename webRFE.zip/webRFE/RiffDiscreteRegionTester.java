import java.util.*;

public class RiffDiscreteRegionTester{

	public static void main(String[] args){
		DiscreteRegion regionA = new DiscreteRegion();
		regionA.addPoint(new Point_Euclidean("E", 50,50,0));
		regionA.addPoint(new Point_Euclidean("F", 250,50,0));
		regionA.addPoint(new Point_Euclidean("G", 250,250,0));
		regionA.addPoint(new Point_Euclidean("H", 50,250,0));
		DiscreteRegionBSPNode root = new DiscreteRegionBSPNode(regionA);
		DiscreteRegion regionB = new DiscreteRegion();
		regionB.addPoint(new Point_Euclidean("A", 50,50,0));
		regionB.addPoint(new Point_Euclidean("B", 250,50,0));
		regionB.addPoint(new Point_Euclidean("C", 250,250,0));
		root=RiffPolygonToolbox.removeOverlappingPolygons(root, regionB, true);
		System.out.println("After removal: " + root.getPolyList());
	}
}
