public class IntersectionPoint{
	private Point_Absolute m_point;
	private boolean m_isTangent;
	public IntersectionPoint(Point_Absolute point, boolean isTangent){
		m_isTangent=isTangent;
		m_point=point;
	}
	public Point_Absolute getPoint(){return m_point;}
	public boolean isTangent(){return m_isTangent;}
	public String toString(){
		String string = new String();
		string += "IntersectionPoint: ";
		string += "\nPoint: " + m_point;
		string += "\nIs tangent: " + m_isTangent;
		return string;
	}
}
