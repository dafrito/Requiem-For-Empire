public interface Returnable{
	// Returnable implementation
	public boolean shouldReturn();
	public ScriptValue_Abstract getReturnValue()throws Exception_Nodeable;
}
