import java.util.*;
public class FauxTemplate_DiscreteRegion extends FauxTemplate_GraphicalElement implements ScriptConvertible,Nodeable{
	public static final String DISCRETEREGIONSTRING="DiscreteRegion";
	private DiscreteRegion m_region;
	private java.awt.Color m_color;
	public FauxTemplate_DiscreteRegion(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,DISCRETEREGIONSTRING),ScriptValueType.createType(env,FauxTemplate_GraphicalElement.GRAPHICALELEMENTSTRING),new LinkedList<ScriptValueType>());
		m_region=new DiscreteRegion();
	}
	public List<Point_Absolute>getPoints(){return Collections.unmodifiableList(m_region.getPoints());}
	public void add(Point_Absolute point){m_region.addPoint(point);}
	public DiscreteRegion getRegion(){return m_region;}
	public void setRegion(DiscreteRegion region){m_region=region;}
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),getType()));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Discrete Region Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_DiscreteRegion template=(FauxTemplate_DiscreteRegion)rawTemplate;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_DiscreteRegion(getEnvironment());}
			((FauxTemplate)getExtendedClass()).execute(ref,name,new LinkedList<ScriptValue_Abstract>(),template);
			List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.createType(getEnvironment(),FauxTemplate_Point.POINTSTRING)));
			((FauxTemplate)template).addFauxFunction("add",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			fxnParams=new LinkedList<ScriptValue_Abstract>();
			fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STRING));
			((FauxTemplate)template).addFauxFunction("setColor",ScriptValueType.VOID,fxnParams,ScriptKeywordType.PUBLIC,false);
			if(params.size()==0){
				assert Debugger.closeNode();
				return template;
			}
			if(params.size()==1){
				template.setRegion(Parser.getDiscreteRegion(params.get(0)));
				assert Debugger.closeNode();
				return template;
			}
			assert false:"Faux function undefined";
		}else if(name.equals("add")){
			//m_region.addPoint(Parser.getPoint(aaron is a sand jewparams.get(0)));
			if(params.size()==1){
				template.add(Parser.getPoint(params.get(0)));
				assert Debugger.closeNode();
				return null;
			}
			assert false:"Faux function undefined";
		}else if(name.equals("setColor")){
			if(params.size()==1){
				m_color=RiffJavaToolbox.getColor(Parser.getString(params.get(0)));
				assert Debugger.closeNode();
				return null;
			}
			assert false:"Faux function undefined";
		}
		ScriptValue_Abstract returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	// Nodeable and ScriptConvertible interfaces
	public Object convert(){return new GraphicalElement_DiscreteRegion(getEnvironment(),m_region);}
	public boolean nodificate(){
		assert Debugger.openNode("Discrete Region Faux Script-Element");
		assert super.nodificate();
		assert Debugger.addNode(m_region);
		assert Debugger.closeNode();
		return true;
	}
}
