public class OwnershipClaim extends Stipulation{
	protected Asset m_claimedObject;
	public static final String m_stipulationType = "Ownership Claim";
	public OwnershipClaim(Asset claim){
		m_claimedObject = claim;
	}
	public Asset getClaimedObject(){return m_claimedObject;}
	public Organization getClaimer(){return m_relationship.getFirstSigner();}
	public String getStipulationType(){return m_stipulationType;}
	public String toString(){
		String string = new String();
		if(m_relationship.getFirstSigner() == null && m_claimedObject == null){return "No signers and/or no claimed locations";}
		//string += m_relationship.getFirstSigner().getFormalName();
		//string += " claims the " + m_claimedObject.getFormalName() + ".";
		return string;
	}
	public boolean equals(Object stip){
		if(m_stipulationType != ((Stipulation)stip).getStipulationType()){
			return false;
		}
		if(getClaimer() != ((OwnershipClaim)stip).getClaimer()){
			return false;
		}
		if(getClaimedObject() != ((OwnershipClaim)stip).getClaimedObject()){
			return false;
		}
		return true;
	}
}
