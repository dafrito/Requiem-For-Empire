public interface Tangible{
	public void setPosition(Point location);
	public Point getPosition();
	public ActiveAsset getParent();
	public void setParent(ActiveAsset parent);
}
