import java.util.*;
import javax.swing.*;

public class SplitterThread extends Thread{
	private String m_statusText;
	private JPanel m_panel;
	private DiscreteRegionBSPNode m_root;
	private Set<DiscreteRegion>m_regions;
	private boolean m_recurse;
	public SplitterThread(JPanel panel, DiscreteRegionBSPNode root, DiscreteRegion region, boolean recurse){
		super("Overlapping Splitter Pipeline");
		m_panel=panel;
		m_regions=new HashSet<DiscreteRegion>();
		m_regions.add(region);
		m_root=root;
		m_recurse=recurse;
		m_statusText=new String();
	}
	public SplitterThread(JPanel panel, DiscreteRegionBSPNode root, Collection<DiscreteRegion>regions, boolean recurse){
		super("Overlapping Splitter Pipeline");
		m_panel=panel;
		m_regions=new HashSet<DiscreteRegion>(regions);
		m_root=root;
		m_recurse=recurse;
		m_statusText=new String();
	}
	public synchronized DiscreteRegionBSPNode getRoot(){return m_root;}
	public synchronized String getStatusText(){return m_statusText;}
	public synchronized void setStatusText(String text){m_statusText=text;}
	public void run(){
		assert Debugger.printDebug("SplitterThread/run", "(splitterThreadRun)");
		setStatusText("Process started.");
		long time = System.currentTimeMillis();
		assert Debugger.printDebug("SplitterThread/run", "Regions: " + RiffToolbox.displayList(m_regions));
		Iterator iter=m_regions.iterator();
		while(iter.hasNext()){
			DiscreteRegion region = (DiscreteRegion)iter.next();
			List regionPoints = region.getPoints();
			if(m_root==null){
				assert Debugger.printDebug("SplitterThread/run", "Creating new root node.");
				RiffPolygonToolbox.optimizePolygon(region);
				m_root = new DiscreteRegionBSPNode(region);
				m_regions.remove(region);
				m_root.addToTempList(m_regions);
				iter=m_regions.iterator();
			}else{
				assert Debugger.printDebug("SplitterThread/run", "Adding region...");
				m_root=RiffPolygonToolbox.removeOverlappingPolygons(m_root, region, m_recurse);
			}
			if(!m_recurse){break;}
		}
		if(m_recurse){
			Set<DiscreteRegion>polygons = m_root.getPolyList();
			Iterator polyIter = m_root.getPolyList().iterator();
			Set<DiscreteRegion>neighbors = new HashSet<DiscreteRegion>();
			m_root.clearTempList();
			for(DiscreteRegion thisRegion:m_root.getPolyList()){
				thisRegion.resetNeighbors();
				thisRegion.addRegionNeighbors(polygons);
			}
			if(!neighbors.equals(m_root.getPolyList())){
				assert Debugger.printDebug("SplitterThread/run/error", "*** ERROR: Neighbors list does not match poly-list.");
				assert Debugger.printDebug("SplitterThread/run/error", "Neighbors list size: " + neighbors.size());
				assert Debugger.printDebug("SplitterThread/run/error", "Polygon list size: " + m_root.getPolyList().size());
				neighbors.removeAll(m_root.getPolyList());
				assert Debugger.printDebug("SplitterThread/run/error", "Offending polygons: " + neighbors);
				m_root.clearTempList();
				m_root.addToTempList(neighbors);
			}
		}
		time = System.currentTimeMillis() - time;
		setStatusText("Process complete. Time taken: " + ((double)time)/1000.0d + " seconds");
		System.gc();
		System.gc();
		m_panel.repaint();
		assert Debugger.printDebug("SplitterThread/run", "(/splitterThreadRun)");
	}
}
