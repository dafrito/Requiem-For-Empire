import java.util.*;
import java.io.*;

public class Terrestrial extends Point implements Location, Serializable{
	private double m_radius;
	private Set<RiffSurface>m_terrainSurfaces=new HashSet<RiffSurface>();
	private DiscreteRegionBSPNode m_tree;
	public Terrestrial(String name, String formal, String adjective, Point offsetPoint, double radius) throws OverwriteException{
		super(name, formal, adjective, offsetPoint);
		m_radius=radius;
	}
	public Set<Asset>getAllAssets(){
		return m_tree.getAllAssets();
	}
	public DiscreteRegion findPolygon(Point point){
		return m_tree.findPolygon(point);
	}
	public double getRadius(){return m_radius;}
	public Set<RiffSurface>getSurfaces(){return m_terrainSurfaces;}
	public void addSurface(RiffSurface surface){
		m_terrainSurfaces.add(surface);
	}
	public void removeSurface(RiffSurface surface){
		m_terrainSurfaces.remove(surface);
	}
	public void iterate(double iterationTime){}
	public String toString(){
		String string = new String();
		string += super.toString();
		return string;
	}
}
