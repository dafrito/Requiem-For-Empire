public class Point extends NamedElement implements Comparable{
	protected Point m_point;
	protected String m_pointName;
	public Point(){}
	public Point(String name, String formal, String adj, Point point){
		super(name, formal, adj);
		m_point=point;
	}
	public Point(Point point){
		m_point = point;
	}
	public String getName(){return m_pointName;}
	public void setName(String name){m_pointName=name;}
	public double getOverlap(Point point){return m_point.getOverlap(point);}
	public Point_Absolute getAbsolutePosition(){return m_point.getAbsolutePosition();}
	public void iterate(int iterationTime){m_point.iterate(iterationTime);}
	public int compareTo(Object obj){
		return getAbsolutePosition().compareTo(((Point)obj).getAbsolutePosition());
	}
	public boolean equals(Object obj){
		return getAbsolutePosition().equals(((Point)obj).getAbsolutePosition());
	}
	public String toString(){
		String string = new String();
		string += "Point:";
		string += "\nPoint: " + m_point;
		return string;
	}
}
