public class LoopingOrder extends Order{
	Order m_order;
	public LoopingOrder(Order order){
		m_order=order;
	}
	public void execute(double iterationTime) throws OrderException{
		super.execute(iterationTime);
		while(getIterationTime()>0){
			m_order.execute(getIterationTime());
		}
	}
	public String toString(){
		String string = new String();
		string += "Looping this Order: " + m_order;
		return string;
	}
}
