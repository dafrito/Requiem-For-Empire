import java.util.*;

public class QuantityProductionOrder extends Order{
	private double m_totalQuantity, m_remainingQuantity;
	private Brand m_product;
	private ActiveAsset m_activeAsset;
	public QuantityProductionOrder(ActiveAsset activeAsset, Brand product, double totalQuantity){
		m_product = product;
		m_remainingQuantity = m_totalQuantity = totalQuantity;
		m_activeAsset = activeAsset;
	}
	public Brand getBrand(){return m_product;}
	public Commodity getCommodity(){return m_product.getCommodity();}
	public double getTotalQuantity(){return m_totalQuantity;}
	public double getRemainingQuantity(){return m_remainingQuantity;}
	public void setQuantity(double quant){
		m_remainingQuantity -= m_totalQuantity - quant;
	}
	public void execute() throws OrderException{
		if(m_totalQuantity != -1 && m_remainingQuantity < 0){setStatus(OrderStatus.COMPLETE);return;}
		ProductionAction.execute(this);
	}
	public ActiveAsset getActiveAsset(){return m_activeAsset;}
	public String toString(){
		String string = new String();
		string += "Order: QuantityProductionOrder";
		string += "\nThe active asset listed below is to produce " + getTotalQuantity() + " units of the product listed below.";
		string += "\nThe order has " + getRemainingQuantity() + " units remaining to be made.";
		string += "\nActive asset: " + m_activeAsset;
		string += "\nProduct: " + m_product;
		return string;
	}
}
