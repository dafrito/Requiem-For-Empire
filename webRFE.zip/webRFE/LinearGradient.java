import java.lang.Math;
import java.util.*;

public class LinearGradient extends RiffSurface{
	private double m_exponent;
	private double m_radius;
	private static final int m_polygonVertices = 4;
	public LinearGradient(Point focus, double radius, double exponent){
		m_point = focus;
		m_radius = radius;
		m_exponent = exponent;
	}
	public LinearGradient(Terrain terrain, Point focus, double radius, double exponent){
		super(terrain);
		m_point = focus;
		m_radius = radius;
		m_exponent = exponent;
	}
	public double getRadius(){return m_radius;}
	public List<DiscreteRegion>getPolygons(double gradientPrecision){
		List<DiscreteRegion>list = new LinkedList<DiscreteRegion>();
		double radius =0;
		DiscreteRegion lastRegion = null;
		for(double i=1.0d; i>0.0d; i -= gradientPrecision){
			assert Debugger.addNode("Entering sequence. i is at: " + i);
			radius += gradientPrecision * m_radius;
			DiscreteRegion newRegion = new DiscreteRegion();
			try{
				newRegion.getAssetMap().add(getTerrain().createTerrainOfIntensity(i));
			}catch(CommodityMapException ex){
				Debugger.printException(ex);
			}
			for(int j=0;j<LinearGradient.m_polygonVertices;j++){
				double radianOffset = ((Math.PI * 2)/m_polygonVertices) * j;
				double longOffset = Math.cos(radianOffset) * radius;
				double latOffset = Math.sin(radianOffset) * radius;
				newRegion.addPoint(new RiffSpherePoint(((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() + longOffset, ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() + latOffset,0.0d));				
			}
			if(lastRegion==null){
				list.add(newRegion);
				lastRegion=newRegion;
			}else{
				DiscreteRegion fullRegion = new DiscreteRegion();
				for(int q=0;q<=lastRegion.getPoints().size()/2;q++){
					fullRegion.getPoints().add(lastRegion.getPoints().get(q));
				}
				for(int q=0;q<=newRegion.getPoints().size()/2;q++){
					fullRegion.getPoints().add(newRegion.getPoints().get((newRegion.getPoints().size()/2)- q));
				}
				lastRegion=newRegion;
				list.add(fullRegion);
			}
		}
		return list;
	}
	public Point_Absolute getFocus(){return getAbsolutePosition();}
	public double getOverlap(Point testPoint){
		double distance = RiffToolbox.getDistance(getAbsolutePosition(), testPoint);
		if(Math.abs(distance) > m_radius || m_exponent == 0){return 0.0d; }
		return Math.abs(Math.pow(distance / m_radius,m_exponent)-1.0d);
	}
	public double getLeftExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() - m_radius;}
	public double getRightExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() + m_radius;}
	public double getTopExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() + m_radius;}
	public double getBottomExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() - m_radius;}
	public String toString(){
		String string = new String();
		string += "Spherical Gradient\n";
		string += "Focus: " + getAbsolutePosition();
		string += "\nRadius: " + m_radius;
		return string;
	}
}
		
