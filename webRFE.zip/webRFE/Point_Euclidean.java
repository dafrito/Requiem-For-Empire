public class Point_Euclidean extends Point_Absolute implements ScriptConvertible{
	private double m_x, m_y, m_z;
	private static int m_pointNum=0;
	private ScriptEnvironment m_environment;
	public ScriptEnvironment getEnvironment(){return m_environment;}
	public Point_Euclidean(ScriptEnvironment env,double x, double y, double z){
		m_environment=env;
		m_x=x;m_y=y;m_z=z;
	}
	public Point_Euclidean(ScriptEnvironment env,String name,double x, double y, double z){
		this(name,name,null,x,y,z);
		m_environment=env;
	}
	public Point_Euclidean(double x,double y){
		this(x,y,0.0d);
	}
	public Point_Euclidean(double x,double y,double z){
		m_x=x;
		m_y=y;
		m_z=z;
	}
	public Point_Euclidean(String name,double x,double y,double z){
		super(name,name,null);
		m_x=x;
		m_y=y;
		m_z=z;
	}
	public Point_Euclidean(String name, String formal, String adj, double x, double y, double z){
		super(name, formal, adj);
		m_pointNum++;
		m_x=x;
		m_y=y;
		m_z=z;
	}
	public boolean equals(Object o){
		Point_Euclidean testPoint=(Point_Euclidean)((Point)o).getAbsolutePosition();
		return(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, m_x,testPoint.getX())&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, m_y,testPoint.getY())&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, m_z,testPoint.getZ()));
	}
	public int compareTo(Object o){
		Point_Euclidean testPoint = (Point_Euclidean)((Point)o).getAbsolutePosition();
		if(m_x>testPoint.getX()){return 1;}
		if(m_x<testPoint.getX()){return -1;}
		if(m_y>testPoint.getY()){return 1;}
		if(m_y<testPoint.getY()){return -1;}
		if(m_z>testPoint.getZ()){return 1;}
		if(m_z<testPoint.getZ()){return -1;}
		return 0;
	}
	public void addX(double x){m_x+=x;}
	public void addY(double y){m_y+=y;}
	public void addZ(double z){m_z+=z;}
	public void setX(double x){m_x=x;}
	public void setY(double y){m_y=y;}
	public void setZ(double z){m_z=z;}
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public String toString(){
		String string = new String();
		string += "(" + m_x;
		string += ", " + m_y;
		string += ", " + m_z + ")";
		return string;
	}
	public Object convert(){
		FauxTemplate_Point point=new FauxTemplate_Point(getEnvironment());
		point.setX(getX());
		point.setY(getY());
		point.setZ(getZ());
		return point;
	}
}
