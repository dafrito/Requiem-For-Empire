import java.util.*;
public class FauxTemplate_Rectangle extends FauxTemplate_InterfaceElement implements ScriptConvertible,Nodeable{
	public static String RECTANGLESTRING="Rectangle";
	public FauxTemplate_Rectangle(ScriptEnvironment env){
		super(env,ScriptValueType.createType(env,RECTANGLESTRING),ScriptValueType.createType(env,FauxTemplate_InterfaceElement.INTERFACEELEMENTSTRING),new LinkedList<ScriptValueType>());
	}
	// addFauxFunction(name,ScriptValueType type,List<ScriptValue_Abstract>params,ScriptKeywordType permission,boolean isAbstract)
	// Static functions must be defined here, but ALL functions will be called through execute, including constructors
	public void initialize()throws Exception_Nodeable{
		getExtendedClass().initialize();
		setFullCreation(true);
		addConstructor(getType(),ScriptValueType.createEmptyParamList());
		List<ScriptValue_Abstract>fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		addConstructor(getType(),fxnParams);
		fxnParams=new LinkedList<ScriptValue_Abstract>();
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		fxnParams.add(new ScriptValue_Faux(getEnvironment(),ScriptValueType.STYLESHEET));
		addConstructor(getType(),fxnParams);
		setFullCreation(false);
	}
	// Function bodies are contained via a series of if statements in execute
	// Template will be null if the object is exactly of this type and is constructing, and thus must be created then
	public ScriptValue_Abstract execute(Referenced ref,String name,List<ScriptValue_Abstract>params,ScriptTemplate_Abstract rawTemplate)throws Exception_Nodeable{
		assert Debugger.openNode("Faux-Template Executions","Executing Rectangle Faux-Template Function ("+ScriptFunction.getDisplayableFunctionName(name)+")");
		FauxTemplate_Rectangle template=(FauxTemplate_Rectangle)rawTemplate;
		ScriptValue_Abstract returning;
		assert Debugger.addSnapNode("Template provided",template);
		assert Debugger.addSnapNode("Parameters provided",params);
		ScriptValue_Abstract value;
		if(name==null||name.equals("")){
			if(template==null){template=new FauxTemplate_Rectangle(getEnvironment());}
			((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
			assert Debugger.closeNode();
			return template;
		}
		returning=((FauxTemplate)getExtendedClass()).execute(ref,name,params,template);
		assert Debugger.closeNode();
		return returning;
	}
	// Convertible and Nodeable implementation
	public Object convert(){
		return new InterfaceElement_Rectangle(getEnvironment(),getUniqueStylesheet(),getClassStylesheet());
	}
	public boolean nodificate(){
		assert Debugger.openNode("Rectangle Faux Template");
		assert super.nodificate();
		assert Debugger.closeNode();
		return true;
	}
}
