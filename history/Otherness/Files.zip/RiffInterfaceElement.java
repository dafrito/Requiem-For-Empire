import java.awt.*;
import java.util.*;

public abstract class RiffInterfaceElement{
	private RiffInterfaceStylesheet m_classStylesheet, m_uniqueStylesheet;
	private int m_xAnchor, m_yAnchor;
	private java.util.List m_elements=new LinkedList();
	private RiffInterfaceElement m_parent;
	public RiffInterfaceElement(RiffInterfaceElement parent){m_parent=parent;}
	public RiffInterfaceElement(RiffInterfaceElement parent, RiffInterfaceStylesheet classStylesheet){this(parent,null,classStylesheet);}
	public RiffInterfaceElement(RiffInterfaceElement parent, String classStyle){this(parent,null,RiffScriptParser.getStylesheet(classStyle));}
	public RiffInterfaceElement(RiffInterfaceElement parent, String uniqueStyle, String classStyle){
		this(parent,RiffScriptParser.getStylesheet(uniqueStyle),RiffScriptParser.getStylesheet(classStyle));
	}
	public RiffInterfaceElement(RiffInterfaceElement parent, RiffInterfaceStylesheet uniqueStylesheet, RiffInterfaceStylesheet classStylesheet){
		m_parent=parent;
		m_uniqueStylesheet=uniqueStylesheet;
		m_classStylesheet=classStylesheet;
	}
	public abstract Rectangle getDrawingBounds();
	public abstract Rectangle getDrawingBoundsUsingWidth(int width);
	public void addElement(RiffInterfaceElement element){
		m_elements.add(element);
	}
	public Font getCurrentFont(){
		return new Font(((RiffInterfaceStylesheetFontElement)getStyleElement(StylesheetElements.FONTNAME)).getFontName(),((RiffInterfaceStylesheetFontStyleElement)getStyleElement(StylesheetElements.FONTSTYLE)).getStyle(), ((RiffInterfaceStylesheetFontSizeElement)getStyleElement(StylesheetElements.FONTSIZE)).getFontSize());
	}
	public Iterator getElementsIterator(){return m_elements.iterator();}
	public RiffInterfaceStylesheet getUniqueStylesheet(){return m_uniqueStylesheet;}
	public RiffInterfaceStylesheet getClassStylesheet(){return m_classStylesheet;}
	public void setUniqueStylesheet(RiffInterfaceStylesheet sheet){m_uniqueStylesheet=sheet;}
	public void setClassStylesheet(RiffInterfaceStylesheet sheet){m_classStylesheet=sheet;}
	public RiffInterfaceStylesheetElement getStyleElement(short code){
		RiffInterfaceStylesheetElement element=null;
		if(getUniqueStylesheet()!=null){
			element=getUniqueStylesheet().getElement(code);
			if(element!=null){return element;}
		}
		if(getClassStylesheet()!=null){
			element=getClassStylesheet().getElement(code);
			if(element!=null){return element;}
		}
		return getParent().getStyleElement(code);
	}
	public void setXAnchor(int xAnchor){m_xAnchor=xAnchor;}
	public void setYAnchor(int yAnchor){m_yAnchor=yAnchor;}
	public int getXAnchor(){return m_xAnchor;}
	public int getYAnchor(){return m_yAnchor;}
	public RiffInterfaceRootElement getRoot(){return m_parent.getRoot();}
	public RiffInterfaceElement getParent(){return m_parent;}
	public abstract void paint(Graphics2D g2d);
}
