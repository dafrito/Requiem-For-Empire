public class RiffScriptItem{
	private final String m_originalString;
	private final String m_filename;
	private final int m_lineNumber;
	private final int m_originalLineOffset;
	public RiffScriptItem(String filename, int lineNumber, String original){
		m_filename=filename;
		m_lineNumber=lineNumber;
		m_originalString=original;
		m_originalLineOffset=0;
	}
	public RiffScriptItem(RiffScriptLine line, int oLO){
		m_originalString=line.getOriginalString();
		m_filename=line.getFilename();
		m_lineNumber=line.getLineNumber();
		m_originalLineOffset=line.getOffset()+oLO;
	}
	public String getFilename(){return m_filename;}
	public String getOriginalString(){return m_originalString;}
	public int getLineNumber(){return m_lineNumber;}
	public int getOffset(){return m_originalLineOffset;}
	
}
