public class RiffParserException extends Exception{
	private String m_filename;
	private int m_lineNumber;
	public RiffParserException(String filename, int num){
		m_filename=filename;
		m_lineNumber=num;
	}
	public String toString(){
		return m_filename + ": " + m_lineNumber + ": " + getMessage();
	}
}
