import java.util.*;
public class RiffTester{
	public static void getIntersectionDiagnostic(){
		System.out.println("Testing getIntersection: getIntersection(RiffAbsolutePOint, RiffAbsolutePoint, RiffAbsolutePoint, RiffAbsolutePoint)");
		RiffAbsolutePoint pointA,pointB,pointC,pointD;
		IntersectionPoint intersectionPoint;
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==2.5d&&intersectionPoint.getPoint().getY()==2.5d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(intersectionPoint!=null){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		pointD = new RiffEuclideanPoint(4.0d, 4.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(intersectionPoint!=null){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointD = new RiffEuclideanPoint(10.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==5.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(2.5d, 2.5d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==2.5d&&intersectionPoint.getPoint().getY()==2.5d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointD = new RiffEuclideanPoint(0.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointD = new RiffEuclideanPoint(5.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointD = new RiffEuclideanPoint(5.0d, 10.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==5.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(-2.0d, 2.0d, 0.0d);
		pointD = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 2.0d, 0.0d);
		pointD = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==0.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		pointC = new RiffEuclideanPoint(2.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(2.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==0.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		pointC = new RiffEuclideanPoint(2.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(2.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointC, pointD, pointA, pointB);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==true&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==0.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 2.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 2.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointA, pointB, pointC, pointD);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
		pointA = new RiffEuclideanPoint(0.0d, 2.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 2.0d, 0.0d);
		pointC = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		intersectionPoint = RiffPolygonToolbox.getIntersection(pointC, pointD, pointA, pointB);
		if(!(intersectionPoint!=null&&intersectionPoint.isTangent()==false&&intersectionPoint.getPoint().getX()==2.0d&&intersectionPoint.getPoint().getY()==2.0d)){
			System.out.println("Testing this line " + pointA + ", " + pointB + " against this line " + pointC + ", " + pointD);
			System.out.println("Failed.");
			System.out.println("IntersectPoint: " + intersectionPoint);
		}
	}
	public static void testPointAgainstLineDiagnostic(){
		System.out.println("Testing one-line point-side test: testPointAgainstLine(RiffAbsolutePoint, RiffAbsolutePoint, RiffAbsolutePoint)");
		RiffAbsolutePoint pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointB = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointC = new RiffEuclideanPoint(2.0d, 1.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, 0.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d,-1.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = new RiffEuclideanPoint(2.0d, 5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, -5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointA = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointC = new RiffEuclideanPoint(2.0d, 5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, -5.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointA = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointC = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isLessThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(-2.0d, -2.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.isGreaterThan(value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
		pointC = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		while(true){
			double value=RiffPolygonToolbox.testPointAgainstLine(pointC,pointA,pointB);
			if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,value, 0.0d)){break;}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ")...");
			System.out.println("failed.");
			System.out.println("Value: " + value);
			break;
		}
	}
	public static void getPointSideTest_RegionPointDiagnostic(){
		System.out.println("Testing region-point point-side test: getPointSideTest(DiscreteRegion, RiffAbsolutePoint)");
		DiscreteRegion region = new DiscreteRegion();
		region.addPoint(new RiffEuclideanPoint(0.0d, 0.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 0.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 5.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(0.0d, 5.0d, 0.0d));
		RiffAbsolutePoint testPoint = new RiffEuclideanPoint(2.0d, 2.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, testPoint);
			if(!array[0].isEmpty()&&array[1].isEmpty()&&array[2].isEmpty()){
				if(array[0].contains(testPoint)&&array[0].size()==4){break;}
			}
			System.out.println("Testing this point " + testPoint + " against this region: " + region);
			System.out.println("Failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
		testPoint = new RiffEuclideanPoint(2.0d, 5.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, testPoint);
			if(array[0].size()==3&&array[2].size()==1&&array[1].isEmpty()){break;}
			System.out.println("Testing this point " + testPoint + " against this region: " + region);
			System.out.println("Failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
		testPoint = new RiffEuclideanPoint(2.0d, 7.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, testPoint);
			if(array[0].size()==3&&array[2].size()==0&&array[1].size()==1){break;}
			System.out.println("Testing this point " + testPoint + " against this region: " + region);
			System.out.println("Failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
	}
	public static void getPointSideTest_RegionLineDiagnostic(){
		System.out.println("Testing region-line point-side test: getPointSideTest(DiscreteRegion, RiffAbsolutePoint, RiffAbsolutePoint)");
		DiscreteRegion region = new DiscreteRegion();
		region.addPoint(new RiffEuclideanPoint(0.0d, 0.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 0.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 5.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(0.0d, 5.0d, 0.0d));
		RiffAbsolutePoint pointA = new RiffEuclideanPoint(2.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointB = new RiffEuclideanPoint(2.0d, 5.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, pointA, pointB);
			if(array[0].size()==2&&array[1].size()==2&&array[2].size()==0){break;}
			System.out.println("Testing these points (" + pointA + ", " + pointB + ") against this region: " + region);
			System.out.println("Failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, pointA, pointB);
			if(array[0].size()==1&&array[1].size()==1&&array[2].size()==2){break;}
			System.out.println("Testing these points (" + pointA + ", " + pointB + ") against this region: " + region);
			System.out.println("Failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
		pointA = new RiffEuclideanPoint(0.0d, 7.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 7.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(region, pointA, pointB);
			if(array[0].size()==0&&array[1].size()==4&&array[2].size()==0){break;}
			System.out.println("Testing these points (" + pointA + ", " + pointB + ") against this region: " + region);
			System.out.println("Failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
	}
	public static void getPointSideTest_TwoLineDiagnostic(){
		System.out.println("Testing two-line point-side test: getPointSideTest(RiffAbsolutePoint, RiffAbsolutePoint, RiffAbsolutePoint, RiffAbsolutePoint)");
		RiffAbsolutePoint pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointB = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointC = new RiffEuclideanPoint(2.0d, -1.0d, 0.0d);
		RiffAbsolutePoint pointD = new RiffEuclideanPoint(7.0d, -1.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(pointA,pointB,pointC,pointD);
			if(array[0].isEmpty()&&!array[1].isEmpty()&&array[2].isEmpty()){
				if(array[1].contains(pointC)&&array[1].contains(pointD)&&array[1].size()==2){break;}
			}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ", " + pointD + ")...");
			System.out.println("failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, 0.0d, 0.0d);
		pointD = new RiffEuclideanPoint(7.0d, 0.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(pointA,pointB,pointC,pointD);
			if(array[0].isEmpty()&&array[1].isEmpty()&&!array[2].isEmpty()){
				if(array[2].contains(pointC)&&array[2].contains(pointD)&&array[2].size()==2){break;}
			}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ", " + pointD + ")...");
			System.out.println("failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
		pointC = new RiffEuclideanPoint(2.0d, 1.0d, 0.0d);
		pointD = new RiffEuclideanPoint(7.0d, 1.0d, 0.0d);
		while(true){
			List[]array=RiffPolygonToolbox.getPointSideList(pointA,pointB,pointC,pointD);
			if(!array[0].isEmpty()&&array[1].isEmpty()&&array[2].isEmpty()){
				if(array[0].contains(pointC)&&array[0].contains(pointD)&&array[0].size()==2){break;}
			}
			System.out.print("Testing these points (" + pointA + ", " + pointB + ", " + pointC + ", " + pointD + ")...");
			System.out.println("failed.");
			System.out.println("Left-side list: " + array[0]);
			System.out.println("Right-side list: " + array[1]);
			System.out.println("Indeterminate-side list: " + array[2]);
			break;
		}
	}
	public static void getMidPointOfLineDiagnostic(){
		System.out.println("Testing midpoint-creation diagnostic: getMidPointOfLine(RiffAbsolutePoint, RiffAbsolutePoint)");
		RiffAbsolutePoint pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointB = new RiffEuclideanPoint(5.0d, 0.0d, 0.0d);
		RiffAbsolutePoint pointC = RiffPolygonToolbox.getMidPointOfLine(pointA, pointB);
		if(!(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getX(),2.5d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getY(),0.0d))){
			System.out.println("Finding the midpoint of these points: " + pointA + ", " + pointB);
			System.out.println("Failed.");
			System.out.println("Midpoint returned: " + pointC);
		}
		pointA = new RiffEuclideanPoint(0.0d, 5.0d, 0.0d);
		pointB = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointC = RiffPolygonToolbox.getMidPointOfLine(pointA, pointB);
		if(!(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getX(),0.0d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getY(),2.5d))){
			System.out.println("Finding the midpoint of these points: " + pointA + ", " + pointB);
			System.out.println("Failed.");
			System.out.println("Midpoint returned: " + pointC);
		}
		pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		pointB = new RiffEuclideanPoint(5.0d, 5.0d, 0.0d);
		pointC = RiffPolygonToolbox.getMidPointOfLine(pointA, pointB);
		if(!(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getX(),2.5d)&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN,pointC.getY(),2.5d))){
			System.out.println("Finding the midpoint of these points: " + pointA + ", " + pointB);
			System.out.println("Failed.");
			System.out.println("Midpoint returned: " + pointC);
		}
	}
	public static void assertCCWPolygonDiagnostic(){
		System.out.println("Testing region-line point-side test: assertCCWPolygon(DiscreteRegion)");
		DiscreteRegion region = new DiscreteRegion();
		RiffAbsolutePoint pointA = new RiffEuclideanPoint(0.0d, 0.0d, 0.0d);
		region.addPoint(pointA);
		region.addPoint(new RiffEuclideanPoint(0.0d, 0.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 0.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 5.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(0.0d, 5.0d, 0.0d));
		RiffPolygonToolbox.assertCCWPolygon(region);
		List points = region.getPoints();
		if(!points.get(0).equals(pointA)){
			System.out.println("Testing this region for CCW-behavior: " + region);
			System.out.println("Failed.");
		}
		region = new DiscreteRegion();
		region.addPoint(new RiffEuclideanPoint(0.0d, 5.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 5.0d, 0.0d));
		region.addPoint(new RiffEuclideanPoint(5.0d, 0.0d, 0.0d));
		region.addPoint(pointA);
		RiffPolygonToolbox.assertCCWPolygon(region);
		points = region.getPoints();
		if(!points.get(0).equals(pointA)){
			System.out.println("Testing this region for CCW-behavior: " + region);
			System.out.println("Failed.");
		}
	}
	public static void polygonDiagnostic(){
		System.out.println("Diagnostics now running for the module: Polygons");
		testPointAgainstLineDiagnostic();
		getPointSideTest_TwoLineDiagnostic();
		getPointSideTest_RegionPointDiagnostic();
		getPointSideTest_RegionLineDiagnostic();
		getMidPointOfLineDiagnostic();
		assertCCWPolygonDiagnostic();
		getIntersectionDiagnostic();
		//RiffPolygonToolbox.testForColinearity(new RiffEuclideanPoint("A", null, 25.0, 25.0, 0), new RiffEuclideanPoint("B", null, 75.0, 75.0, 0), new RiffEuclideanPoint("C", null, 50.0, 50.0, 0), new RiffEuclideanPoint("D", null, 100.0, 100.0, 0));
	}
	public static void main(String[]args){
		System.out.println(" *** Requiem for Empire Self-Diagnostic ***\n");
		polygonDiagnostic();
	}
}
