import java.util.*;

public class ComplexOrder extends Order{
	private List m_orderList;
	private int m_currentOrder;
	public ComplexOrder(){
		m_orderList=new LinkedList();
	}
	public List getList(){return m_orderList;}
	public void execute(double time) throws OrderException{
		super.execute(time);
		while(getIterationTime()>0){
			Order current=(Order)m_orderList.get(m_currentOrder);
			current.execute(getIterationTime());
			if(current.getStatus()==OrderStatus.COMPLETE){
				m_currentOrder++;
				if(m_currentOrder==m_orderList.size()){
					m_currentOrder=0;
					setStatus(OrderStatus.COMPLETE);
					break;
				}
			}else{
				break;
			}
		}
	}
	public String toString(){
		String string = new String();
		string += "Complex order, list follows: " + RiffToolbox.displayList(m_orderList, "order");
		return string;
	}
}
