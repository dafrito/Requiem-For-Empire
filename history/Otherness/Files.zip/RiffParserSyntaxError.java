public class RiffParserSyntaxError extends RiffParserException{
	private String m_line;
	private int m_position;
	public RiffParserSyntaxError(RiffScriptItem element){
		super(element.getFilename(), element.getLineNumber());
		m_line=element.getOriginalString();
	}
	public String getMessage(){
		String string ="Syntax error\n\t" + m_line;
		string += "\n\t";
		for(int i=0;i<m_position;i++){
			string += " ";
		}
		string += "^";
		return string;
	}
}
