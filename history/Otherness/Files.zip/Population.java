import java.util.*;

public class Population extends ActiveAsset implements Transport, Thinker, LivingBeing{
	private Map m_identities;
	private int m_size;
	private Map m_consumptionLevels;
	private Map m_proficiencies;
	private List m_orders = new LinkedList();
	public Population(ActiveAsset parent, RiffDataPoint position, int size){
		super(parent, position);
		m_size = size;
		m_proficiencies = new HashMap();
		m_identities = new HashMap();
		m_consumptionLevels = new HashMap();
	}
	public Population(Population otherPop){
		this(otherPop.getParent(), otherPop.getPosition(), otherPop.getSize());
		m_proficiencies=new HashMap(otherPop.getProficiencies());
		m_consumptionLevels=new HashMap(otherPop.getConsumptionLevels());
		m_identities=new HashMap(otherPop.getIdentities());
	}
	public Object clone(){return new Population(this);}
	public boolean mergeAsset(Asset asset){
		if(!asset.getAssetType().equals(Asset.POPULATION)){return false;}
		Population pop = (Population)asset;
		m_size+=pop.getSize();
		// TODO: Finish this merging process.
		return true;
	}
	public void addOrder(Order order){
		m_orders.add(order);
	}
	public Integer getAssetType(){return Asset.POPULATION;}
	public boolean isAssetOfType(Integer type){
		return(type.equals(getAssetType())||type.equals(Asset.TRANSPORT)||type.equals(Asset.THINKER)||type.equals(Asset.LIVINGBEING)||super.isAssetOfType(type));
	}
	public Double getValue(RiffDataPoint source, RiffDataPoint location, RiffDataPoint destination, DiscreteRegion region){
		double sourceToLocation = RiffToolbox.getDistance(source, location);
		double locToDestination = RiffToolbox.getDistance(location, destination);
		assert RiffToolbox.printDebug("Pathfinder/getValue", "SourceToLoc: " + sourceToLocation);
		assert RiffToolbox.printDebug("Pathfinder/getValue", "LocToDest: " + locToDestination);
		if(((Terrain)region.getAssetMap().getAsset(Asset.TERRAIN)).getBrushDensity()>0.0d){
			locToDestination=Double.POSITIVE_INFINITY;
		}
		return new Double(sourceToLocation+locToDestination);
	}
	public void expendFuel(double time){
		
	}
	public void setPosition(RiffDataPoint position){}
	public double getVelocity(double time){
		return 8.0d;
	}
	public boolean isUnique(){return false;}
	public Map getIdentities(){return m_identities;}
	public Map getConsumptionLevels(){return m_consumptionLevels;}
	public Map getProficiencies(){return m_proficiencies;}
	public int getSize(){return m_size;}
	public boolean addIdentity(Identity ident, Integer loyalty){m_identities.put(ident, loyalty);return true;}
	public Integer getLoyalty(Identity identity){return (Integer)m_identities.get(identity);}
	public double getProficiency(String action){
		Double value=(Double)m_proficiencies.get(action);
		if(value==null){return 0.0d;}
		return value.doubleValue();
	}
	public double getProficiency(String action, Commodity comm){
		Map map = (Map)m_proficiencies.get(action);
		if(map==null){return 0.0d;}
		Double value = (Double)map.get(comm);
		if(value==null){return 0.0d;}
		return value.doubleValue();
	}
	public void addProficiency(String action, double proficiency){
		m_proficiencies.put(action, new Double(proficiency));
	}
	public void addProficiency(String action, Commodity comm, double proficiency){
		if(m_proficiencies.get(action)==null){
			m_proficiencies.put(action, new HashMap());
		}
		((Map)m_proficiencies.get(action)).put(comm, new Double(proficiency));
	}
	public Integer getConsumptionLevel(Brand comm){return (Integer)m_consumptionLevels.get(comm);}
	public boolean addConsumptionLevel(Brand comm, Integer level){m_consumptionLevels.put(comm, level);return true;}
	public void iterate(double iterationTime){
		try{
			for(int i=0;i<m_orders.size();i++){
				Order order = (Order)m_orders.get(i);
				order.execute(iterationTime);
				if(order.getIterationTime()==0){return;}
				iterationTime = order.getIterationTime();
				m_orders.remove(i);
				i--;
			}
		}catch(OrderException ex){
			System.out.println(ex);
		}
	}
	public void evaluate(){
		
	}
	public String toString(){
		String string = new String();
		string += "Population of " + m_size + " people\n";
		return string;
	}
}
