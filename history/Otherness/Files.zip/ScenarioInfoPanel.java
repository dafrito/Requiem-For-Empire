import java.awt.event.*;
import javax.swing.*; // For JPanel, etc.
import java.util.*;
import java.awt.*;
import java.awt.geom.Dimension2D;
import java.text.SimpleDateFormat;
import java.text.FieldPosition;

public class ScenarioInfoPanel extends JPanel implements ActionListener{
	private Scenario m_scenario;
	public ScenarioInfoPanel(Scenario scenario){
		m_scenario=scenario;
		JPanel motherPanel = new JPanel();
		motherPanel.setLayout(new BoxLayout(motherPanel, BoxLayout.PAGE_AXIS));
		setLayout(new BorderLayout());
		// Scenario data panel
		java.util.List keys=new LinkedList();
		java.util.List values= new LinkedList();
		keys.add("Scenario name:");
		keys.add("Timescale:");
		keys.add("Current iteration:");
		keys.add("Current date:");
		keys.add("Ending date:");
		values.add(m_scenario.getScenarioName());
		switch(m_scenario.getTimescale()){
			case 0:
			values.add("Unset");
			break;
			case 1:
			values.add("Real-time");
			break;
			case Scenario.MINUTE:
			values.add("1 second: 1 game-minute");
			break;
			case Scenario.HOUR:
			values.add("1 second: 1 game-hour");
			break;
			case Scenario.DAY:
			values.add("1 second: 1 game-day");
			break;
			case Scenario.SEASON:
			values.add("1 day: 1 game-season");
			break;
			default:
			values.add("1 second: " + Integer.toString(m_scenario.getTimescale()) + " seconds");
			break;
		}
		switch(m_scenario.getCurrentIteration()){
			case 0:
			values.add("Has not started.");
			break;
			default:
			values.add(new Integer(m_scenario.getCurrentIteration()));
			break;
		}
		SimpleDateFormat dateString=new SimpleDateFormat("MMMMM d, yyyy GG");
		StringBuffer buffer = new StringBuffer();
		dateString.format(m_scenario.getDate(), buffer, new FieldPosition(0));
		values.add(buffer);
		buffer = new StringBuffer();
		dateString.format(m_scenario.getEndDate(), buffer, new FieldPosition(0));
		values.add(buffer.toString());
		motherPanel.add(RiffJavaToolbox.getKeyValueBox("Scenario Data", keys, values));
		// Organizations panel
		motherPanel.add(RiffJavaToolbox.createInfoBox(scenario.getRootLocation()));
		JPanel organizationsPanel = new JPanel();
		organizationsPanel.setBorder(BorderFactory.createTitledBorder("Organizations"));
		Iterator iterator = scenario.getOrganizations().iterator();
		while(iterator.hasNext()){
			organizationsPanel.add(RiffJavaToolbox.createInfoBox(iterator.next()));
		}
		motherPanel.add(organizationsPanel);
		add(motherPanel, BorderLayout.NORTH);
	}
	public void actionPerformed(ActionEvent e){}
}
