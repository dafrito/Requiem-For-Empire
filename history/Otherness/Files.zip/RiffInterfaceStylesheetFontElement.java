public class RiffInterfaceStylesheetFontElement extends RiffInterfaceStylesheetElement{
	private String m_fontName;
	public RiffInterfaceStylesheetFontElement(String fontName){
		m_fontName=fontName;
	}
	public String getFontName(){return m_fontName;}
}
