import java.util.*;
import java.awt.Color;
public class DiscreteRegion implements Comparable{
	private List m_points;
	private double m_leftExtreme, m_rightExtreme, m_topExtreme, m_bottomExtreme;
	private Map m_intersectionMap=new HashMap();
	private RiffAbsolutePoint m_midPoint, m_interiorPoint;
	private Integer m_version= new Integer(0);
	private boolean m_isOptimized=false;
	private AssetMap m_assetMap;
	private Set m_neighbors;
	private Color m_color;
	private String m_name;
	public DiscreteRegion(){
		assert RiffToolbox.printDebug("DiscreteRegion/constructor", "(DiscreteRegionConstructor/)Creating new, empty DiscreteRegion.");
		m_points = new Vector();
		m_neighbors = new HashSet();
		m_assetMap = new AssetMap();
		resetExtrema();
	}
	public DiscreteRegion(AssetMap assets){
		assert RiffToolbox.printDebug("DiscreteRegion/constructor/assetData", "(DiscreteRegionConstructor/)Creating new DiscreteRegion with a provided asset-list.");
		assert RiffToolbox.printDebug("DiscreteRegion/constructor/assetData", "Provided asset-list: " + assets);
		m_points = new Vector();
		m_neighbors = new HashSet();
		m_assetMap = assets;
	}
	public DiscreteRegion(DiscreteRegion otherRegion){
		assert RiffToolbox.printDebug("DiscreteRegion/constructor", "(DiscreteRegionConstructor/)Creating a new DiscreteRegion with a region provided to duplicate.");
		assert RiffToolbox.printDebug("DiscreteRegion/constructor/data", "Provided DiscreteRegion: " + otherRegion);
		m_neighbors = new HashSet();
		m_points = new Vector(otherRegion.getPoints());
		m_leftExtreme=otherRegion.getLeftExtreme();
		m_rightExtreme=otherRegion.getRightExtreme();
		m_topExtreme=otherRegion.getTopExtreme();
		m_bottomExtreme=otherRegion.getBottomExtreme();
		m_isOptimized=otherRegion.isOptimized();
		m_version=otherRegion.getVersion();
		m_assetMap = otherRegion.getAssetMap();
	}
	public void setName(String name){m_name=name;}
	public void resetNeighbors(){m_neighbors.clear();}
	public Color getColor(){return m_color;}
	public void setColor(Color color){m_color=color;}
	public double getLeftExtreme(){return m_leftExtreme;}
	public double getRightExtreme(){return m_rightExtreme;}
	public double getTopExtreme(){return m_topExtreme;}
	public double getBottomExtreme(){return m_bottomExtreme;}
	public RiffAbsolutePoint getBoundingRectMidPoint(){
		if(m_midPoint==null){
			m_midPoint = RiffPolygonToolbox.createPoint(m_points.get(0), null, getLeftExtreme()+((getRightExtreme()-getLeftExtreme())/2),  getBottomExtreme()+((getTopExtreme()-getBottomExtreme())/2), 0.0d);
		}
		return m_midPoint;
	}
	public RiffAbsolutePoint getInteriorPoint(){
		return getBoundingRectMidPoint();//RiffPolygonToolbox.getMidPointOfLine(RiffPolygonToolbox.getMidPointOfLine(m_points.get(0), m_points.get(1)), RiffPolygonToolbox.getMidPointOfLine(m_points.get(1), m_points.get(2)));
		//return m_interiorPoint;
	}
	public Set getNeighbors(){return new HashSet(m_neighbors);}
	public List getPoints(){return new LinkedList(m_points);}
	public void addPoint(RiffAbsolutePoint point){
		testExtrema(point);
		m_points.add(point);
		assert RiffToolbox.printDebug("DiscreteRegion/addPoint", "(addPoint/)Adding this point: " + point);
		assert RiffToolbox.printDebug("DiscreteRegion/addPoint/data", "New point-list: " + RiffToolbox.displayList(m_points, "point"));
		resetIntersectionMap();
	}
	public void addPointAt(int location, RiffAbsolutePoint point){
		testExtrema(point);
		m_points.add(location, point);
		assert RiffToolbox.printDebug("DiscreteRegion/addPointAt", "(addPointAt/)Adding at this location, " + location + ", this point: " + point);
		assert RiffToolbox.printDebug("DiscreteRegion/addPointAt/data", "New point-list: " + RiffToolbox.displayList(m_points, "point"));
		resetIntersectionMap();
	}
	public void reversePoints(){
		assert RiffToolbox.printDebug("DiscreteRegion/reversePoints", "(reversePoints/)Reversing points.");
		Collections.reverse(m_points);
	}
	public void removePoint(int pointNum){
		RiffAbsolutePoint point = (RiffAbsolutePoint)m_points.get(pointNum);
		removePoint(point);
	}
	public void removePoint(RiffAbsolutePoint point){
		if(!m_points.contains(point)){return;}
		assert RiffToolbox.printDebug("DiscreteRegion/removePoint", "Removing this point: " + point);
		m_points.remove(point);
		if(point.getX()==m_leftExtreme||point.getX()==m_rightExtreme||point.getY()==m_topExtreme||point.getY()==m_bottomExtreme){
			recalculateExtrema();
		}
		assert RiffToolbox.printDebug("DiscreteRegion/removePoint/data", "New point-list: " + RiffToolbox.displayList(m_points, "point"));
		resetIntersectionMap();
	}
	public void setPointList(List pointList){
		assert RiffToolbox.printDebug("DiscreteRegion/setPointList", "(setPointList/)Setting this region's pointList to a provided pointList.");
		assert RiffToolbox.printDebug("DiscreteRegion/setPointList/data", "Old point-list: " + RiffToolbox.displayList(m_points));
		assert RiffToolbox.printDebug("DiscreteRegion/setPointList/data", "New point-list: " + RiffToolbox.displayList(pointList));
		m_points=pointList;
		recalculateExtrema();
		resetIntersectionMap();
	}
	private void testExtrema(RiffAbsolutePoint point){
		if(point.getX()<m_leftExtreme){
			m_leftExtreme=point.getX();
		}
		if(point.getX()>m_rightExtreme){
			m_rightExtreme=point.getX();
		}
		if(point.getY()<m_bottomExtreme){
			m_bottomExtreme=point.getY();
		}
		if(point.getY()>m_topExtreme){
			m_topExtreme=point.getY();
		}
	}
	private void resetExtrema(){
		assert RiffToolbox.printDebug("DiscreteRegion/resetExtrema", "(resetExtrema/)Resetting extrema.");
		m_leftExtreme=java.lang.Double.POSITIVE_INFINITY;
		m_rightExtreme=java.lang.Double.NEGATIVE_INFINITY;
		m_topExtreme=m_rightExtreme;
		m_bottomExtreme=m_leftExtreme;
	}
	private void recalculateExtrema(){
		assert RiffToolbox.printDebug("DiscreteRegion/recalculateExtrema", "(recalculateExtrema/)Recalculating extrema.");
		resetExtrema();
		for(int i=0;i<m_points.size();i++){
			testExtrema((RiffAbsolutePoint)m_points.get(i));
		}
	}
	public AssetMap getAssetMap(){return m_assetMap;}
	public Integer getVersion(){return m_version;}
	public void resetIntersectionMap(){
		assert RiffToolbox.printDebug("DiscreteRegion/resetIntersectionMap", "(resetIntersectionMap/)Resetting intersection map.");
		m_intersectionMap.clear();
		m_interiorPoint=m_midPoint=null;
		m_version=new Integer(m_version.intValue()+1);
		m_isOptimized=false;
		recheckNeighbors();
	}
	public void addRegionToMap(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegion/addRegionToMap", "(addRegionToMap/)\nAdding region to intersection map.");
		assert RiffToolbox.printDebug("DiscreteRegion/addRegionToMap/data", "Region to add: " + region + "\n(/addRegionMap)");
		m_intersectionMap.put(region, region.getVersion());
	}
	public boolean isOptimized(){return m_isOptimized;}
	public void setOptimized(boolean optimized){m_isOptimized=optimized;}
	public boolean checkClearedRegionMap(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegion/checkClearedRegionMap", "(checkClearedRegionMap)\nChecking cleared region map.");
		assert RiffToolbox.printDebug("DiscreteRegion/checkClearedRegionMap/data", "Region to check for: " + region);
		if(m_intersectionMap.get(region)==null){
			assert RiffToolbox.printDebug("DiscreteRegion/checkIntersectionMap", "Cannot find region, returning false.\n(checkIntersectionMap/)");
			return false;
		}
		if(m_intersectionMap.get(region)==region.getVersion()){
			assert RiffToolbox.printDebug("DiscreteRegion/checkClearedRegionMap", "Quick intersection test valid, returning true.\n(checkIntersectionMap/)");
			return true;
		}else{
			assert RiffToolbox.printDebug("DiscreteRegion/checkClearedRegionMap", "Version difference, returning false.\n(checkIntersectionMap/)");
			return false;
		}
	}
	public void addNeighbor(DiscreteRegion region){
		if(region.equals(this)){return;}
		m_neighbors.add(region);
	}
	public void addRegionNeighbor(DiscreteRegion region){
		if(region.equals(this)){return;}
		assert RiffToolbox.printDebug("DiscreteRegion/addRegionNeighbor/data", "Checking this region for neighbor status: " + region);
		List regionPoints = region.getPoints();
		for(int i=0;i<m_points.size();i++){
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)m_points.get(i);
			RiffAbsolutePoint pointB = (RiffAbsolutePoint)m_points.get((i+1)%m_points.size());
			for(int j=0;j<regionPoints.size();j++){
				RiffAbsolutePoint testPoint = (RiffAbsolutePoint)regionPoints.get(j);
				RiffAbsolutePoint otherTestPoint = (RiffAbsolutePoint)regionPoints.get((j+1)%regionPoints.size());
				if(!RiffPolygonToolbox.testForColinearity(pointA, pointB, testPoint, otherTestPoint)){continue;}
				if(!RiffPolygonToolbox.getBoundingRectIntersection(pointA, pointB, testPoint, otherTestPoint)){continue;}
				region.addNeighbor(this);
				m_neighbors.add(region);
			}
		}
	}
	public void removeRegionNeighbor(DiscreteRegion region){
		m_neighbors.remove(region);
	}
	public void recheckNeighbors(){
		Set neighbors=new HashSet(m_neighbors);
		m_neighbors.clear();
		addRegionNeighbors(neighbors);
	}
	public String getName(){return m_name;}
	public void addRegionNeighbors(Set regions){
		assert RiffToolbox.printDebug("DiscreteRegion/addRegionNeighbors", "(addRegionNeighbors)\nChecking these regions for neighbor status.");
		Iterator iter = regions.iterator();
		while(iter.hasNext()){
			addRegionNeighbor((DiscreteRegion)iter.next());
		}
		assert RiffToolbox.printDebug("DiscreteRegion/addRegionNeighbors", "(/addRegionNeighbors)");
	}
	public int getNextNum(){return m_polyNum++;}
	private static int m_polyNum=0;
	public String toString(){
		String string = new String();
		string += "Discrete Region: " + m_name;
		string += "\nPoints list: " + RiffToolbox.displayList(m_points, "point");
		/*string += "\nAssets: " + RiffToolbox.displayList(m_assets, "asset");
		string += "\nLeft Extrema: " + m_leftExtreme;
		string += "\nRight Extrema: " + m_rightExtreme;
		string += "\nTop Extrema: " + m_topExtreme;
		string += "\nBottom Extrema: " + m_bottomExtreme;*/
		string += "\nThis region has " + m_neighbors.size() + " neighbors.";
		return string;
	}
	public boolean equals(Object o){
		DiscreteRegion otherRegion = (DiscreteRegion)o;
		List pointList = otherRegion.getPoints();
		return(m_points.containsAll(pointList) && pointList.containsAll(m_points));
	}
	public int compareTo(Object o){
		return getBoundingRectMidPoint().compareTo(((DiscreteRegion)o).getBoundingRectMidPoint());
	}
	public int hashCode(){
		return m_points.hashCode();
	}
}
