public class RiffScriptLine extends RiffScriptItem{
	private String m_string;
	public RiffScriptLine(String filename, int num, String string){
		super(filename, num,string);
		m_string=string;
	}
	public RiffScriptLine(String string, RiffScriptLine otherLine, int oLO){
		super(otherLine, oLO);
		m_string=string;
	}
	public void setString(String string){m_string=string;}
	public String getString(){return m_string;}
	public String toString(){
		return "RiffScriptLine: \"" + m_string + '"';
	}
}
