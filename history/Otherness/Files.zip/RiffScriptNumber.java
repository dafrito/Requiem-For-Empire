public abstract class RiffScriptNumber extends RiffScriptElement{
	public RiffScriptNumber(RiffScriptLine line, int oLO){
		super(line, oLO);
	}
	public abstract double getDoubleValue();
	public abstract float getFloatValue();
	public abstract long getLongValue();
	public abstract int getIntegerValue();
	public abstract short getShortValue();
}
