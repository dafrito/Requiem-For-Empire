public class UniqueAssetNotMergingException extends CommodityMapException{
	Asset m_asset, m_otherAsset;
	public UniqueAssetNotMergingException(Asset asset, Asset otherAsset){
		m_asset=asset;
		m_otherAsset=otherAsset;
	}
	public String toString(){
		String string = new String("This asset is unique and should merge with this asset, but it does not.");
		string += "\nAsset: " + m_asset;
		string += "\nOther asset: " + m_otherAsset;
		return string;
	}
}
