import java.util.*;

public class TradeLink{
	private Double m_currentRouteDistance;
	private RiffDataPoint m_currentStartingPoint;
	private RiffDataPoint m_currentEndingPoint;
	private List m_route;
	public TradeLink(){
		m_route=new LinkedList();
		m_currentStartingPoint=null;
		m_currentEndingPoint=null;
	}
	public RiffDataPoint getCurrentStartingPoint(){return m_currentStartingPoint;}
	public RiffDataPoint getCurrentEndingPoint(){return m_currentEndingPoint;}
	public void goToNextRoute(){
		m_route.remove(0);
		m_currentStartingPoint=(RiffDataPoint)m_route.get(0);
		m_currentEndingPoint=(RiffDataPoint)m_route.get(1);
		m_currentRouteDistance=null;
		getCurrentRouteDistance();
	}
	public double getCurrentRouteDistance(){
		if(m_currentRouteDistance==null){
			m_currentRouteDistance=new Double(RiffToolbox.getDistance(m_currentStartingPoint,m_currentEndingPoint));
		}
		return m_currentRouteDistance.doubleValue();
	}
	public boolean hasNext(){
		return(m_route.size()>2);
	}
	public List getFullRoute(){return m_route;}
	public String toString(){
		String string = new String();
		string += "TradeLink: ";
		return string;
	}
}
