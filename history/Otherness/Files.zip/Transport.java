public interface Transport{
	public void expendFuel(double time);
	public void setPosition(RiffDataPoint position);
	public double getVelocity(double time);
	public Double getValue(RiffDataPoint source, RiffDataPoint tempDestination, RiffDataPoint destination, DiscreteRegion region);
}
