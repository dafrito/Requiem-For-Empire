import java.awt.*;

public class RiffPlaceholderStylesheet extends RiffInterfaceStylesheet{
	private String m_stylesheetName;
	private RiffInterfaceStylesheet m_stylesheet;
	public RiffPlaceholderStylesheet(String string){
		m_stylesheetName=string;
	}
	public void activateStyle(Graphics2D g2d){
		if(m_stylesheet!=null){m_stylesheet.activateStyle(g2d);return;}
		if(RiffScriptParser.isStylesheetPresent(m_stylesheetName)){
			m_stylesheet=RiffScriptParser.getStylesheet(m_stylesheetName);
			m_stylesheetName=null;
			m_stylesheet.activateStyle(g2d);return;
		}
		assert RiffToolbox.printError("RiffPlaceholderStylesheet/activateStyle", "Style not found: " + m_stylesheetName);
	}
	public void addElement(short elementCode, RiffInterfaceStylesheetElement element){
		if(m_stylesheet!=null){m_stylesheet.addElement(elementCode,element);return;}
		if(RiffScriptParser.isStylesheetPresent(m_stylesheetName)){
			m_stylesheet=RiffScriptParser.getStylesheet(m_stylesheetName);
			m_stylesheetName=null;
			m_stylesheet.addElement(elementCode,element);return;
		}
		assert RiffToolbox.printError("RiffPlaceholderStylesheet/addElement", "Style not found: " + m_stylesheetName);
	}
}
