import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TerrestrialControllerPanel extends JPanel implements ActionListener{
	public static final int DRAWINGMODE=0;
	public static final int VIEWINGMODE=1;
	public static final int HAND=0;
	public static final int ZOOM=1;
	private JButton m_drawingModeButton, m_viewingModeButton, m_zoomButton, m_handButton, m_drawRegionButton;
	private int m_selectedMode;
	private int m_selectedTool;
	public TerrestrialControllerPanel(Terrestrial terrestrial){
		setLayout(new BorderLayout());
		JPanel panel=new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));
		panel.add(m_drawingModeButton=new JButton("Drawing Mode"));
		panel.add(m_viewingModeButton=new JButton("Viewing Mode"));
		panel.add(Box.createHorizontalGlue());
		panel.add(m_zoomButton=new JButton("Zoom"));
		panel.add(m_handButton=new JButton("Hand"));
		panel.add(m_drawRegionButton=new JButton("Draw Region"));
		add(panel, BorderLayout.NORTH);
		m_zoomButton.addActionListener(this);
		m_handButton.addActionListener(this);
		m_drawRegionButton.addActionListener(this);
		m_drawingModeButton.addActionListener(this);
		m_viewingModeButton.addActionListener(this);
		add(new TerrestrialViewerPanel(this, terrestrial));
	}
	public void actionPerformed(ActionEvent e){
		String action=e.getActionCommand();
		if(e.getSource() instanceof JButton){
			if("Hand".equals(action)){m_selectedTool=HAND;
			}else if("Zoom".equals(action)){m_selectedTool=ZOOM;
			}
		}
	}
	public int getSelectedMode(){return m_selectedMode;}
	public int getSelectedTool(){return m_selectedTool;}
}
