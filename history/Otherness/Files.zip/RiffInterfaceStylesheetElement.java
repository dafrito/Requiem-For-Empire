import java.awt.*;
public class RiffInterfaceStylesheetElement{}
