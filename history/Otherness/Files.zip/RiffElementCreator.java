public class RiffElementCreator{
	public final static int NESTEDSCRIPT=0;
	public final static int PARAMGROUP=1;
	public static RiffScriptGroup createElement(int elementNum, Object prereqs){
		switch(elementNum){
			case RiffElementCreator.NESTEDSCRIPT:
			return NestedScript.createElement(prereqs);
			case RiffElementCreator.PARAMGROUP:
			return RiffScriptParamGroup.createElement(prereqs);
		}
		assert false;
		return null;
	}
}
