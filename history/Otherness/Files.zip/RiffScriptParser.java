import java.io.*;
import java.util.*;

// File --> List of naked strings
// List of naked strings --> Comments-removed naked strings
// Comments-removed naked strings --> Curly Bracket Groupings
// Curly Bracket Groupings --> Lists of line of code

public class RiffScriptParser{
	private static Map m_styles=new HashMap(); // String, Style
	private static Map m_functions=new HashMap(); // String, Function
	private static Map m_classes=new HashMap(); // String, Class
	public static void main(String[]args){
		parseFile("interface.RiffScript");
	}
	public static RiffInterfaceStylesheet getStylesheet(String string){
		Object obj=m_styles.get(string);
		if(obj==null){return new RiffPlaceholderStylesheet(string);}
		return (RiffInterfaceStylesheet)obj;
	}
	public static boolean isStylesheetPresent(String string){
		Object obj=m_styles.get(string);
		return(obj!=null);
	}
	public static List parseFile(String fileName){
		try{
			return parseFile(new FileReader(fileName), fileName);
		}catch(IOException ex){
			RiffToolbox.printError("RiffScriptParser/parseFile", ex);
			return null;
		}
	}
	public static List parseFile(FileReader reader, String filename){
		assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "(parseFile)");
		String string = RiffToolbox.getLineFromStream(reader);
		List stringList = new LinkedList();
		int lineNum=1;
		while(string != null){
			stringList.add(new RiffScriptLine(filename, lineNum, string));
			string = RiffToolbox.getLineFromStream(reader);
			lineNum++;
		}try{
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now creating quoted elements...");
			stringList=createQuotedElements(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now removing comments...");
			stringList=removeComments(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now creating curly-bracket groupings...");
			stringList=createGroupings(stringList,"{","}", RiffElementCreator.NESTEDSCRIPT, false);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now splitting by semicolons...");
			stringList=splitLineBySemicolons(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now creating parenthesis groupings...");
			stringList=createGroupings(stringList,"(",")", RiffElementCreator.PARAMGROUP, true);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now parsing operators...");
			stringList=parseOperators(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now removing empty script lines...");
			stringList=removeEmptyScriptLines(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now separating by whitespace.");
			stringList=splitByWhitespace(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now pulling out keywords...");
			stringList=extractKeywords(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now extracting numbers...");
			stringList=extractNumbers(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile/data", "Final list:\n" + printParseList(stringList,0));
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Now sending to specialized parsers...");
			parseList(stringList);
			assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "Complete.");
			
		}catch(RiffParserException ex){RiffToolbox.printError("RiffScriptParser/parseFile", ex);}
		assert RiffToolbox.printDebug("RiffScriptParser/parseFile", "(/parseFile)");
		return stringList;
	}
	public static void parseList(List lineList) throws RiffParserException{
		List modifiers=new LinkedList();
		for(int i=0;i<lineList.size();i++){
			if(lineList.get(i) instanceof RiffScriptKeyword){
				if(((RiffScriptKeyword)lineList.get(i)).getKeywordCode()==RiffScriptKeyword.STYLE){
					assert lineList.get(i+2) instanceof RiffScriptGroup;
					parseStylesheet(modifiers, (RiffScriptLine)lineList.get(i+1), (RiffScriptGroup)lineList.get(i+2));
					modifiers.clear();continue;
				}
				if(((RiffScriptKeyword)lineList.get(i)).getKeywordCode()==RiffScriptKeyword.FUNCTION){
					assert lineList.get(i+2) instanceof RiffScriptGroup;
					parseFunction(modifiers, (RiffScriptLine)lineList.get(i+1), (RiffScriptGroup)lineList.get(i+2));
					modifiers.clear();continue;
				}
				modifiers.add(lineList.get(i));
			}
		}
		if(modifiers.size()!=0){
			if(lineList.get(lineList.size()-1)instanceof RiffScriptItem){
				throw new RiffParserSyntaxError((RiffScriptItem)lineList.get(lineList.size()-1));
			}
		}
	}
	public static void parseStylesheet(List modifiers, RiffScriptLine name, RiffScriptGroup group){
		assert RiffToolbox.printDebug("RiffScriptParser/parseStylesheet", "(parseStylesheet)");
		assert RiffToolbox.printDebug("RiffScriptParser/parseStylesheet", "Name: " + name);
		assert RiffToolbox.printDebug("RiffScriptParser/parseStylesheet", "Modifiers: " + RiffToolbox.displayList(modifiers));
		assert RiffToolbox.printDebug("RiffScriptParser/parseStylesheet", "(/parseStylesheet)");
	}
	public static void parseFunction(List modifiers, RiffScriptLine name, RiffScriptGroup group){
		assert RiffToolbox.printDebug("RiffScriptParser/parseFunction", "(parseFunction)");
		assert RiffToolbox.printDebug("RiffScriptParser/parseFunction", "Name: " + name);
		assert RiffToolbox.printDebug("RiffScriptParser/parseFunction", "Modifiers: " + RiffToolbox.displayList(modifiers));
		assert RiffToolbox.printDebug("RiffScriptParser/parseFunction", "(/parseFunction)");
	}
	public static String printParseList(List list, int offset){
		String string=new String();
		for(int i=0;i<list.size();i++){
			Object obj=list.get(i);
			if(obj instanceof RiffScriptGroup){string+=RiffToolbox.tab(offset)+((RiffScriptGroup)obj).getName()+"\n"+printParseList(((RiffScriptGroup)obj).getElements(),offset+1);continue;}
			string += RiffToolbox.tab(offset) + obj+"\n";
		}
		return string;
	}
	public static List extractNumbers(List lineList){
		for(int i=0;i<lineList.size();i++){
			if(lineList.get(i) instanceof RiffScriptElement){continue;}
			if(lineList.get(i) instanceof RiffScriptGroup){
				((RiffScriptGroup)lineList.get(i)).setElements(extractNumbers(((RiffScriptGroup)lineList.get(i)).getElements()));
				continue;
			}
			assert lineList.get(i) instanceof RiffScriptLine;
			if(((RiffScriptLine)lineList.get(i)).getString().matches("^[0-9]*px$")){
				String numString=((RiffScriptLine)lineList.get(i)).getString().substring(0,((RiffScriptLine)lineList.get(i)).getString().length()-2);
				RiffScriptShort scriptShort=new RiffScriptShort(Short.parseShort(numString), ((RiffScriptLine)lineList.get(i)), 0);
				lineList.remove(i);lineList.add(i,scriptShort);continue;
			}
			if(((RiffScriptLine)lineList.get(i)).getString().matches("^[0-9]*$")&&i<lineList.size()-1&&lineList.get(i+1) instanceof RiffScriptOperator&&((RiffScriptOperator)lineList.get(i+1)).getOperator()==RiffScriptOperator.MODULUS){
				String numString=((RiffScriptLine)lineList.get(i)).getString();
				RiffScriptFloat scriptFloat=new RiffScriptFloat(Float.parseFloat(numString)/100, ((RiffScriptLine)lineList.get(i)), 0);
				lineList.remove(i);lineList.add(i,scriptFloat);continue;
			}
			if(((RiffScriptLine)lineList.get(i)).getString().matches("^[0-9]+[fd]{0,1}$")){
				if(i>0&&lineList.get(i-1) instanceof RiffScriptOperator&&((RiffScriptOperator)lineList.get(i-1)).getOperator()==RiffScriptOperator.PERIOD){
					String numString="."+((RiffScriptLine)lineList.get(i)).getString();
					if(numString.matches("^[.]{0,1}[0-9]*em$")){
						numString=numString.substring(0,numString.length()-2);
						RiffScriptFloat scriptFloat=new RiffScriptFloat(Float.parseFloat(numString) * 14, ((RiffScriptLine)lineList.get(i)), 0);
						lineList.remove(i-1);lineList.remove(i-1);
						lineList.add(i-1,scriptFloat);i--;i--;continue;
					}
					if(numString.charAt(numString.length()-1)=='f'){
						RiffScriptFloat scriptFloat=new RiffScriptFloat(Float.parseFloat(numString), ((RiffScriptLine)lineList.get(i)), 0);
						lineList.remove(i-1);lineList.remove(i-1);
						lineList.add(i-1,scriptFloat);i--;i--;continue;
					}
					RiffScriptDouble scriptDouble=new RiffScriptDouble(Double.parseDouble(numString), ((RiffScriptLine)lineList.get(i)), 0);
					lineList.remove(i-1);lineList.remove(i-1);
					lineList.add(i-1,scriptDouble);i--;i--;continue;
				}
				if(i<lineList.size()-1&&lineList.get(i+1) instanceof RiffScriptOperator&&((RiffScriptOperator)lineList.get(i+1)).getOperator()==RiffScriptOperator.PERIOD){
					String numString=((RiffScriptLine)lineList.get(i)).getString() + "." + ((RiffScriptLine)lineList.get(i+2)).getString();
					if(numString.matches("^[0-9]*[.]{0,1}[0-9]*em$")){
						numString=numString.substring(0,numString.length()-2);
						RiffScriptFloat scriptFloat=new RiffScriptFloat(Float.parseFloat(numString) * 14, ((RiffScriptLine)lineList.get(i)), 0);
						lineList.remove(i);lineList.remove(i);lineList.remove(i);
						lineList.add(i,scriptFloat);continue;
					}
					if(numString.charAt(numString.length()-1)=='f'){
						RiffScriptFloat scriptFloat=new RiffScriptFloat(Float.parseFloat(numString), ((RiffScriptLine)lineList.get(i)), 0);
						lineList.remove(i);lineList.remove(i);lineList.remove(i);
						lineList.add(i,scriptFloat);continue;
					}
					RiffScriptDouble scriptDouble=new RiffScriptDouble(Double.parseDouble(numString), ((RiffScriptLine)lineList.get(i)), 0);
					lineList.remove(i);lineList.remove(i);lineList.remove(i);
					lineList.add(i,scriptDouble);continue;
				}
				RiffScriptLong scriptLong=new RiffScriptLong(Long.parseLong(((RiffScriptLine)lineList.get(i)).getString()), ((RiffScriptLine)lineList.get(i)),0);
				lineList.remove(i);lineList.add(i,scriptLong);
			}
		}
		return lineList;
	}
	public static List extractKeywords(List lineList){
		for(int i=0;i<lineList.size();i++){
			if(lineList.get(i) instanceof RiffScriptElement){continue;}
			if(lineList.get(i) instanceof RiffScriptGroup){
				((RiffScriptGroup)lineList.get(i)).setElements(extractKeywords(((RiffScriptGroup)lineList.get(i)).getElements()));
				continue;
			}
			assert lineList.get(i) instanceof RiffScriptLine;
			short code=RiffScriptKeyword.getKeywordCode(((RiffScriptLine)lineList.get(i)).getString());
			if(RiffScriptKeyword.UNKNOWN!=code){
				lineList.add(i, new RiffScriptKeyword(code, (RiffScriptLine)lineList.get(i), 0));
				lineList.remove(i+1);
			}
		}
		return lineList;
	}
	public static List createQuotedElements(List lineList) throws RiffParserException{
		for(int i=0;i<lineList.size();i++){
			if(!(lineList.get(i) instanceof RiffScriptLine)){continue;}
			List returnedList=createQuotedElements((RiffScriptLine)lineList.get(i));
			lineList.remove(i);
			lineList.addAll(i,returnedList);			
		}
		return lineList;
	}
	public static List createQuotedElements(RiffScriptLine line) throws RiffParserException{
		int charElem=line.getString().indexOf("'");
		int stringElem=line.getString().indexOf('"');
		List list=new LinkedList();
		if(charElem==-1&&stringElem==-1){list.add(line);return list;
		}else if((charElem==-1||stringElem<charElem)&&stringElem!=-1){
			assert stringElem!=-1;
			int offset=stringElem+1;
			int nextStringElem;
			do{
				nextStringElem=line.getString().indexOf('"',offset);
				if(nextStringElem==-1){throw new RiffParserUnenclosedStringLiteralException(line, stringElem);}
				if(nextStringElem!=0&&'\\'==line.getString().charAt(nextStringElem-1)){offset=nextStringElem+1;nextStringElem=-1;}
			}while(nextStringElem==-1);
			list.add(new RiffScriptLine(line.getString().substring(0,stringElem), line,0));
			list.add(new RiffStringElement(line.getString().substring(stringElem+"\"".length(), nextStringElem), line,stringElem+"\"".length()));
			list.add(new RiffScriptLine(line.getString().substring(nextStringElem+"\"".length()),line,nextStringElem+"\"".length()));
			return createQuotedElements(list);
		}else{
			assert charElem!=-1;
			int nextCharElem=line.getString().indexOf("'", charElem+1);
			if(nextCharElem==-1){throw new RiffParserUnenclosedStringLiteralException(line, charElem);}
			list.add(new RiffScriptLine(line.getString().substring(0,charElem), line,0));
			list.add(new RiffStringElement(line.getString().substring(charElem+"'".length(), nextCharElem), line,charElem+"'".length()));
			list.add(new RiffScriptLine(line.getString().substring(nextCharElem+"'".length()), line,nextCharElem+"'".length()));
			return createQuotedElements(list);
		}
	}
	public static List removeSingleLineGroupings(List lineList, String openChar, String closingChar, int creator, boolean recurse){
		for(int i=0;i<lineList.size();i++){
			if(lineList.get(i) instanceof RiffScriptElement){continue;}
			if(lineList.get(i) instanceof RiffScriptGroup){
				if(recurse){((RiffScriptGroup)lineList.get(i)).setElements(removeSingleLineGroupings(((RiffScriptGroup)lineList.get(i)).getElements(),openChar,closingChar,creator,recurse));}
				continue;
			}
			assert lineList.get(i) instanceof RiffScriptLine;
			List returnedList=removeSingleLineGroupings((RiffScriptLine)lineList.get(i),openChar,closingChar,creator, recurse);
			lineList.remove(i);
			lineList.addAll(i,returnedList);
		}
		return lineList;
	}
	public static List removeSingleLineGroupings(RiffScriptLine line, String openChar, String closingChar, int creator, boolean recurse){
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "(removeSingleLineGroupings)");
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Now creating groups with this openChar: '" + openChar + "' and this closing char: '" + closingChar + "'");
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings/data", "Testing this group: " + line);
		int endGroup=-1;
		int beginGroup=-1;
		int offset=0;
		String string;
		while(true){
			endGroup=line.getString().indexOf(closingChar, offset);
			if(endGroup==-1){
				assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Cannot find endGroup, returning.");
				List list=new LinkedList();list.add(line);
				assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "(/removeSingleLineGroupings)");
				return list;
			}
			string=line.getString().substring(0,endGroup);
			beginGroup=string.lastIndexOf(openChar);
			if(beginGroup!=-1){break;}
			offset = endGroup+1;
		}
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Found single-line group, removing and recursing.");
		List list=new LinkedList();
		List itemList=new LinkedList();
		RiffScriptLine newGroup=new RiffScriptLine(string.substring(beginGroup+openChar.length()), line,beginGroup+openChar.length());
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings/data", "Group found: "+newGroup);
		list.addAll(removeSingleLineGroupings(new RiffScriptLine(line.getString().substring(0,beginGroup), line,0), openChar, closingChar, creator, recurse));
		itemList.add(newGroup);
		list.add(RiffElementCreator.createElement(creator, splitLineBySemicolons(itemList)));
		list.addAll(removeSingleLineGroupings(new RiffScriptLine(line.getString().substring(endGroup+closingChar.length()), line,endGroup+closingChar.length()), openChar, closingChar, creator, recurse));
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "(/removeSingleLineGroupings)");
		return list;
	}
	public static List createGroupings(List stringList, String openChar, String closingChar, int creator, boolean recurse) throws RiffParserException{
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "(createGroupings)");
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Now creating groups with this openChar: '" + openChar + "' and this closing char: '" + closingChar + "'");
		stringList=removeSingleLineGroupings(stringList,openChar,closingChar,creator, recurse);
		for(int i=0;i<stringList.size();i++){
			Object obj=stringList.get(i);
			if(obj instanceof RiffScriptGroup){
				if(recurse){((RiffScriptGroup)obj).setElements(createGroupings(((RiffScriptGroup)obj).getElements(),openChar,closingChar,creator,recurse));}
				continue;
			}
			if(obj instanceof RiffScriptElement){continue;}
			assert obj instanceof RiffScriptLine;
			RiffScriptLine scriptLine=(RiffScriptLine)obj;
			assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Current string: " + scriptLine);
			int j=scriptLine.getString().indexOf(closingChar);
			if(j==-1){
				assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "No closing character found, continuing...");
				continue;
			}
			assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Found closing character, now searching backwards for opening character.");
			List newList = new LinkedList();
			newList.add(new RiffScriptLine(scriptLine.getString().substring(0,j), scriptLine,0));
			scriptLine.setString(scriptLine.getString().substring(j+closingChar.length()));
			for(int q=i-1;q>=0;q--){
				if(!(stringList.get(q) instanceof RiffScriptLine)){newList.add(stringList.get(q));stringList.remove(q);i--;continue;}
				RiffScriptLine backwardScriptLine=(RiffScriptLine)stringList.get(q);
				assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Current string: " + backwardScriptLine);
				int x=backwardScriptLine.getString().lastIndexOf(openChar);
				if(x==-1){
					if(q==0){throw new RiffScriptUnenclosedBracketException(scriptLine, j);}
					assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "No opening character found, continuing...");
					newList.add(backwardScriptLine);stringList.remove(q);i--;
					continue;
				}
				assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "Found opening character, closing newList.");
				newList.add(new RiffScriptLine(backwardScriptLine.getString().substring(x+openChar.length()), backwardScriptLine,x+openChar.length()));
				backwardScriptLine.setString(backwardScriptLine.getString().substring(0, x));
				Collections.reverse(newList);
				stringList.add(i, RiffElementCreator.createElement(creator, createGroupings(newList, openChar, closingChar, creator, recurse)));
				assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "(/createGroupings)");
				return createGroupings(stringList, openChar, closingChar, creator, recurse);
			}
		}
		assert RiffToolbox.printDebug("RiffScriptParser/createGroupings", "(/createGroupings)");
		return stringList;
	}
	public static List parseOperators(RiffScriptLine line){
		assert RiffToolbox.printDebug("RiffScriptParser/parseOperators", "(parseOperators)");
		List list=parseOperator(line, ",");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, ".");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, ":");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "#");
		if(list!=null){return parseOperators(list);}
		// Comparision operations
		list=parseOperator(line, "==");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, ">=");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "<=");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, ">");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "<");
		if(list!=null){return parseOperators(list);}
		// Boolean operations
		list=parseOperator(line, "!");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "&&");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "||");
		if(list!=null){return parseOperators(list);}
		// Single-line equation operations
		list=parseOperator(line, "++");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "--");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "+=");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "-=");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "*=");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "/=");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "%=");
		if(list!=null){return parseOperators(list);}
		// Assignment operation
		list=parseOperator(line, "=");
		if(list!=null){return parseOperators(list);}
		// Mathematical operations.
		list=parseOperator(line, "-");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "+");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "*");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "/");
		if(list!=null){return parseOperators(list);}
		list=parseOperator(line, "%");
		if(list!=null){return parseOperators(list);}
		list=new LinkedList();
		list.add(line);
		return list;
	}
	public static List splitByWhitespace(RiffScriptLine line){
		line.setString(line.getString().trim());
		String[] array=line.getString().split("[ ]+");
		List list=new LinkedList();
		int offset=0;
		for(int i=0;i<array.length;i++){
			System.out.println( "'"+array[i] + "'");
			list.add(new RiffScriptLine(array[i], line, offset));
			offset += array[i].length();
		}
		return list;
	}
	public static List splitByWhitespace(List list){
		for(int i=0;i<list.size();i++){
			Object obj=list.get(i);
			if(obj instanceof RiffScriptGroup){((RiffScriptGroup)obj).setElements(splitByWhitespace(((RiffScriptGroup)obj).getElements()));continue;}
			if(obj instanceof RiffScriptElement){continue;}
			assert obj instanceof RiffScriptLine:obj;
			list.remove(i);
			list.addAll(i, splitByWhitespace((RiffScriptLine)obj));
		}
		return list;
	}
	public static List parseOperator(RiffScriptLine line, String operator){
		int location=line.getString().indexOf(operator);
		if(location!=-1){
			assert RiffToolbox.printDebug("RiffScriptParser/parseOperators", "Found " + RiffScriptOperator.getOperatorName(operator) + " operator, now splitting.");
			List list=new LinkedList();
			list.add(line);
			list.add(new RiffScriptOperator(RiffScriptOperator.getNumericCode(operator), line, location));
			list.add(new RiffScriptLine(line.getString().substring(location+operator.length()),line, location+operator.length()));
			line.setString(line.getString().substring(0,location));
			assert RiffToolbox.printDebug("RiffScriptParser/parseOperators", RiffToolbox.displayList(list));
			return list;
		}
		return null;
	}
	public static List parseOperators(List list){
		for(int i=0;i<list.size();i++){
			Object obj=list.get(i);
			if(obj instanceof RiffScriptGroup){((RiffScriptGroup)obj).setElements(parseOperators(((RiffScriptGroup)obj).getElements()));continue;}
			if(obj instanceof RiffScriptElement){continue;}
			assert obj instanceof RiffScriptLine:obj;
			list.remove(i);
			list.addAll(i, parseOperators((RiffScriptLine)obj));
		}
		return list;
	}
	
	public static List removeEmptyScriptLines(List list){
		assert RiffToolbox.printDebug("RiffScriptParser/removeEmptyScriptLines", "(removeEmptyScriptLines)");
		for(int i=0;i<list.size();i++){
			Object obj=list.get(i);
			if(obj instanceof RiffScriptGroup){((RiffScriptGroup)obj).setElements(removeEmptyScriptLines(((RiffScriptGroup)obj).getElements()));continue;}
			if(obj instanceof RiffScriptElement){continue;}
			assert obj instanceof RiffScriptLine:obj;
			assert RiffToolbox.printDebug("RiffScriptParser/removeEmptyScriptLines/data", "String: " + obj);
			if(((RiffScriptLine)obj).getString().trim().length()==0){
				assert RiffToolbox.printDebug("RiffScriptParser/removeEmptyScriptLines/data", "Removing empty string.");
				list.remove(i);i--;
			}else{
				assert RiffToolbox.printDebug("RiffScriptParser/removeEmptyScriptLines/data", "String not empty: " + obj);
			}
		}
		assert RiffToolbox.printDebug("RiffScriptParser/removeEmptyScriptLines", "(/removeEmptyScriptLines)");
		return list;
	}
	public static List splitLineBySemicolons(List list){
		for(int i=0;i<list.size();i++){
			Object obj=list.get(i);
			if(obj instanceof RiffScriptGroup){((RiffScriptGroup)obj).setElements(splitLineBySemicolons(((RiffScriptGroup)obj).getElements()));continue;}
			if(obj instanceof RiffScriptElement){continue;}
			assert obj instanceof RiffScriptLine:obj;
			list.remove(i);
			list.addAll(i, splitLineBySemicolons((RiffScriptLine)obj));
		}
		return list;
	}
	public static List splitLineBySemicolons(RiffScriptLine line){
		List list=new LinkedList();
		String[]array=line.getString().split(";");
		int offset=0;
		for(int j=array.length-1;j>=0;j--){
			list.add(new RiffScriptLine(array[j], line,offset));
			offset+=array[j].length();
		}
		Collections.reverse(list);
		return list;
	}
	public static String removeSingleLineParagraphs(String string){
		int beginParagraph=string.indexOf("/*");
		int endParagraph=string.indexOf("*/");
		if(beginParagraph!=-1&&endParagraph!=-1){
			String newString=string.substring(0, beginParagraph)+string.substring(endParagraph+"*/".length());
			return newString;
		}
		return string;
	}
	public static List removeComments(List stringList){
		Iterator iter=stringList.iterator();
		boolean isParagraphCommenting=false;
		List list = new LinkedList();
		while(iter.hasNext()){
			Object obj = iter.next();
			if(obj instanceof RiffScriptElement){
				if(!isParagraphCommenting){list.add(obj);}
				continue;
			}
			assert obj instanceof RiffScriptLine;
			RiffScriptLine scriptLine=(RiffScriptLine)obj;
			if(isParagraphCommenting){
				int endComment=scriptLine.getString().indexOf("*/");
				if(endComment!=-1){
					scriptLine.setString(scriptLine.getString().substring(endComment+"*/".length()));
					isParagraphCommenting=false;
				}else{continue;}
			}
			int oldStringLength=0;
			do{
				oldStringLength=scriptLine.getString().length();
				scriptLine.setString(removeSingleLineParagraphs(scriptLine.getString()));
			}while(oldStringLength!=scriptLine.getString().length());
			int beginParagraph=scriptLine.getString().indexOf("/*");
			int lineComment=scriptLine.getString().indexOf("//");
			if(lineComment!=-1&&beginParagraph!=-1){
				if(lineComment<beginParagraph){
					scriptLine.setString(scriptLine.getString().substring(0, lineComment));
				}else{
					isParagraphCommenting=true;
					int endComment=scriptLine.getString().indexOf("*/");
					if(endComment!=-1){
						scriptLine.setString(scriptLine.getString().substring(0, beginParagraph)+scriptLine.getString().substring(endComment+"*/".length()));
						isParagraphCommenting=false;
					}else{
						scriptLine.setString(scriptLine.getString().substring(0, beginParagraph));
					}
				}
			}else if(lineComment!=-1){
				scriptLine.setString(scriptLine.getString().substring(0,lineComment));
			}else if(beginParagraph!=-1){
				isParagraphCommenting=true;
				int endComment=scriptLine.getString().indexOf("*/");
				if(endComment!=-1){
					scriptLine.setString(scriptLine.getString().substring(0, beginParagraph)+scriptLine.getString().substring(endComment+"*/".length()));
					isParagraphCommenting=false;
				}else{
					scriptLine.setString(scriptLine.getString().substring(0, beginParagraph));
				}
			}
			list.add(scriptLine);
		}
		return list;
	}
}
