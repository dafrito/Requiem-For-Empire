public class RiffInterfaceStylesheetHeightElement extends RiffInterfaceStylesheetElement{
	private int m_height;
	public RiffInterfaceStylesheetHeightElement(int height){
		m_height=height;
	}
	public int getHeight(){return m_height;}
	public void setHeight(int height){m_height=height;}
}
