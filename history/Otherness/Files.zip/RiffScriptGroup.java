import java.util.*;

public abstract class RiffScriptGroup{
	protected List m_elements;
	public RiffScriptGroup(List elements){
		m_elements=elements;
	}
	public List getElements(){return m_elements;}
	public void setElements(List list){m_elements=list;}
	public abstract String getName();
	public String toString(){return "Script Group: " + RiffToolbox.displayList(m_elements);}
}
