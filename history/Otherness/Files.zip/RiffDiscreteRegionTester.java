import java.util.*;

public class RiffDiscreteRegionTester{

	public static void main(String[] args) {
		DiscreteRegion regionA = new DiscreteRegion();
		regionA.addPoint(new RiffEuclideanPoint("E", 50,50,0));
		regionA.addPoint(new RiffEuclideanPoint("F", 250,50,0));
		regionA.addPoint(new RiffEuclideanPoint("G", 250,250,0));
		regionA.addPoint(new RiffEuclideanPoint("H", 50,250,0));
		DiscreteRegionBSPNode root = new DiscreteRegionBSPNode(regionA);
		DiscreteRegion regionB = new DiscreteRegion();
		regionB.addPoint(new RiffEuclideanPoint("A", 50,50,0));
		regionB.addPoint(new RiffEuclideanPoint("B", 250,50,0));
		regionB.addPoint(new RiffEuclideanPoint("C", 250,250,0));
		root=RiffPolygonToolbox.removeOverlappingPolygons(root, regionB, true);
		System.out.println("After removal: " + root.getPolyList());
	}
}
