public class RiffScriptFloat extends RiffScriptNumber{
	private float m_value;
	public RiffScriptFloat(float value, RiffScriptLine line, int oLO){
		super(line,oLO);
		m_value=value;
	}
	public float getValue(){return m_value;}
	public double getDoubleValue(){return (double)getValue();}
	public float getFloatValue(){return getValue();}
	public long getLongValue(){return (long)getValue();}
	public int getIntegerValue(){return (int)getValue();}
	public short getShortValue(){return (short)getValue();}
	public String toString(){return "RiffScriptFloat: " + m_value;}
}
