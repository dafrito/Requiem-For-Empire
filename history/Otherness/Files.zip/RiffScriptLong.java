public class RiffScriptLong extends RiffScriptNumber{
	private long m_value;
	public RiffScriptLong(long value, RiffScriptLine line, int oLO){
		super(line,oLO);
		m_value=value;
	}
	public long getValue(){return m_value;}
	public double getDoubleValue(){return (double)getValue();}
	public float getFloatValue(){return (float)getValue();}
	public long getLongValue(){return getValue();}
	public int getIntegerValue(){return (int)getValue();}
	public short getShortValue(){return (short)getValue();}
	public String toString(){return "RiffScriptLong: " + m_value;}
}
