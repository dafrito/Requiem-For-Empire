public class Terrain extends Asset{
	private double m_brushDensity, m_waterDepth, m_temperature, m_groundCohesion, m_elevation;
	private double m_brushDensityWeight, m_elevationWeight, m_groundCohesionWeight, m_temperatureWeight, m_waterDepthWeight;
	public Terrain(double brushDensity, double bdWeight, double elevation, double eWeight, double temperature, double tempWeight, double cohesion, double cWeight, double waterDepth, double wdWeight){
		m_brushDensity=brushDensity;
		m_elevation=elevation;
		m_temperature=temperature;
		m_waterDepth=waterDepth;
		m_groundCohesion=cohesion;
		m_brushDensityWeight=bdWeight;
		m_waterDepth=wdWeight;
		m_temperature=tempWeight;
		m_groundCohesion=cWeight;
		m_elevation=eWeight;
	}
	public Terrain(Terrain otherTerrain){
		m_brushDensity=otherTerrain.getBrushDensity();
		m_brushDensityWeight=otherTerrain.getBrushDensityWeight();
		m_elevation=otherTerrain.getElevation();
		m_elevationWeight=otherTerrain.getElevationWeight();
		m_temperature=otherTerrain.getTemperature();
		m_temperatureWeight=otherTerrain.getTemperatureWeight();
		m_waterDepth=otherTerrain.getWaterDepth();
		m_waterDepthWeight=otherTerrain.getWaterDepthWeight();
		m_groundCohesion=otherTerrain.getGroundCohesion();
		m_groundCohesionWeight=otherTerrain.getGroundCohesionWeight();
	}
	public Integer getAssetType(){return Asset.TERRAIN;}
	public boolean isAssetOfType(Integer type){
		return(type.equals(getAssetType())||super.isAssetOfType(type));
	}
	public Object clone(){return new Terrain(this);}
	public boolean isTangible(){return false;}
	public boolean isUnique(){return true;}
	public boolean mergeAsset(Asset asset){
		if(!asset.getAssetType().equals(getAssetType())){return false;}
		Terrain terrain = (Terrain)asset;
		double theSumOfAllWeights = getBrushDensityWeight()+terrain.getBrushDensityWeight();
		m_brushDensity = m_brushDensity*(getBrushDensityWeight()/theSumOfAllWeights) + terrain.getBrushDensity()*(terrain.getBrushDensityWeight()/theSumOfAllWeights);
		theSumOfAllWeights = getElevationWeight()+terrain.getElevationWeight();
		m_elevation = m_elevation*(getElevationWeight()/theSumOfAllWeights) + terrain.getElevation()*(terrain.getElevationWeight()/theSumOfAllWeights);
		theSumOfAllWeights = getGroundCohesionWeight()+terrain.getGroundCohesionWeight();
		m_groundCohesion = m_groundCohesion*(getGroundCohesionWeight()/theSumOfAllWeights) + terrain.getGroundCohesion()*(terrain.getGroundCohesionWeight()/theSumOfAllWeights);
		theSumOfAllWeights = getTemperatureWeight()+terrain.getTemperatureWeight();
		m_temperature = m_temperature*(getTemperatureWeight()/theSumOfAllWeights) + terrain.getTemperature()*(terrain.getTemperatureWeight()/theSumOfAllWeights);
		theSumOfAllWeights = getWaterDepthWeight()+terrain.getWaterDepthWeight();
		m_waterDepth = m_waterDepth*(getWaterDepthWeight()/theSumOfAllWeights) + terrain.getWaterDepth()*(terrain.getWaterDepthWeight()/theSumOfAllWeights);
		return true;
	}
	public void iterate(double iterationTime){}
	public String toString(){
		String string = new String();
		string += "Terrain Asset: ";
		string += "\nElevation: " + m_elevation;
		string += "\nBrush Density: " + m_brushDensity;
		string += "\nTemperature: " + m_temperature;
		string += "\nGround Cohesion: " + m_groundCohesion;
		string += "\nWater Depth: " + m_waterDepth;
		return string;
	}
	public void physicalIterate(double iterationTime){}
	//public Terrain(double brushDensity, double bdWeight, double elevation, double eWeight, double temperature, double tempWeight, double cohesion, double cWeight, double waterDepth, double wdWeight){
	public Terrain createTerrainOfIntensity(double intensity){
		return new Terrain(getBrushDensity(), getBrushDensityWeight()*intensity, getElevation(), getElevationWeight()*intensity, getTemperature(), getTemperatureWeight()*intensity, getGroundCohesion(), getGroundCohesionWeight()*intensity, getWaterDepth(), getWaterDepthWeight()*intensity);
	}
	public double getBrushDensityWeight(){return m_brushDensityWeight;}
	public double getElevationWeight(){return m_elevationWeight;}
	public double getGroundCohesionWeight(){return m_groundCohesionWeight;}
	public double getTemperatureWeight(){return m_temperatureWeight;}
	public double getWaterDepthWeight(){return m_waterDepthWeight;}
	
	public double getBrushDensity(){return m_brushDensity;}
	public double getElevation(){return m_elevation;}
	public double getGroundCohesion(){return m_groundCohesion;}
	public double getTemperature(){return m_temperature;}
	public double getWaterDepth(){return m_waterDepth;}
	
	public void setBrushDensity(double brushDensity){m_brushDensity=brushDensity;}
	public void setElevation(double elevation){m_elevation=elevation;}
	public void setGroundCohesion(double cohesion){m_groundCohesion=cohesion;}
	public void setTemperature(double temp){m_temperature=temp;}
	public void setWaterDepth(double waterDepth){m_waterDepth=waterDepth;}
	
	public void setWaterDepthWeight(double waterDepthWeight){m_waterDepthWeight=waterDepthWeight;}
	public void setElevationWeight(double elevationWeight){m_elevationWeight=elevationWeight;}
	public void setGroundCohesionWeight(double gcWeight){m_groundCohesionWeight=gcWeight;}
	public void setTemperatureWeight(double tempWeight){m_temperatureWeight=tempWeight;}
	public void setBrushDensityWeight(double bdWeight){m_brushDensityWeight=bdWeight;}
}
