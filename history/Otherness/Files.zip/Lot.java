public class Lot extends ActiveAsset{
	protected Brand m_brand;
	protected double m_quality;
	protected double m_quantity;
	public Lot(ActiveAsset parent, RiffDataPoint point, Brand brand, double quality, double quantity){
		super(parent,point);
		m_brand = brand;
		m_quality = quality;
		m_quantity = quantity;
	}
	public Lot(Lot otherLot){
		this(otherLot.getParent(), otherLot.getPosition(), otherLot.getBrand(), otherLot.getQuality(), otherLot.getQuantity());
	}
	public Integer getAssetType(){return Asset.LOT;}
	public boolean isAssetOfType(Integer type){
		return(type.equals(getAssetType())||super.isAssetOfType(type));
	}
	public boolean isUnique(){return false;}
	public boolean isTangible(){return true;}
	public Object clone(){return new Lot(this);}
	public boolean mergeAsset(Asset asset){
		if(!asset.getAssetType().equals(Asset.LOT)){return false;}
		Lot lot = (Lot)asset;
		if(!lot.getBrand().equals(getBrand())){return false;}
		double grossQuality = m_quantity * m_quality;
		double lotQuality = lot.getQuality() * lot.getQuantity();
		m_quantity = m_quantity + lot.getQuantity();
		m_quality = (grossQuality + lotQuality) / m_quantity;
		return true;
	}
	public Lot getSlice(double quantity){
		if(quantity>=getQuantity()){return this;}
		setQuantity(getQuantity()-quantity);
		return new Lot(getParent(), getPosition(),getBrand(), getQuality(), quantity);
	}
	public double getQuality(){return m_quality;}
	public double getQuantity(){return m_quantity;}
	public boolean setQuantity(double quantity){m_quantity = quantity;return true;}
	public Commodity getCommodity(){return m_brand.getCommodity();}
	public Brand getBrand(){return m_brand;}
	public void iterate(double iterationTime){}
	public String toString(){
		String string = new String();      
		string += "\n" + RiffToolbox.printUnderline("Lot of " + m_brand.getName(), "-");
		string += "Commodity: " + m_brand.getCommodity().getName() + "\n";
		string += "Quality: " + m_quality + " | Quantity: " + m_quantity;
		return string;
	}
}
