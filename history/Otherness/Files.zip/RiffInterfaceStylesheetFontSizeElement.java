public class RiffInterfaceStylesheetFontSizeElement extends RiffInterfaceStylesheetElement{
	private int m_fontSize;
	public RiffInterfaceStylesheetFontSizeElement(int fontSize){
		m_fontSize=fontSize;
	}
	public int getFontSize(){return m_fontSize;}
}
