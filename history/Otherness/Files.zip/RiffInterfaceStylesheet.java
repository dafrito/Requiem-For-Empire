import java.awt.*;
import java.util.*;


public class RiffInterfaceStylesheet{
	public Map m_styleElements=new HashMap(); // element code, element
	public RiffInterfaceStylesheet(){}
	public void activateStyle(Graphics2D g2d){
		
	}
	public void addElement(short elementCode, RiffInterfaceStylesheetElement element){
		m_styleElements.put(new Short(elementCode), element);
	}
	public RiffInterfaceStylesheetElement getElement(short elementCode){return (RiffInterfaceStylesheetElement)m_styleElements.get(new Short(elementCode));}
}
