import javax.swing.*; // For JPanel, etc.
import java.util.*;
import java.awt.*;

import java.awt.event.*;
public class RiffJavaToolbox{
	public static JPanel createInfoBox(Scenario scenario){
		return new ScenarioInfoPanel(scenario);
	}
	public static JPanel createInfoBox(Organization organization){
		return new OrganizationInfoPanel(organization);
	}
	public static JPanel createInfoBox(Object object){
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		JTextArea text = new JTextArea("An object that is intended to be placed here has no overloaded drawer.");
		text.setLineWrap(true);
		text.setWrapStyleWord(true);
		text.setEditable(false);
		panel.add(text);
		JPanel infoPanel = new JPanel();
		infoPanel.setLayout(new GridLayout(1,1));
		infoPanel.setBorder(BorderFactory.createTitledBorder("Debug Spew"));
		text = new JTextArea(object.toString());
		text.setLineWrap(true);
		text.setWrapStyleWord(true);
		text.setEditable(false);
		infoPanel.add(text);
		panel.add(infoPanel);
		panel.setBorder(BorderFactory.createTitledBorder("Unsupported Object"));
		return panel;
	}
	public static JButton createButtonLink(JFrame frame, String text){
		JButton button = new JButton(text);
		button.addActionListener((ActionListener)frame);
		button.setBackground(Color.WHITE);
		button.setBorderPainted(false);
		button.setContentAreaFilled(false);
		return button;
	}
	public static JPanel getKeyValueBox(String string, java.util.List keys, java.util.List values){
		JPanel basePanel = new JPanel();
		basePanel.setBorder(BorderFactory.createTitledBorder(string));
		int gridSize = keys.size();
		if(values.size()>gridSize){gridSize=values.size();}
		JPanel keyPanel=new JPanel();
		keyPanel.setLayout(new GridLayout(gridSize, 1));
		Iterator iter=keys.iterator();
		while(iter.hasNext()){
			keyPanel.add(getKeyLabel(iter.next()));
		}
		JPanel valuePanel=new JPanel();
		valuePanel.setLayout(new GridLayout(gridSize, 1));
		iter=values.iterator();
		while(iter.hasNext()){
			valuePanel.add(getValueLabel(iter.next()));
		}
		basePanel.add(keyPanel);
		basePanel.add(valuePanel);
		return basePanel;
	}
	public static JLabel getKeyLabel(Object o){return getKeyLabel(o.toString());}
	public static JLabel getKeyLabel(String string){
		JLabel label=new JLabel(string);
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		return label;
	}
	public static JTextArea getValueLabel(Object o){return getValueLabel(o.toString());}
	public static JTextArea getValueLabel(String string){
		JTextArea area=new JTextArea(string);
		area.setWrapStyleWord(true);
		area.setEditable(false);
		return area;
	}
}
