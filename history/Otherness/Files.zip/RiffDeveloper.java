// Requiem for Empire

import java.awt.event.*;
import javax.swing.*; // For JPanel, etc.
import java.io.*;
import java.util.*;
import java.awt.*;

public class RiffDeveloper extends JFrame implements ActionListener{
	private JMenuItem m_newScenarioMenuItem, m_openScenarioMenuItem, m_saveScenarioMenuItem, m_saveScenarioAsMenuItem, m_exitMenuItem,m_closeScenarioMenuItem;
	private JRadioButtonMenuItem m_scenarioViewerMenuItem, m_elementViewerMenuItem;
	private int m_currentAction=0;
	private static final int SCENARIOVIEWER=0;
	private static final int ELEMENTVIEWER=1;
	private Scenario m_scenario;
	private boolean m_isEdited;
	private File m_scenarioFile;
	private JPanel m_developerPanel;
	private JMenu m_operationsMenu;
	private JLabel m_statusBar;
	private JPanel m_linkBar;
	private static final int HEIGHT=768;
	private static final int WIDTH=1024;
	public RiffDeveloper(){super("Requiem for Empire");}
	public void createWindow(){
		add(new RiffInterfacePageElement());
		/*JMenuBar jmb = new JMenuBar();
		setJMenuBar(jmb);
		// System Menu
		JMenu systemMenu=new JMenu("System");
		systemMenu.setMnemonic('S');
		jmb.add(systemMenu);
		systemMenu.add(m_newScenarioMenuItem=new JMenuItem("New Scenario", 'N'));
		m_newScenarioMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
		m_newScenarioMenuItem.addActionListener(this);
		systemMenu.add(m_openScenarioMenuItem=new JMenuItem("Open Scenario...", 'O'));
		m_openScenarioMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
		m_openScenarioMenuItem.addActionListener(this);
		systemMenu.add(m_closeScenarioMenuItem=new JMenuItem("Close Scenario", 'C'));
		m_closeScenarioMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, ActionEvent. CTRL_MASK));
		m_closeScenarioMenuItem.addActionListener(this);
		systemMenu.add(m_saveScenarioMenuItem=new JMenuItem("Save Scenario", 'S'));
		m_saveScenarioMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, ActionEvent.CTRL_MASK));
		m_saveScenarioMenuItem.addActionListener(this);
		systemMenu.add(m_saveScenarioAsMenuItem=new JMenuItem("Save Scenario As...", 'A'));
		m_saveScenarioAsMenuItem.addActionListener(this);
		systemMenu.add(m_exitMenuItem=new JMenuItem("Exit", 'X'));
		m_exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
		m_exitMenuItem.addActionListener(this);
		// Operations Menu
		m_operationsMenu=new JMenu("Operations");
		m_operationsMenu.setMnemonic('O');
		jmb.add(m_operationsMenu);
		m_operationsMenu.add(m_scenarioViewerMenuItem=new JRadioButtonMenuItem("Scenario Viewer"));
		m_scenarioViewerMenuItem.setAccelerator(KeyStroke.getKeyStroke('C', ActionEvent.SHIFT_MASK));
		m_scenarioViewerMenuItem.addActionListener(this);
		m_scenarioViewerMenuItem.setMnemonic('C');
		m_operationsMenu.add(m_elementViewerMenuItem=new JRadioButtonMenuItem("Element Viewer"));
		m_elementViewerMenuItem.setAccelerator(KeyStroke.getKeyStroke('E', ActionEvent.SHIFT_MASK));
		m_elementViewerMenuItem.addActionListener(this);
		m_elementViewerMenuItem.setMnemonic('E');
		ButtonGroup buttonGroup= new ButtonGroup();
		buttonGroup.add(m_scenarioViewerMenuItem);
		buttonGroup.add(m_elementViewerMenuItem);
		// Basic layout
		getContentPane().setLayout(new BorderLayout());
		disableAllScenarioOptions();
		m_developerPanel=new JPanel();
		m_developerPanel.setLayout(new GridLayout(1,1));
		m_statusBar=new JLabel("Ready.");
		m_linkBar=new JPanel();
		m_linkBar.setLayout(new BoxLayout(m_linkBar, BoxLayout.LINE_AXIS));
		getContentPane().add(m_linkBar, BorderLayout.NORTH);
		getContentPane().add(m_developerPanel);
		getContentPane().add(m_statusBar, BorderLayout.SOUTH);
		// See if we can open our last-opened file
		try{
			File currentFile=new File("studio.Riff");
			FileInputStream input = new FileInputStream(currentFile);
			ObjectInputStream s = new ObjectInputStream(input);
			m_scenarioFile=(File)s.readObject();
			if(m_scenarioFile!=null){
				input.close();
				s.close();
				input=new FileInputStream(m_scenarioFile);
				s=new ObjectInputStream(input);
				m_scenario=(Scenario)s.readObject();
				enableAllScenarioOptions();
				openTool(m_currentAction=RiffDeveloper.SCENARIOVIEWER);
				input.close();
				s.close();
				setStatusText("Last-opened scenario opened successfully.");
			}
		}catch(IOException ioEx){
		}catch(ClassNotFoundException ex){}*/
	}
	public void setStatusText(String string){m_statusBar.setText("  " + string);}
	public void closeStudio(){
		if(m_scenarioFile!=null&&m_scenario!=null){
			try{
				File currentFile=m_scenarioFile;
				if(!closeScenario()){return;}
				FileOutputStream out = new FileOutputStream(new File("studio.Riff"));
				ObjectOutputStream s = new ObjectOutputStream(out);
				s.writeObject(currentFile);
				s.close();
				out.close();
			}catch(IOException ioEx){
				System.out.println(ioEx);
			}
		}
		System.exit(0);
	}
	public boolean closeScenario(){
		if(m_scenario==null){return true;}
		if(m_isEdited==true){
			int choice=JOptionPane.showConfirmDialog(this, "Scenario has been edited. Save or discard?", "Scenario changed", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
			switch(choice){
				case JOptionPane.YES_OPTION:
				if(!saveScenario(false)){return false;}
				case JOptionPane.NO_OPTION:
				break;
				default:
				return false;
			}
		}
		m_scenario=null;
		m_scenarioFile=null;
		m_isEdited=false;
		m_developerPanel.removeAll();
		m_developerPanel.revalidate();
		m_developerPanel.repaint();
		disableAllScenarioOptions();
		return true;
	}
	public boolean saveScenario(boolean explicitlyDisplayDialog){
		try{
			if(m_scenario==null){return true;}
			if(!m_isEdited&&!explicitlyDisplayDialog){return true;}
			if(m_scenarioFile==null||explicitlyDisplayDialog){
				ExtensionFilter filter = new ExtensionFilter("RFE Scenario File");
				filter.addExtension("RiffScenario");
				JFileChooser chooser = new JFileChooser();
				chooser.setFileFilter(filter);
				int returnVal = chooser.showSaveDialog(this);
				if(returnVal == JFileChooser.APPROVE_OPTION){
					m_scenarioFile=chooser.getSelectedFile();
				}else{return false;}
				m_saveScenarioMenuItem.setEnabled(false);
				m_saveScenarioMenuItem.setEnabled(true);
				m_saveScenarioAsMenuItem.setEnabled(false);
				m_saveScenarioAsMenuItem.setEnabled(true);
			}
			FileOutputStream out = new FileOutputStream(m_scenarioFile);
			ObjectOutputStream s = new ObjectOutputStream(out);
			s.writeObject(m_scenario);
			s.close();
			out.close();
			m_isEdited=false;
			return true;
		}catch(IOException ioEx){
			System.out.println(ioEx);
			return false;
		}
	}
	public void openScenario(){
		if(!closeScenario()){return;}
		try{
			ExtensionFilter filter = new ExtensionFilter("RFE Scenario File");
			filter.addExtension("RiffScenario");
			JFileChooser chooser = new JFileChooser();
			chooser.setFileFilter(filter);
			int returnVal = chooser.showOpenDialog(this);
			if(returnVal != JFileChooser.APPROVE_OPTION){return;}
			m_scenarioFile=chooser.getSelectedFile();
			m_openScenarioMenuItem.setEnabled(false);
			m_openScenarioMenuItem.setEnabled(true);
			FileInputStream in = new FileInputStream(m_scenarioFile);
			ObjectInputStream s = new ObjectInputStream(in);
			m_scenario = (Scenario)s.readObject();
			s.close();
			in.close();
			m_isEdited=false;
			enableAllScenarioOptions();
			openTool(m_currentAction=RiffDeveloper.SCENARIOVIEWER);
			setStatusText("Scenario opened successfully.");
		}catch(IOException ioEx){
			System.out.println(ioEx);
		}catch(ClassNotFoundException ex){
			System.out.println(ex);
		}
	}
	public void openTool(int newTool){
		m_currentAction=newTool;
		switch(newTool){
			case RiffDeveloper.SCENARIOVIEWER:
			JSplitPane pane=getSplitPane();
			pane.setLeftComponent(RiffJavaToolbox.createInfoBox(m_scenario));
			pane.setRightComponent(new TerrestrialControllerPanel((Terrestrial)m_scenario.getRootLocation()));
			m_developerPanel.add(pane);
			m_scenarioViewerMenuItem.setSelected(true);
			break;
		}
	}
	private JSplitPane getSplitPane(){
		JSplitPane splitPane=new JSplitPane();
		splitPane.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		splitPane.setDividerSize(4);
		splitPane.setLeftComponent(new JPanel());
		splitPane.setRightComponent(new JPanel());
		return splitPane;
	}
	public Scenario getScenario(){return m_scenario;}
	public void actionPerformed(ActionEvent e){
		String action=e.getActionCommand();
		if(e.getSource() instanceof JMenuItem){
			if("Exit".equals(action)){closeStudio();
			}else if("Scenario Viewer".equals(action)){openTool(RiffDeveloper.SCENARIOVIEWER);
			}else if("Save Scenario".equals(action)||"Save Scenario As...".equals(action)){if(saveScenario("Save Scenario As...".equals(action))){setStatusText("Scenario saved successfully.");}
			}else if("Close Scenario".equals(action)){if(closeScenario()){setStatusText("Scenario closed successfully.");}
			}else if("Open Scenario...".equals(action)){openScenario();
			}else if("New Scenario".equals(action)){
				if(!closeScenario()){return;}
				GregorianCalendar startDate = new GregorianCalendar(2100, Calendar.MARCH, 1, 5, 25, 00);
				GregorianCalendar endDate = new GregorianCalendar(2200, Calendar.DECEMBER, 25, 12, 00, 00);
				try{
					m_scenario=new Scenario("New scenario", new Terrestrial("Borel", "Borelli", null, null, 65000.0d), Scenario.SEASON, startDate, endDate);
				}catch(Exception ex){
					System.out.println(ex);
				}
				refreshAllPanels();
				m_isEdited=true;
			}
		}
	}
	public void refreshAllPanels(){
		if(m_scenario==null){disableAllScenarioOptions();return;}
		enableAllScenarioOptions();
		openTool(m_currentAction);
		m_developerPanel.revalidate();
		m_developerPanel.repaint();
	}
	public void disableAllScenarioOptions(){
		m_closeScenarioMenuItem.setEnabled(false);
		m_saveScenarioMenuItem.setEnabled(false);
		m_saveScenarioAsMenuItem.setEnabled(false);
		m_operationsMenu.setEnabled(false);
	}
	public void enableAllScenarioOptions(){
		m_closeScenarioMenuItem.setEnabled(true);
		m_saveScenarioMenuItem.setEnabled(true);
		m_saveScenarioAsMenuItem.setEnabled(true);
		m_operationsMenu.setEnabled(true);
	}
	public static void main(String[] args) {
	 	RiffDeveloper studio=new RiffDeveloper();
		studio.setSize(RiffDeveloper.WIDTH, RiffDeveloper.HEIGHT);
		studio.createWindow();
		studio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		studio.setVisible(true);
	}
}
