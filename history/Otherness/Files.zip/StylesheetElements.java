public class StylesheetElements{
	public static final short WIDTH=0;
	public static final short HEIGHT=1;
	public static final short COLOR=2;
	public static final short FONTNAME=3;
	public static final short FONTSIZE=4;
	public static final short FONTSTYLE=5;
	public static String getCodeName(short code){
		switch(code){
			case WIDTH:return "Width";
			case HEIGHT:return "Height";
			case COLOR:return "Color";
			case FONTNAME:return "Font Name";
			case FONTSIZE:return "Font Size";
			case FONTSTYLE:return "Font Style";
			default:assert RiffToolbox.printError("StylesheetElements/getCodeName","No name defined for code " + code);return "Unknown";
		}
	}
}
