import java.util.*;
import java.io.*;

public class Terrestrial extends RiffDataPoint implements Location, Serializable{
	private double m_radius;
	private Set m_terrainSurfaces=new HashSet();
	private DiscreteRegionBSPNode m_tree;
	public Terrestrial(String name, String formal, String adjective, RiffDataPoint offsetPoint, double radius) throws OverwriteException{
		super(name, formal, adjective, offsetPoint);
		m_radius=radius;
	}
	public Set getAllAssets(){
		return m_tree.getAllAssets();
	}
	public DiscreteRegion findPolygon(RiffDataPoint point){
		return m_tree.findPolygon(point);
	}
	public double getRadius(){return m_radius;}
	public Set getSurfaces(){return m_terrainSurfaces;}
	public void addSurface(RiffSurface surface){
		m_terrainSurfaces.add(surface);
	}
	public void removeSurface(RiffSurface surface){
		m_terrainSurfaces.remove(surface);
	}
	public void iterate(double iterationTime){}
	public String toString(){
		String string = new String();
		string += super.toString();
		return string;
	}
}
