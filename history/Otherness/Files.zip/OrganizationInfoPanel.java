import java.util.*;
import javax.swing.*;
/*public class Organization extends Asset{
	protected String m_formalName;
	protected String m_shortName;
	protected String m_adjective;
	protected AssetMap m_assets;*/
public class OrganizationInfoPanel extends JPanel{
	private Organization m_organization;
	public OrganizationInfoPanel(Organization org){
		m_organization=org;
		List keys = new LinkedList();
		List values = new LinkedList();
		keys.add("Formal name:");
		values.add(org.getFormalName());
		keys.add("Number of assets:");
		values.add(new Integer(org.getAssetListSize()));
		add(RiffJavaToolbox.getKeyValueBox(org.getShortName(), keys, values));
	}
}
