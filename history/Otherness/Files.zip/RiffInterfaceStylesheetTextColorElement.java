import java.awt.*;

public class RiffInterfaceStylesheetTextColorElement extends RiffInterfaceStylesheetElement{
	private Color m_color;
	public RiffInterfaceStylesheetTextColorElement(Color color){
		m_color=color;
	}
	public RiffInterfaceStylesheetTextColorElement(String colorString){
		if(colorString.charAt(0)=='#'){
			m_color=Color.decode(colorString);
		}else{
			m_color=Color.decode("#"+colorString);
		}
	}
	public void activateElement(Graphics2D g2d){
		g2d.setColor(m_color);
	}
}
