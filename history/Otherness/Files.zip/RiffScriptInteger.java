public class RiffScriptInteger extends RiffScriptNumber{
	private int m_value;
	public RiffScriptInteger(int value, RiffScriptLine line, int oLO){
		super(line,oLO);
		m_value=value;
	}
	public int getValue(){return m_value;}
	public double getDoubleValue(){return (double)getValue();}
	public float getFloatValue(){return (float)getValue();}
	public long getLongValue(){return (long)getValue();}
	public int getIntegerValue(){return getValue();}
	public short getShortValue(){return (short)getValue();}
	public String toString(){return "RiffScriptInteger: " + m_value;}
}
