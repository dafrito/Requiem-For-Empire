public interface Tangible{
	public void setPosition(RiffDataPoint location);
	public RiffDataPoint getPosition();
	public ActiveAsset getParent();
	public void setParent(ActiveAsset parent);
}
