public class RiffInterfaceStylesheetWidthElement extends RiffInterfaceStylesheetElement{
	private int m_width;
	public RiffInterfaceStylesheetWidthElement(int width){
		m_width=width;
	}
	public int getWidth(){return m_width;}
	public void setWidth(int width){m_width=width;}
}
