import java.util.*;

public abstract class Asset extends UniqueObject implements Cloneable{
	public static final Integer ASSET = new Integer(0);
	public static final Integer LOT = new Integer(1);
	public static final Integer TAPPABLEASSET = new Integer(2);
	public static final Integer ACTIVEASSET = new Integer(3);
	public static final Integer ORGANIZATION = new Integer(4);
	public static final Integer TERRAIN = new Integer(5);
	public static final Integer INTANGIBLEASSET = new Integer(6);
	public static final Integer POPULATION = new Integer(7);
	public static final Integer TRANSPORT = new Integer(8);
	public static final Integer THINKER = new Integer(9);
	public static final Integer LIVINGBEING = new Integer(10);
	public Integer getAssetType(){return Asset.ASSET;}
	public boolean isAssetOfType(Integer type){
		return(type.equals(getAssetType()));
	}
	public abstract Object clone();
	public abstract void physicalIterate(double iterationTime);
	public abstract String toString();
	public abstract boolean mergeAsset(Asset asset);
	public abstract boolean isUnique();
	public abstract boolean isTangible();
	public boolean equals(Object obj){
		return (getAssetType()==((Asset)obj).getAssetType());
	}
}
