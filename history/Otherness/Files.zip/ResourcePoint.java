public class ResourcePoint extends TappableAsset{
	private double m_optimumLevel;
	private double m_spawnRate;
	private double m_currentLevel;
	private double m_standardDeviation;
	private double m_averageQuality;
	private double m_gatherRate;
	public ResourcePoint(RiffDataPoint point, Brand brand, double optimumLevel, double standardDeviation, double quality, double gatherRate){
		super(point,brand);
		m_optimumLevel = optimumLevel;
		m_standardDeviation = standardDeviation;
		m_averageQuality = quality;
		m_gatherRate = gatherRate;
	}
	public double getSlice(double iterationTime){
		return ((RiffToolbox.getRandom().nextGaussian()%2) * .5 * m_currentLevel + m_currentLevel)*iterationTime/m_gatherRate;
	}
	public void setLevel(double level){m_currentLevel=level;}
	public Lot getLot(Population population, double quantity){
		if(quantity > m_currentLevel){quantity = m_currentLevel;}
		//public Lot(Brand brand, double quality, double quantity){
		return new Lot(population, population.getPosition(), getBrand(), m_averageQuality + RiffToolbox.getRandom().nextGaussian() * m_standardDeviation, quantity);
	}
	public void iterate(int iterationTime){
		m_currentLevel += m_spawnRate * iterationTime;
	}
}
