import java.util.*;

public class RiffScriptParamGroup extends RiffScriptGroup{
	public RiffScriptParamGroup(List list){
		super(list);
	}
	public String getName(){return "RiffScriptParamGroup";}
	public static RiffScriptParamGroup createElement(Object obj){return new RiffScriptParamGroup((List)obj);}
	public String toString(){return "RiffScriptParamGroup: " + RiffToolbox.displayList(m_elements);}
}
