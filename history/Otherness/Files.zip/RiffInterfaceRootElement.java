import java.awt.*;
import javax.swing.*;
import java.util.*;

public class RiffInterfaceRootElement extends RiffInterfaceElement{
	private JPanel m_drawingPanel;
	public RiffInterfaceRootElement(JPanel drawingPanel){
		super(null);
		m_drawingPanel=drawingPanel;
		setXAnchor(8);
		setYAnchor(20);
	}
	public RiffInterfaceRootElement getRoot(){return this;}
	public Graphics2D getGraphics(){return (Graphics2D)m_drawingPanel.getGraphics();}
	public Rectangle getDrawingBounds(){return new Rectangle(m_drawingPanel.getWidth(), m_drawingPanel.getHeight());}
	public Rectangle getDrawingBoundsUsingWidth(int width){return new Rectangle(width, m_drawingPanel.getHeight());}
	public void paint(Graphics2D g2d){
		RiffInterfaceStylesheetWidthElement widthElement=(RiffInterfaceStylesheetWidthElement)getStyleElement(StylesheetElements.WIDTH);
		Iterator iter=getElementsIterator();
		int xAnchorOffset=getXAnchor();
		int yAnchorOffset=getYAnchor();
		int nextLineAnchorOffset=0;
		while(iter.hasNext()){
			RiffInterfaceElement element=(RiffInterfaceElement)iter.next();
			Rectangle rect=element.getDrawingBounds();
			if(rect.getWidth()>widthElement.getWidth()-xAnchorOffset){
				rect=element.getDrawingBoundsUsingWidth(widthElement.getWidth()-xAnchorOffset);
				if(rect.getWidth()>widthElement.getWidth()-xAnchorOffset){
					yAnchorOffset+=nextLineAnchorOffset;
					xAnchorOffset=getXAnchor();
				}
			}
			element.setXAnchor(xAnchorOffset);
			element.setYAnchor(yAnchorOffset);
			xAnchorOffset+=rect.getWidth();
			if(nextLineAnchorOffset<rect.getHeight()){
				nextLineAnchorOffset=(int)rect.getHeight();
			}
			element.paint(g2d);
		}
	}
	public RiffInterfaceStylesheetElement getStyleElement(short code){
		RiffInterfaceStylesheet sheet=getUniqueStylesheet();
		if(sheet==null){
			setUniqueStylesheet(new RiffInterfaceStylesheet());
			sheet=getUniqueStylesheet();
		}
		/*case WIDTH:return "Width";
			case HEIGHT:return "Height";
			case COLOR:return "Color";
			case FONTNAME:return "Font Name";
			case FONTSIZE:return "Font Size";
			case FONTSTYLE:return "Font Style";*/
		RiffInterfaceStylesheetElement element=getUniqueStylesheet().getElement(code);
		switch(code){
			case StylesheetElements.WIDTH:
			if(element!=null){((RiffInterfaceStylesheetWidthElement)element).setWidth(m_drawingPanel.getWidth()-getXAnchor());
			}else{
				element=new RiffInterfaceStylesheetWidthElement(m_drawingPanel.getWidth()-getXAnchor());
				sheet.addElement(code,element);
			}
			return element;
			case StylesheetElements.HEIGHT:
			if(element!=null){((RiffInterfaceStylesheetHeightElement)element).setHeight(m_drawingPanel.getHeight()-getYAnchor());
			}else{element=new RiffInterfaceStylesheetHeightElement(m_drawingPanel.getHeight()-getYAnchor());sheet.addElement(code,element);}
			return element;
			case StylesheetElements.COLOR:
			if(element!=null){return element;}
			element=new RiffInterfaceStylesheetTextColorElement(Color.BLACK);
			sheet.addElement(code,element);
			return element;
			case StylesheetElements.FONTNAME:
			if(element!=null){return element;}
			element=new RiffInterfaceStylesheetFontElement("Palatino Linotype");
			sheet.addElement(code,element);
			return element;
			case StylesheetElements.FONTSIZE:
			if(element!=null){return element;}
			element=new RiffInterfaceStylesheetFontSizeElement(12);
			sheet.addElement(code,element);
			return element;                         
			case StylesheetElements.FONTSTYLE:
			if(element!=null){return element;}
			element=new RiffInterfaceStylesheetFontStyleElement(Font.PLAIN);
			sheet.addElement(code,element);
			return element;
			default:
			assert RiffToolbox.printError("RiffInterfaceStylesheetElement/getStyleElement", "No default setting set for element: " + StylesheetElements.getCodeName(code));
			return null;
		}
	}
}
