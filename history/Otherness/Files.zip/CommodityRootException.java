public class CommodityRootException extends CommodityMapException{
	private CommodityMapNode m_node;
	private Commodity m_comm;
	public CommodityRootException(CommodityMapNode node, Commodity comm){
		m_node = node;
		m_comm = comm;
	}
	public String getMessage(){
		String string = new String();
		string += "An action exclusive to real nodes was trying to be performed to the root commodity map node.";
		string += "\nNode: " + m_node;
		string += "\nCommodity: " + m_comm;
		return string;
	}
}
