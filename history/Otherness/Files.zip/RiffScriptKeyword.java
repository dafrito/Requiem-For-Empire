public class RiffScriptKeyword extends RiffScriptElement{
	private short m_keywordCode;
	public static final short UNKNOWN=-1;
	public static final short UNIQUE=0;
	public static final short STYLE=1;
	public static final short FUNCTION=2;
	public static final short NEW=3;
	public static final short IF=4;
	public static final short PUBLIC=5;
	public static final short CLASS=6;
	public static final short EXTENDS=7;
	public static final short IMPLEMENTS=8;
	public static final short SHORT=9;
	public static final short INT=10;
	public static final short FLOAT=11;
	public static final short DOUBLE=12;
	public static final short RETURN=13;
	public static final short STATIC=14;
	public RiffScriptKeyword(String string, RiffScriptLine line,  int oLO){
		super(line, oLO);
		m_keywordCode=getKeywordCode(string);
	}
	public RiffScriptKeyword(short keyword, RiffScriptLine line, int oLO){
		super(line, oLO);
		m_keywordCode=keyword;
	}
	public static short getKeywordCode(String string){
		if("unique".equals(string)){return UNIQUE;}
		if("style".equals(string)){return STYLE;}
		if("function".equals(string)){return FUNCTION;}
		if("new".equals(string)){return NEW;}
		if("if".equals(string)){return IF;}
		if("public".equals(string)){return PUBLIC;}
		if("class".equals(string)){return CLASS;}
		if("extends".equals(string)){return EXTENDS;}
		if("implements".equals(string)){return IMPLEMENTS;}
		if("short".equals(string)){return SHORT;}
		if("int".equals(string)){return INT;}
		if("float".equals(string)){return FLOAT;}
		if("double".equals(string)){return DOUBLE;}
		if("return".equals(string)){return RETURN;}
		if("static".equals(string)){return STATIC;}
		return UNKNOWN;
	}
	public short getKeywordCode(){return m_keywordCode;}
	public static String getKeyword(short code){
		switch(code){
			case UNIQUE:return "unique";
			case STYLE:return "style";
			case FUNCTION:return "function";
			case NEW:return "new";
			case IF:return "if";
			case PUBLIC:return "public";
			case CLASS:return "class";
			case EXTENDS:return "extends";
			case IMPLEMENTS:return "implements";
			case SHORT:return "short";
			case INT:return "int";
			case FLOAT:return "float";
			case DOUBLE:return "double";
			case RETURN:return "return";
			case STATIC:return "static";
			default:return "unknown";
		}
	}
	public String toString(){return "RiffScriptKeyword: " + getKeyword(m_keywordCode);}
}
