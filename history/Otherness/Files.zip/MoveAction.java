import java.lang.Math;

public class MoveAction extends Action{
	private static String m_actionName = new String("Move");
	public String toString(){return m_actionName;}
	public static void execute(Order superOrder) throws FailedActionException{
		assert RiffToolbox.printDebug("MoveAction/execute", "(execute)\nMove action executing..");
		MoveOrder order = (MoveOrder)superOrder;
		assert RiffToolbox.printDebug("MoveAction/execute", "Iteration time: " + order.getIterationTime());
		double thisTraveledDistance = order.getTransport().getVelocity(order.getIterationTime()) * order.getIterationTime();
		double remainingDistance = order.getTradeLink().getCurrentRouteDistance() - order.getOffsetDistance();
		assert RiffToolbox.printDebug("MoveAction/execute", "Total distance: " + order.getTradeLink().getCurrentRouteDistance());
		assert RiffToolbox.printDebug("MoveAction/execute", "Remaining distance: " + remainingDistance);
		assert RiffToolbox.printDebug("MoveAction/execute", "Distance traveled this turn: " + thisTraveledDistance);
		if(remainingDistance >= thisTraveledDistance){
			assert RiffToolbox.printDebug("MoveAction/execute", "Traveled distance is less than or equal to the distance necessary to complete this route");
			order.addOffsetDistance(thisTraveledDistance);
			order.getTransport().expendFuel(order.getIterationTime());
			order.setIterationTime(0);
		}else{
			assert RiffToolbox.printDebug("MoveAction/execute", "Traveled distance is greater than the distance necessary to complete this route.");
			double overage = order.getTradeLink().getCurrentRouteDistance() - order.getOffsetDistance() - thisTraveledDistance;
			overage *= -1;
			double time = overage / order.getTransport().getVelocity(order.getIterationTime());
			assert RiffToolbox.printDebug("MoveAction/execute", "Overage distance: " + overage);
			assert RiffToolbox.printDebug("MoveAction/execute", "Time spent traveling overage: " + time);
			order.getTransport().expendFuel(order.getIterationTime() - time);
			order.setIterationTime(order.getIterationTime() - time);
			RiffDataPoint point=null;
			if(order.getTradeLink().hasNext()){
				order.getTradeLink().goToNextRoute();
				point=order.getTradeLink().getCurrentStartingPoint();
			}else{
				point=order.getTradeLink().getCurrentEndingPoint();
			}
			order.getTransport().setPosition(point);
		}
		assert RiffToolbox.printDebug("MoveAction/execute", "(/execute)");
	}
}
