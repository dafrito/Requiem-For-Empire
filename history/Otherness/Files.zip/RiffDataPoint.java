public class RiffDataPoint extends NamedElement implements Comparable{
	protected RiffDataPoint m_point;
	protected String m_pointName;
	public RiffDataPoint(){}
	public RiffDataPoint(String name, String formal, String adj, RiffDataPoint point){
		super(name, formal, adj);
		m_point=point;
	}
	public RiffDataPoint(RiffDataPoint point){
		m_point = point;
	}
	public String getName(){return m_pointName;}
	public void setName(String name){m_pointName=name;}
	public double getOverlap(RiffDataPoint point){return m_point.getOverlap(point);}
	public RiffAbsolutePoint getAbsolutePosition(){return m_point.getAbsolutePosition();}
	public void iterate(int iterationTime){m_point.iterate(iterationTime);}
	public int compareTo(Object obj){
		return getAbsolutePosition().compareTo(((RiffDataPoint)obj).getAbsolutePosition());
	}
	public boolean equals(Object obj){
		return getAbsolutePosition().equals(((RiffDataPoint)obj).getAbsolutePosition());
	}
	public String toString(){
		String string = new String();
		string += "RiffDataPoint:";
		string += "\nPoint: " + m_point;
		return string;
	}
}
