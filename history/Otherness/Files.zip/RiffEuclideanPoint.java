public class RiffEuclideanPoint extends RiffAbsolutePoint{
	private double m_x, m_y, m_z;
	private static int m_pointNum=0;
	public RiffEuclideanPoint(double x, double y, double z){
		this(null, x,y,z);
	}
	public RiffEuclideanPoint(String name, double x, double y, double z){
		this(name, name, null, x,y,z);
	}
	public RiffEuclideanPoint(String name, String formal, String adj, double x, double y, double z){
		super(name, formal, adj);
		m_pointNum++;
		m_x=x;
		m_y=y;
		m_z=z;
	}
	public boolean equals(Object o){
		RiffEuclideanPoint testPoint = (RiffEuclideanPoint)((RiffDataPoint)o).getAbsolutePosition();
		return(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, m_x,testPoint.getX())&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, m_y,testPoint.getY())&&RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, m_z,testPoint.getZ()));
	}
	public int compareTo(Object o){
		RiffEuclideanPoint testPoint = (RiffEuclideanPoint)((RiffDataPoint)o).getAbsolutePosition();
		if(m_x>testPoint.getX()){return 1;}
		if(m_x<testPoint.getX()){return -1;}
		if(m_y>testPoint.getY()){return 1;}
		if(m_y<testPoint.getY()){return -1;}
		if(m_z>testPoint.getZ()){return 1;}
		if(m_z<testPoint.getZ()){return -1;}
		return 0;
	}
	public void setX(double x){m_x=x;}
	public void setY(double y){m_y=y;}
	public void setZ(double z){m_z=z;}
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public String toString(){
		String string = new String();
		string += "(" + m_x;
		string += ", " + m_y;
		string += ", " + m_z + ")";
		return string;
	}
}
