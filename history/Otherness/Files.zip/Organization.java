import java.util.*;

public class Organization extends Asset{
	protected String m_formalName;
	protected String m_shortName;
	protected String m_adjective;
	protected final int SHORTNAMEMAXLENGTH = 30;	
	protected AssetMap m_assets;
	public Organization(){
		m_formalName = new String();
		m_adjective = new String();
		m_shortName = new String();
		m_assets = new AssetMap();
	}
	public Organization(String formal, String adj, String shortName){
		m_formalName = formal;
		m_adjective = adj;
		m_shortName = shortName;
		m_assets = new AssetMap();
	}
	public Organization(Organization org){
		this(org.getFormalName(),org.getAdjective(), org.getShortName());
		m_assets=org.getAssets();
	}
	public Integer getAssetType(){return Asset.ORGANIZATION;}
	public boolean isAssetOfType(Integer type){
		return (type.equals(getAssetType())||super.isAssetOfType(type));
	}
	public boolean isUnique(){return false;}
	public boolean isTangible(){return false;}
	public void physicalIterate(double iterationTime){}
	public Object clone(){return new Organization(this);}
	public int getAssetListSize(){return m_assets.size();}
	public boolean mergeAsset(Asset asset){
		if(!asset.getAssetType().equals(Asset.ORGANIZATION)){return false;}
		return true; // TODO: This.
	}
	public String getName(){return getShortName();}
	public String getFormalName(){return m_formalName;}
	public String getShortName(){return m_shortName;}
	public String getAdjective(){return m_adjective;}
	public boolean setFormalName(String formalName){m_formalName = formalName;return true;}
	public boolean setAdjective(String adj){m_adjective = adj; return true;}
	public boolean setShortName(String name){
		if(name.length() > SHORTNAMEMAXLENGTH && m_formalName == null){
			return false;
		}
		m_shortName = name;
		return true;
	}
	public void iterate(double time){
		
	}
	public AssetMap getAssets(){return m_assets;}
	public boolean equals(Object org){
		return (m_formalName == ((Organization)org).getFormalName());
	}
	public int compareTo(Object org){
		return m_formalName.compareTo(((Organization)org).getFormalName());
	}
	public String toString(){return new String();// TODO: This..
	}
}
