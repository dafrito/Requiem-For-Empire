public interface Thinker{
	public void evaluate();
}
