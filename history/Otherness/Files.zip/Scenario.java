import java.util.*;
import java.io.*;

public class Scenario implements Serializable{
	private Location m_rootLocation;
	private String m_scenarioName;
	private Calendar m_gameCalendar;
	private int m_timeScale;
	private int m_numIterations;
	private Calendar m_endDate;
	private Date m_lastIteration;
	private Set m_organizations;
	public static final int MINUTE=60;
	public static final int HOUR=3600;
	public static final int DAY=3600*24;
	public static final int SEASON=((365/4)*3600*24)/(3600*24);
	private Scenario(){} // explicitly forbidden.
	public Scenario(String scenarioName, Location rootLocation, int timeScale, Calendar startDate, Calendar endDate) throws InvalidScenarioDateRangeException{
		if(startDate.getTime().compareTo(endDate.getTime()) > 0){throw(new InvalidScenarioDateRangeException(this));}
		m_rootLocation = rootLocation;
		m_timeScale = timeScale;
		m_gameCalendar = startDate;
		m_gameCalendar.setLenient(true);
		m_endDate = endDate;
		m_scenarioName = scenarioName;
		m_organizations = new HashSet();
		m_lastIteration = new Date(System.currentTimeMillis());
		LogManager.writeDebug(m_scenarioName, "A scenario with the following parameters was created:\n\n" + this);
	}
	public Set getOrganizations(){return m_organizations;}
	public int getTimescale(){return m_timeScale;}
	public int getCurrentIteration(){return m_numIterations;}
	public Location getRootLocation(){return m_rootLocation;}
	public boolean setEndDate(Calendar endDate){m_endDate = endDate;return true;}
	public Date getEndDate(){return m_endDate.getTime();}
	public Date getDate(){return m_gameCalendar.getTime();}
	public String getScenarioName(){return m_scenarioName;}
	public void iterate(double elapsedTime){
		m_gameCalendar.add(GregorianCalendar.SECOND, (int)elapsedTime);
		m_rootLocation.iterate(elapsedTime);
		m_numIterations++;
		m_lastIteration = new Date(System.currentTimeMillis());
		Set assets = m_rootLocation.getAllAssets();
		Set thinkers = new HashSet();
		Set livingBeings = new HashSet();
		thinkers.addAll(m_organizations);
		Iterator iter=assets.iterator();
		while(iter.hasNext()){
			Asset asset=(Asset)iter.next();
			asset.physicalIterate(elapsedTime);
			if(asset.isAssetOfType(Asset.THINKER)){
				thinkers.add(asset);
			}
			if(asset.isAssetOfType(Asset.LIVINGBEING)){
				livingBeings.add(asset);
			}
		}
		iter=livingBeings.iterator();
		while(iter.hasNext()){
			LivingBeing being=(LivingBeing)iter.next();
			being.iterate(elapsedTime);
		}
		iter=thinkers.iterator();
		while(iter.hasNext()){
			Thinker thinker=(Thinker)iter.next();
			thinker.evaluate();
		}
	}
	public void iterate(){
		iterate((System.currentTimeMillis() - m_lastIteration.getTime()) / 1000);
	}
	public String toString(){
		String string = new String();
		string += "Scenario: " + m_scenarioName + "\n";
		string += "Current date: " + m_gameCalendar.getTime() + "\n";
		string += "End date: " + m_endDate.getTime() + "\n";
		switch(m_timeScale){
		case 60:string += "Timescale: 1 second : 1 game-minute (1:" + m_timeScale + ")\n"; break;
		case 3600:string += "Timescale: 1 second : 1 game-hour (1:" + m_timeScale + ")\n";break;
		case 3600*24:string += "Timescale: 1 second: 1 game-day (1:" + m_timeScale + ")\n";break;
		case (((365/4)*3600*24)/(3600*24)): string += "Timescale: 1 day: 1 season (1:" + m_timeScale + ")\n";break;
		default:string += "Timescale: 1:" + m_timeScale + "\n";
		}
		string += "Number of iterations: " + m_numIterations + "\n";
		string += "Root element data follows: \n";
		string += m_rootLocation;
		return string;
	}
}