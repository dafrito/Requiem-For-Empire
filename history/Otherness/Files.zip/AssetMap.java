import java.util.*;

public class AssetMap{
	private Map m_tangibleAssets; // String, List
	private Map m_tangibleUniqueAssets;
	private Map m_intangibleAssets;
	private Map m_intangibleUniqueAssets;
	private List m_allAssets;
	public AssetMap(){
		m_tangibleAssets = new HashMap();
		m_tangibleUniqueAssets = new HashMap();
		m_intangibleAssets = new HashMap();
		m_intangibleUniqueAssets = new HashMap();
		m_tangibleAssets.put(Asset.LOT, new CommodityMapNode());
	}
	public Asset getAsset(Integer type){
		Object obj = m_tangibleUniqueAssets.get(type);
		if(obj!=null){return (Asset)obj;}
		return (Asset)m_intangibleUniqueAssets.get(type);
	}
	public List getAllAssets(){return m_allAssets;}
	public int size(){return m_allAssets.size();}
	public List getAssets(Commodity comm){return ((CommodityMapNode)m_tangibleAssets.get(Asset.LOT)).getLotList(comm);}
	public void add(Lot lot) throws CommodityMapException{m_allAssets.add(lot);((CommodityMapNode)m_tangibleAssets.get(Asset.LOT)).addLot(lot);}
	public void add(Asset asset)throws CommodityMapException{
		Map assetMap=null;
		if(asset.isUnique()){
			if(asset.isTangible()){
				assetMap=m_tangibleUniqueAssets;
			}else{
				assetMap=m_intangibleUniqueAssets;
			}
			if(assetMap.get(asset.getAssetType())==null){
				assetMap.put(asset.getAssetType(), asset);
				m_allAssets.add(asset);
			}else{
				if(!((Asset)assetMap.get(asset.getAssetType())).mergeAsset(asset)){
					throw(new UniqueAssetNotMergingException(asset, (Asset)assetMap.get(asset.getAssetType())));
				}
			}
			return;
		}
		if(asset.isTangible()){
			assetMap=m_tangibleAssets;
		}else{
			assetMap=m_intangibleAssets;
		}
		m_allAssets.add(asset);
		if(assetMap.get(asset.getAssetType())==null){
			assetMap.put(asset.getAssetType(), new LinkedList());
		}else{
			((List)assetMap.get(asset.getAssetType())).add(asset);
		}
	}
	public void addAll(Collection list)throws CommodityMapException{
		Iterator iter=list.iterator();
		while(iter.hasNext()){
			add((Asset)iter.next());
		}
	}
	public void remove(Asset asset){
		Map assetMap=null;
		m_allAssets.remove(asset);
		if(asset.isUnique()){
			if(asset.isTangible()){
				assetMap=m_tangibleUniqueAssets;
			}else{
				assetMap=m_intangibleUniqueAssets;
			}
			assetMap.remove(asset.getAssetType());
		}else{
			if(asset.isTangible()){
				assetMap=m_tangibleAssets;
			}else{
				assetMap=m_intangibleAssets;
			}
			((List)assetMap.get(asset.getAssetType())).remove(asset);
		}
	}
	public void removeAll(Collection assets){
		Iterator iter=assets.iterator();
		while(iter.hasNext()){
			remove((Asset)iter.next());
		}
	}
	public String toString(){
		String string = new String();
		string += "AssetMap: ";
		// TODO: this.
		return string;
	}
}
