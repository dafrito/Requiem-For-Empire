public class RiffScriptOperator extends RiffScriptElement{
	public static final short UNKNOWN=-1;
	public static final short COMMA=0;
	public static final short EQUIVALENCY=1;
	public static final short GREATEREQUALS=2;
	public static final short LESSEQUALS=3;
	public static final short GREATER=4;
	public static final short LESS=5;
	public static final short NOT=6;
	public static final short AND=7;
	public static final short OR=8;
	public static final short INCREMENT=9;
	public static final short DECREMENT=10;
	public static final short PLUSEQUALS=11;
	public static final short MINUSEQUALS=12;
	public static final short MULTIPLYEQUALS=13;
	public static final short DIVIDEEQUALS=14;
	public static final short MODULUSEQUALS=15;
	public static final short ASSIGNMENT=16;
	public static final short MINUS=17;
	public static final short PLUS=18;
	public static final short MULTIPLY=19;
	public static final short DIVIDE=20;
	public static final short MODULUS=21;
	public static final short PERIOD=22;
	public static final short COLON=23;
	public static final short POUNDSIGN=24;
	private final short m_operator;
	public RiffScriptOperator(short operator, RiffScriptLine line, int oLO){
		super(line, oLO);
		m_operator=operator;
	}
	public int getOperator(){return m_operator;}
	public String toString(){
		return "RiffScriptOperator: " + getOperatorName(m_operator);
	}
	public static String getOperatorName(String string){return getOperatorName(getNumericCode(string));}
	public static String getOperatorName(int operatorCode){
		switch(operatorCode){
			case COMMA:return "Comma";
			case EQUIVALENCY:return "Equivalency";
			case GREATEREQUALS:return "Greater than or Equals to";
			case LESSEQUALS:return "Less than or Equals to";
			case GREATER:return "Greater than";
			case LESS:return "Less than";
			case NOT:return "Not";
			case AND:return "And";
			case OR:return "Or";
			case INCREMENT:return "Increment";
			case DECREMENT:return "Decrement";
			case PLUSEQUALS:return "Plus-Equals";
			case MINUSEQUALS:return "Minus-Equals";
			case MULTIPLYEQUALS:return "Multiply-Equals";
			case DIVIDEEQUALS:return "Divide-Equals";
			case MODULUSEQUALS:return "Modulus-Equals";
			case ASSIGNMENT:return "Assignment";
			case MINUS:return "Subtraction";
			case PLUS:return "Addition";
			case MULTIPLY:return "Multiply";
			case DIVIDE:return "Divide";
			case MODULUS:return "Modulus";
			case PERIOD:return "Period";
			case COLON:return "Colon";
			case POUNDSIGN:return "Pound Sign";
			default:return "Unknown";
		}
	}
	public short getNumericCode(){return m_operator;}
	public static short getNumericCode(String string){
		if(string.equals(",")){return COMMA;}
		if(string.equals("==")){return EQUIVALENCY;}
		if(string.equals(">=")){return GREATEREQUALS;}
		if(string.equals("<=")){return LESSEQUALS;}
		if(string.equals(">")){return GREATER;}
		if(string.equals("<")){return LESS;}
		if(string.equals("!")){return NOT;}
		if(string.equals("&&")){return AND;}
		if(string.equals("||")){return OR;}
		if(string.equals("++")){return INCREMENT;}
		if(string.equals("--")){return DECREMENT;}
		if(string.equals("+=")){return PLUSEQUALS;}
		if(string.equals("-=")){return MINUSEQUALS;}
		if(string.equals("*=")){return MULTIPLYEQUALS;}
		if(string.equals("/=")){return DIVIDEEQUALS;}
		if(string.equals("%=")){return MODULUSEQUALS;}
		if(string.equals("=")){return ASSIGNMENT;}
		if(string.equals("-")){return MINUS;}
		if(string.equals("+")){return PLUS;}
		if(string.equals("*")){return MULTIPLY;}
		if(string.equals("/")){return DIVIDE;}
		if(string.equals("%")){return MODULUS;}
		if(string.equals(".")){return PERIOD;}
		if(string.equals(":")){return COLON;}
		if(string.equals("#")){return POUNDSIGN;}
		return UNKNOWN;
	}
}
