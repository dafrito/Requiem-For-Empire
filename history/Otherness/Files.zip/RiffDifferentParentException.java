public class RiffDifferentParentException extends LocationException{
	private RiffDataPoint m_firstLocation;
	private RiffDataPoint m_secondLocation;
	public RiffDifferentParentException(RiffDataPoint first, RiffDataPoint second){
		m_firstLocation = first;
		m_secondLocation = second;
	}
	public String getMessage(){
		String string = new String();
		string += "During a compare operation, these two locations were trying to be compared, but their parents are not identical.\n";
		string += "First location: \n" + m_firstLocation;
		string += "\nSecond location: \n" + m_secondLocation;
		return string;
	}
}
