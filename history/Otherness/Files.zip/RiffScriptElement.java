public class RiffScriptElement extends RiffScriptItem{
	public RiffScriptElement(RiffScriptLine line, int oLO){
		super(line,oLO);
	}
}
