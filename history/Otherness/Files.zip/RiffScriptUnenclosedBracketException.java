public class RiffScriptUnenclosedBracketException extends RiffParserException{
	private RiffScriptLine m_line;
	private int m_position;
	public RiffScriptUnenclosedBracketException(RiffScriptLine line, int loc){
		super(line.getFilename(), line.getLineNumber());
		m_line=line;
		m_position=line.getOffset()+loc;
	}
	public String getMessage(){
		String string="Unenclosed bracket\n\t" + m_line.getOriginalString();
		string += "\n\t";
		for(int i=1;i<m_position;i++){
			string += " ";
		}
		string += "^";
		return string;
	}
}
