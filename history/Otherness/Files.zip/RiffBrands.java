import java.util.*;

public class RiffBrands{
	private static Map m_brands = new HashMap(); // BrandName, Brand
	public static void addBrand(Brand brand){
		RiffBrands.m_brands.put(brand.getName(), brand);
	}
	public static Brand getBrand(String name){
		return (Brand)RiffBrands.m_brands.get(name);
	}
}
