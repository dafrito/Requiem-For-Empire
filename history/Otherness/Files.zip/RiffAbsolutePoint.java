public abstract class RiffAbsolutePoint extends RiffDataPoint implements Comparable{
	public RiffAbsolutePoint(){}
	public RiffAbsolutePoint(String name, String formalName, String adj){
		this(name,formalName,adj, null);
	}
	public RiffAbsolutePoint(String name, String formalName, String adj, RiffDataPoint point){
		super(name, formalName, adj, point);
	}
	public RiffAbsolutePoint(RiffDataPoint point){
		super(point);
	}
	public void duplicate(RiffAbsolutePoint point){
		setX(point.getX());
		setY(point.getY());
		setZ(point.getZ());
		setName(point.getName());
	}
	public void translate(double x, double y, double z){
		setX(getX()+x);
		setY(getY()+y);
		setZ(getZ()+z);
	}
	public void setPosition(double x, double y, double z){
		setX(x);
		setY(y);
		setZ(z);
	}
	public abstract double getX();
	public abstract double getY();
	public abstract double getZ();
	public abstract void setX(double x);
	public abstract void setY(double y);
	public abstract void setZ(double z);
	public abstract int compareTo(Object o);
	public void iterate(int iterationTime){}
	public boolean equals(Object o){
		RiffAbsolutePoint testPoint = (RiffAbsolutePoint)o;
		return(getY()==((RiffAbsolutePoint)o).getY()&&getX()==((RiffAbsolutePoint)o).getX());
	}
	public RiffAbsolutePoint getAbsolutePosition(){return this;}
}
