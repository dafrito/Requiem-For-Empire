import java.util.*;

public class NestedScript extends RiffScriptGroup{
	public NestedScript(List list){super(list);}
	public static NestedScript createElement(Object prereqs){return new NestedScript((List)prereqs);}
	public String getName(){return "NestedScript";}
	public String toString(){return "Nested Script Group: " + RiffToolbox.displayList(m_elements);}
}
