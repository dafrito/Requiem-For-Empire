import java.util.*;

public class LogMessage{
	private String m_string;
	private String m_creator;
	private Date m_dateCreated;
	public LogMessage(String string){
		m_creator = "Anonymous";
		m_string = string;
		m_dateCreated = new Date(System.currentTimeMillis());
	}
	public LogMessage(Object creator, String string){
		m_creator = creator.toString();
		m_string = string;
		m_dateCreated = new Date(System.currentTimeMillis());
	}
	public LogMessage(String creatorName, String string){
		m_creator = creatorName;
		m_string = string;
		m_dateCreated = new Date(System.currentTimeMillis());
	}
	public String toString(){
		String string = new String();
		string += "\nLog Message Creator: " + m_creator;
		string += "\nDate Created: " + m_dateCreated;
		string += "\nMessage: " + m_string;
		return string;
	}
}
