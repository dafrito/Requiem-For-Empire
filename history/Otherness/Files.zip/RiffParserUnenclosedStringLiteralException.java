public class RiffParserUnenclosedStringLiteralException extends RiffParserException{
	private RiffScriptLine m_line;
	private int m_position;
	public RiffParserUnenclosedStringLiteralException(RiffScriptLine line, int loc){
		super(line.getFilename(), line.getLineNumber());
		m_line=line;
		m_position=loc;
	}
	public String getMessage(){
		String string ="Unenclosed string literal\n\t" + m_line.getOriginalString();
		string += "\n\t";
		for(int i=0;i<m_position;i++){
			string += " ";
		}
		string += "^";
		return string;
	}
}
