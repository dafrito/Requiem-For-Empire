public class CollectResourceAction extends Action{
	private static String m_actionName = new String("Collect Resource");
	public String toString(){return m_actionName;}
	public static void execute(Order superOrder) throws FailedActionException{
		CollectResourceOrder order = (CollectResourceOrder)superOrder;
		double resource = order.getResourcePoint().getSlice(order.getIterationTime());
		Lot lot = order.getResourcePoint().getLot(order.getPopulation(), resource * order.getPopulation().getProficiency(m_actionName, order.getResourcePoint().getBrand().getCommodity()));
	}
}
