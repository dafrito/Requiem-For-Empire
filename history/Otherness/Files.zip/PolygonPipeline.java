import java.util.*;
import javax.swing.*;

public class PolygonPipeline extends Thread{
	private DiscreteRegionBSPNode m_outputTree;
	private DiscreteRegion m_region;
	private String m_infoString;
	private JPanel m_panel;
	private boolean m_isComplete;
	public PolygonPipeline(JPanel panel, DiscreteRegionBSPNode tree, int num, DiscreteRegion region){
		super("Polygon Pipeline " + num);
		m_region=region;
		m_outputTree=tree;
		m_panel=panel;
		m_isComplete=false;
		m_infoString=new String();
	}
	public boolean isComplete(){return m_isComplete;}
	public synchronized DiscreteRegion getRegion(){return m_region;}
	public synchronized String getInfoString(){return m_infoString;}
	public synchronized void setInfoString(String string){m_infoString=string;m_panel.repaint();}
	public void run(){
		setInfoString("Converting polygon to convex polygons...");
		if(m_region==null){
			setInfoString("Region is null.");
			m_isComplete=true;
			return;
		}
		List polygonList = RiffPolygonToolbox.convertPolyToConvex(m_region);
		if(polygonList==null){
			setInfoString("Returned list was null; polygon was invalid.");
			m_isComplete=true;
			return;
		}
		setInfoString("Joining polygons...");
		polygonList = RiffPolygonToolbox.joinPolygons(polygonList);
		setInfoString("Performing final optimizations...");
		polygonList = RiffPolygonToolbox.optimizePolygons(polygonList);
		setInfoString("Adding polygons to BSP tree...");
		m_outputTree.addRegions(polygonList);
		//setInfoString("Process complete. Recreating tree...");
		//m_outputTree.recreateTree();
		setInfoString("Process complete.");
		m_isComplete=true;
	}
}
