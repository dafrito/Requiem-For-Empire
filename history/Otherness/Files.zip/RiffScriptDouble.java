public class RiffScriptDouble extends RiffScriptNumber{
	private double m_value;
	public RiffScriptDouble(double value, RiffScriptLine line, int oLO){
		super(line,oLO);
		m_value=value;
	}
	public double getValue(){return m_value;}
	public double getDoubleValue(){return getValue();}
	public float getFloatValue(){return (float)getValue();}
	public long getLongValue(){return (long)getValue();}
	public int getIntegerValue(){return (int)getValue();}
	public short getShortValue(){return (short)getValue();}
	public String toString(){return "RiffScriptDouble: " + m_value;}
}
