import java.awt.event.*;
import javax.swing.*; // For JPanel, etc.
import java.io.*;
import java.util.*;
import java.awt.*;

public class RiffInterfacePageElement extends JPanel{
	private RiffInterfaceRootElement m_rootElement;
	public RiffInterfacePageElement(){
		setBackground(Color.BLACK);
		m_rootElement=new RiffInterfaceRootElement(this);
		m_rootElement.addElement(new RiffInterfaceTextElement(m_rootElement,"Requiem for Empire?"));
		m_rootElement.addElement(new RiffInterfaceTextElement(m_rootElement,"Requiem for Empire?"));
		m_rootElement.addElement(new RiffInterfaceTextElement(m_rootElement,"Requiem for Empire?"));
		m_rootElement.addElement(new RiffInterfaceTextElement(m_rootElement,"Requiem for Empire?"));
	}
	public void paintComponent(Graphics g){
		clear(g);
		Graphics2D g2d=(Graphics2D)g;
		g2d.setColor(Color.WHITE);
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		m_rootElement.paint(g2d);
		g2d.dispose();
	}
	protected void clear(Graphics g){super.paintComponent(g);}
}
