import java.util.*;

// The commodity map node is intended for traversal for best-fit commodities, and also for
// locating optimum commodities quickly. To accomplish the first, the commodityMapNode acts
// as a tree, adding leafs as necessary for different Commodity categories. Each node can also
// have lots categorized by brand. To quickly find the best good, the root node acts as an index,
// holding references to all added nodes in the tree.

// To add a lot, the function first checks if the commodity-node exists. If it does, then the process
// is simple - adding the lot to the list of brands inside that node. If it isn't found, the node must
// confirm the existence of each of its parents until it finds an existing node. This process recurses as
// far back as necessary. Each node is "asserted" meaning that it will yield a valid result by first checking
// the root to see if it exists, and if it does, returning it, or calling the assert function of its parent, and
// then returning that.

public class CommodityMapNode{
	private Map m_parents; // Commodity, CommodityMapNode
	private Map m_children; // Commodity, CommodityMapNode
	private Commodity m_commodity;
	private Map m_brands; // Brand, LinkedList of Lots
	private CommodityMapNode m_root;
	private Map m_index; // Commodity, CommodityMapNode
	public CommodityMapNode(Commodity commodity){
		m_commodity = commodity;
		m_brands = new HashMap();
		m_children = new HashMap();
		m_parents = new HashMap();
	}
	public CommodityMapNode(){
		m_children = new HashMap();
		m_index = new HashMap();
	}
	public Map getIndex(){return m_index;}
	public List getAllLots(){
		List list = new LinkedList();
		Iterator iter = m_brands.values().iterator();
		while(iter.hasNext()){
			list.addAll((Collection)iter.next());
		}
		iter = m_children.values().iterator();
		while(iter.hasNext()){
			list.addAll(((CommodityMapNode)iter.next()).getAllLots());
		}
		return list;
	}
	
	public Map getParents(){return m_parents;}
	public Map getChildren(){return m_children;}
	public CommodityMapNode getRoot(){
		if(m_parents==null || m_parents.size() == 0){return this;}
		return ((CommodityMapNode)m_parents.get((Commodity)m_parents.keySet().iterator().next())).getRoot();
	}
	public CommodityMapNode getNode(Commodity comm){
		if(m_index != null){return (CommodityMapNode)m_index.get(comm);}
		return getRoot().getNode(comm);
	}
	public CommodityMapNode assertNode(Commodity comm){
		if(getRoot().getNode(comm)==null){
			if(!comm.hasParents()){return getRoot().addNode(comm);
			}else{
				for(int i = 0;i<comm.getParentCommodities().size();i++){
					assertNode((Commodity)comm.getParentCommodities().get(i)).addNode(comm);
				}
			}
		}
		return getRoot().getNode(comm);
	}
	public CommodityMapNode addNode(Commodity comm){
		CommodityMapNode node = getNode(comm);
		if(node == null){
			node = new CommodityMapNode(comm);
			getRoot().getIndex().put(comm, node);
		}
		node.addParent(this);
		m_children.put(comm, node);
		return node;
	}
	public void removeAsset(Asset asset){
		((List)getBrands(((Lot)asset).getCommodity()).get(((Lot)asset).getBrand())).remove(asset);
	}
	public void addParent(CommodityMapNode node){
		m_parents.put(node.getCommodity(), node);
	}
	public Map getBrands(Commodity commodity){
		if(getRoot().getNode(commodity)==this){return m_brands;}
		return getRoot().getNode(commodity).getBrands(commodity);
	}
	public Commodity getCommodity(){return m_commodity;}
	public List getLotList(Brand brand){
		if(getRoot().getNode(brand.getCommodity())==this){
			return (List)m_brands.get(brand);
		}
		return getRoot().getNode(brand.getCommodity()).getLotList(brand);
	}
	public List getLotList(Commodity commodity){
		if(getRoot().getNode(commodity)==this){
			List list = new LinkedList();
			List entryList = new LinkedList(m_brands.values());
			for(int i=0;i<entryList.size();i++){
				list.addAll((List)entryList.get(i));
			}
			Iterator iter=m_children.values().iterator();
			while(iter.hasNext()){
				list.addAll(((CommodityMapNode)iter.next()).getLotList(commodity));
			}
			return list;
		}
		if(getRoot().getNode(commodity) != null){
			return getRoot().getNode(commodity).getLotList(commodity);
		}else
		{
			return null;
		}
	}
	public void addLot(Lot lot) throws CommodityMapException{
		if(assertNode(lot.getCommodity()) != this){
			assertNode(lot.getCommodity()).addLot(lot);
			return;
		}
		if(m_brands == null){throw new CommodityMapAddLotToRootException(this, lot);}
		if(m_brands.get(lot.getBrand()) == null){
			m_brands.put(lot.getBrand(), new LinkedList());
		}
		((List)m_brands.get(lot.getBrand())).add(lot);
	}
	public String toString(){
		String string = new String();
		string += "CommodityMapNode: ";
		if(getRoot() == this){string += "Root node";
		}else{string += m_commodity.getName();}
		if(m_parents == null){
			/*if(m_index.size()==1){string += "\nThis node contains 1 child in its index:";
			}else if(m_index.size()==0){string += "\nThis node contains no children in its index.";
			}else{string += "\nThis node contains " + m_index.size() + " child nodes in its index:";}
			Iterator iter = m_index.values().iterator();
				while(iter.hasNext()){
				string += "\n" + (CommodityMapNode)iter.next();
			}
			if(m_index.size() != 0){string += "\nEnd of index.";}*/
		}else{
			if(m_brands.size()==1){string += "\nThis node contains 1 brand:";
			}else if(m_brands.size()==0){string += "\nThis node contains no brands.";
			}else{string += "\nThis node contains " + m_brands.size() + " brands:";}
			Iterator iter = m_brands.entrySet().iterator();
			while(iter.hasNext()){
				Map.Entry entry = (Map.Entry)iter.next();
				string += "\nBrand: " + (Brand)entry.getKey();
				if(((List)entry.getValue()).size()==1){string += "\nThis brand-list contains 1 lot:";
				}else if(((List)entry.getValue()).size()==0){string += "\nThis brand-list contains no lots.";
				}else{string += "\nThis brand-list contains " + ((List)entry.getValue()).size() + " lots:";}
				for(int i=0;i<((List)entry.getValue()).size();i++){
					string += "\n" + (Lot)((List)entry.getValue()).get(i);
				}
			}
		}
		if(m_children.size()==1){string += "\nThis node contains 1 child:";
		}else if(m_children.size()==0){string += "\nThis node contains no children.";return string;
		}else{string += "\nThis node contains " + m_children.size() + " child nodes:";}
		Iterator iter = m_children.values().iterator();
		while(iter.hasNext()){
			string += "\n" + (CommodityMapNode)iter.next();
		}
		string += "\nEnd of children.";
		return string;
	}
}
