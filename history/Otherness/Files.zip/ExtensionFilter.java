import java.util.*;
import java.io.*;
import javax.swing.filechooser.*;

public class ExtensionFilter extends javax.swing.filechooser.FileFilter{
	private Set m_extensions=new HashSet();
	private String m_description;
	public ExtensionFilter(String desc){
		m_description=desc;
	}
	public void addExtension(String extension){
		m_extensions.add(extension.toLowerCase());
	}
	public boolean accept(File file){
		if(file.isDirectory()){return true;}
		String string=RiffToolbox.getExtension(file);
		Iterator iter=m_extensions.iterator();
		while(iter.hasNext()){
			String testExt = (String)iter.next();
			if(string.equals(testExt)){return true;}
		}
		return false;
	}
	public void setDescription(String desc){
		m_description=desc;
	}
	public String getDescription(){return m_description;}
}
