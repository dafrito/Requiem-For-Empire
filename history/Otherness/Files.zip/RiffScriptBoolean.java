public class RiffScriptBoolean extends RiffScriptElement{
	private boolean m_value;
	public RiffScriptBoolean(boolean value, RiffScriptLine line, int oLO){
		super(line,oLO);
		m_value=value;
	}
	public boolean getValue(){return m_value;}
	public String toString(){return "RiffScriptBoolean: " + m_value;}
}
