public class RiffScriptShort extends RiffScriptNumber{
	private short m_value;
	public RiffScriptShort(short value, RiffScriptLine line, int oLO){
		super(line,oLO);
		m_value=value;
	}
	public short getValue(){return m_value;}
	public double getDoubleValue(){return (double)getValue();}
	public float getFloatValue(){return (float)getValue();}
	public long getLongValue(){return (long)getValue();}
	public int getIntegerValue(){return (int)getValue();}
	public short getShortValue(){return getValue();}
	public String toString(){return "RiffScriptShort: " + m_value;}
}
