import java.awt.*;
import java.awt.font.TextLayout;
import java.awt.geom.Rectangle2D;

public class RiffInterfaceTextElement extends RiffInterfaceElement{
	private String m_string;
	public RiffInterfaceTextElement(RiffInterfaceElement parent, String string){
		super(parent);
		m_string=string;
	}
	public RiffInterfaceTextElement(RiffInterfaceElement parent, String classStyle, String string){super(parent,null,RiffScriptParser.getStylesheet(classStyle));m_string=string;}
	public RiffInterfaceTextElement(RiffInterfaceElement parent, String uniqueStyle, String classStyle, String string){
		super(parent,RiffScriptParser.getStylesheet(uniqueStyle),RiffScriptParser.getStylesheet(classStyle));
		m_string=string;
	}
	public Rectangle getDrawingBounds(){
		Graphics2D g2d=getRoot().getGraphics();
		TextLayout layout=new TextLayout(m_string, getCurrentFont(), g2d.getFontRenderContext());
		Rectangle2D boundingRect=layout.getBounds();
		return new Rectangle((int)boundingRect.getWidth(), (int)boundingRect.getHeight());
	}
	public Rectangle getDrawingBoundsUsingWidth(int width){
		// IMPLEMENT THIS!
		Graphics2D g2d=getRoot().getGraphics();
		TextLayout layout=new TextLayout(m_string, getCurrentFont(), g2d.getFontRenderContext());
		Rectangle2D boundingRect=layout.getBounds();
		return new Rectangle((int)boundingRect.getWidth(), (int)boundingRect.getHeight());
	}
	public void paint(Graphics2D g2d){
		g2d.drawString(m_string, getXAnchor(), getYAnchor());
	}
}
