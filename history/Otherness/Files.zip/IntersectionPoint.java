public class IntersectionPoint{
	private RiffAbsolutePoint m_point;
	private boolean m_isTangent;
	public IntersectionPoint(RiffAbsolutePoint point, boolean isTangent){
		m_isTangent=isTangent;
		m_point=point;
	}
	public RiffAbsolutePoint getPoint(){return m_point;}
	public boolean isTangent(){return m_isTangent;}
	public String toString(){
		String string = new String();
		string += "IntersectionPoint: ";
		string += "\nPoint: " + m_point;
		string += "\nIs tangent: " + m_isTangent;
		return string;
	}
}
