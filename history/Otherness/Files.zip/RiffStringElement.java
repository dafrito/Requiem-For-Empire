public class RiffStringElement extends RiffScriptElement{
	private String m_string;
	public RiffStringElement(String string, RiffScriptLine line, int originalLineOffset){
		super(line, originalLineOffset);
		m_string=string;
	}
	public String toString(){return "RiffStringElement: \"" +m_string+'"';}
}
