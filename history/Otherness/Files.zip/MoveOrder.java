import java.util.*;
import java.util.Collections;

public class MoveOrder extends Order{
	private TradeLink m_tradeLink;
	private Transport m_transport;
	private double m_offsetDistance, m_offsetPercentage;
	public MoveOrder(Transport transport, Terrestrial terrestrial, RiffAbsolutePoint source, RiffAbsolutePoint dest){
		m_transport=transport;
		m_tradeLink=RiffPolygonToolbox.getRoute(transport, terrestrial, source, dest);
	}
	public Transport getTransport(){return m_transport;}
	public double getOffsetDistance(){return m_offsetDistance;}
	public void addOffsetDistance(double distance){setOffsetDistance(m_offsetDistance + distance);}
	public void setOffsetDistance(double distance){
		assert RiffToolbox.printDebug("MoveOrder/setOffsetDistance", "(setOffsetDistance)\nSetting offset distance to this: " + distance);
		double percentage = distance / m_tradeLink.getCurrentRouteDistance();
		m_offsetDistance = distance;
		m_offsetPercentage = percentage;
		assert RiffToolbox.printDebug("MoveOrder/setOffsetDistance", "(/setOffsetDistance)");
	}
	public TradeLink getTradeLink(){return m_tradeLink;}
	public void execute(double iterationTime) throws OrderException{
		super.execute(iterationTime);
		assert RiffToolbox.printDebug("MoveOrder/execute", "(execute)\nMove order executing with provided iteration-time: " + iterationTime);
		while(m_tradeLink.hasNext()&&getIterationTime()>0){
			MoveAction.execute(this);
		}
	}
	public String toString(){
		String string = new String("Move Order:");
		return string;
	}
}
