public class RiffInterfaceStylesheetFontStyleElement extends RiffInterfaceStylesheetElement{
	private int m_style;
	public RiffInterfaceStylesheetFontStyleElement(int style){
		m_style=style;
	}
	public int getStyle(){return m_style;}
}
