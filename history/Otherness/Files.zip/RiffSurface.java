import java.util.*;

public abstract class RiffSurface extends RiffDataPoint{
	protected Terrain m_terrain;
	public RiffSurface(){}
	public RiffSurface(Terrain terrain){
		m_terrain=terrain;
	}
	public abstract double getLeftExtreme();
	public abstract double getRightExtreme();
	public abstract double getTopExtreme();
	public abstract double getBottomExtreme();
	public void setTerrain(Terrain terrain){m_terrain=terrain;}
	public Terrain getTerrain(){return m_terrain;}
	public abstract List getPolygons(double precision);
}
