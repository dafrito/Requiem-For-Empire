import java.util.*;

public class DiscreteRegionBSPNode{
	private RiffAbsolutePoint m_pointA, m_pointB;
	private DiscreteRegionBSPNode m_leftNode, m_rightNode;
	private Set m_leftNeighbors;
	private Set m_rightNeighbors;
	private Set m_tempList;
	private DiscreteRegionBSPNode m_root;
	public DiscreteRegionBSPNode(DiscreteRegionBSPNode root, Object a, Object b){
		this(root, (RiffAbsolutePoint)a, (RiffAbsolutePoint)b);
	}
	public DiscreteRegionBSPNode(DiscreteRegion region){
		this(null, region.getPoints().get(0), region.getPoints().get(1));
		m_root=this;
		addRegion(region);
	}
	public DiscreteRegionBSPNode(DiscreteRegionBSPNode root, RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/constructor", "(BSPNodeConstructor)\nCreating new BSP-node. Lines: " + pointA + ", " + pointB);
		m_root=root;
		m_pointA=pointA;
		m_pointB=pointB;
		m_leftNeighbors = new HashSet();
		m_rightNeighbors = new HashSet();
		m_tempList = new HashSet();
	}
	public synchronized Set getAllAssets(){
		Set assets=new HashSet();
		Iterator iter=m_leftNeighbors.iterator();
		while(iter.hasNext()){
			DiscreteRegion region=(DiscreteRegion)iter.next();
			assets.addAll(region.getAssetMap().getAllAssets());
		}
		assets.addAll(m_rightNeighbors);
		iter=m_rightNeighbors.iterator();
		while(iter.hasNext()){
			DiscreteRegion region=(DiscreteRegion)iter.next();
			assets.addAll(region.getAssetMap().getAllAssets());
		}
		if(m_leftNode!=null){assets.addAll(m_leftNode.getAllAssets());}
		if(m_rightNode!=null){assets.addAll(m_rightNode.getAllAssets());}
		return assets;
	}
	public synchronized void addToTempList(Collection regions){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addToTempList", "(addToTempList/)\nAdding regions to temp-list.");
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addToTempList/data", "Regions to add: " + RiffToolbox.displayList(regions));
		m_tempList.addAll(regions);
	}
	public synchronized Set getTempList(){return m_tempList;}
	public synchronized void addToTempList(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addToTempList", "(addToTempList/)Adding region to temp-list.");
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addToTempList/data", "Region to add: " + region);
		m_tempList.add(region);
	}
	public synchronized void clearTempList(){m_tempList.clear();}
	public synchronized void removeFromTempList(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/removeFromTempList", "(removeFromTempList/)\nRemoving region from temp-list.");
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/removeFromTempList/data", "Region to remove: " + region);
		m_tempList.remove(region);
	}
	public synchronized Set getPotentialList(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "(getPotentialList)\nTesting this region against this line: " + m_pointA + ", " + m_pointB);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/data", "Region: " + region);
		RiffPolygonToolbox.optimizePolygon(region);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Getting point-side list to determine region proximity.");
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()&&!array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Region is straddling this line, returning full list.");
			Set polys = new HashSet();
			polys.addAll(getPolyList());
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "(/getPotentialList)");
			return polys;
		}else if(!array[0].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Region is less than this line.");
			if(m_leftNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Deferring to left node and returning those results.");
				Set returnList = m_leftNode.getPotentialList(region);
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "(/getPotentialList)");
				return returnList;
			}
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Left node is null, so returning left neighbors.");
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/data", "Left neighbors: " + RiffToolbox.displayList(m_leftNeighbors));
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "(/getPotentialList)");
			return m_leftNeighbors;
		}else if(!array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Region is greater than this line.");
			if(m_rightNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Deferring to right node and returning those results.");
				Set returnList = m_rightNode.getPotentialList(region);
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "(/getPotentialList)");
				return returnList;
			}
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "Right node is null, so returning right neighbors.");
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/data", "Right neighbors: " + RiffToolbox.displayList(m_rightNeighbors));
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "(/getPotentialList)");
			return m_rightNeighbors;
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList", "*** ERROR: Returning null.\n(/getPotentialList)");
		return null;
	}
	public synchronized DiscreteRegion findPolygon(RiffDataPoint point){
		return findPolygon(point.getAbsolutePosition());
	}
	public synchronized DiscreteRegion findPolygon(RiffAbsolutePoint point){
		Set set = findPolygons(point);
		if(set.size()<1){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygon/error", "More than one polygon found for supposedly single-polygon query.");
		}else if(set.size()==0){return null;}
		return (DiscreteRegion)set.iterator().next();
	}
	public synchronized Set findPolygons(RiffAbsolutePoint point){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "(findPolygons)Point given: " + point);
		double value = RiffPolygonToolbox.testPointAgainstLine(point, m_pointA, m_pointB);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons/data", "Value from pointside: " + value);
		
		Set polyList = new HashSet();
		if(RiffToolbox.isGreaterThan(value, 0.0d)){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Value is greater than zero.");
			if(m_rightNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Deferring to right node.");
				Set set = m_rightNode.findPolygons(point);
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "(/findPolygons)");
				return set;
			}else{
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Adding all right neighbors.");
				polyList.addAll(m_rightNeighbors);
			}
		}
		if(RiffToolbox.isLessThan(value, 0.0d)){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Value is less than zero.");
			if(m_leftNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Deferring to left node.");
				Set set =  m_leftNode.findPolygons(point);
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "(/findPolygons)");
				return set;
			}else{
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Adding all left neighbors.");
				polyList.addAll(m_leftNeighbors);
			}
		}
		if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, value, 0.0d)){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "Value is equal to zero, adding both lists.");
			polyList.addAll(m_leftNeighbors);
			polyList.addAll(m_rightNeighbors);
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/findPolygons", "(/findPolygons)");
		return polyList;
	}
	public synchronized Set getPolyList(){
		Set list = new HashSet();
		list.addAll(m_leftNeighbors);
		list.addAll(m_rightNeighbors);
		if(m_leftNode!=null){list.addAll(m_leftNode.getPolyList());}
		if(m_rightNode!=null){list.addAll(m_rightNode.getPolyList());}
		return list;
	}
	public synchronized void addRegions(Collection regions){
		Iterator iter=regions.iterator();
		while(iter.hasNext()){
			addRegion((DiscreteRegion)iter);
		}
	}
	public synchronized void addRegion(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "(addRegion)\nAdding region to BSP tree. This node's line value: " + m_pointA + ", " + m_pointB);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/data", "Region: " + region);
		RiffPolygonToolbox.optimizePolygon(region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()&&!array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region is straddling this node's line, splitting.");
			m_root.removeRegion(region);
			DiscreteRegion splitPolygon = RiffPolygonToolbox.splitPolygonUsingEdge(region, m_pointA, m_pointB,true);
			if(splitPolygon==null){
				RiffToolbox.toggleDebugSpew();
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/error", "*** ERROR: Unexpected null region from split.");
				for(int i=0;i<array.length;i++){
					assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/error", "Pointside result " + i + ": " + array[i]);
				}
			}
			m_root.addRegion(region);
			m_root.addRegion(splitPolygon);
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "(/addRegion)");
			return;
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Checking region proximity...");
		if(!array[0].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region is less than this node's line.");
			if(!array[2].isEmpty()){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region has points that are colinear with this node's line, so adding it to left neighbors.");
				m_leftNeighbors.add(region);
				region.addRegionNeighbors(m_rightNeighbors);
			}
			if(m_leftNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Left node isn't null, so deferring to that node and returning.\n(/addRegion)");
				m_leftNode.addRegion(region);
				return;
			}
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Adding region line-by-line to the BSP tree...");
			List pointList = region.getPoints();
			for(int i=0;i<pointList.size();i++){
				addLine(region, pointList.get(i),pointList.get((i+1)%pointList.size()));
			}
		}else if(!array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region is greater than this node's line.");
			if(!array[2].isEmpty()){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region has points that are colinear with this node's line, so adding it to right neighbors.");
				m_rightNeighbors.add(region);
				region.addRegionNeighbors(m_leftNeighbors);
			}
			if(m_rightNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Right node isn't null, so deferring to that node and returning.\n(/addRegion)");
				m_rightNode.addRegion(region);
				return;
			}
			List pointList = region.getPoints();
			for(int i=0;i<pointList.size();i++){
				addLine(region, pointList.get(i),pointList.get((i+1)%pointList.size()));
			}
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "BSP addition process is complete, returning.\n(/addRegion)");
	}
	public synchronized void removeRegion(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/removeRegion", "(removeRegion)\nRemoving region. This node's line value: " + m_pointA + ", " + m_pointB);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/removeRegion/data", "Region to remove: " + region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region is less than this node's line.");
			if(!array[2].isEmpty()){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Removing region from left neighbors.");
				m_leftNeighbors.remove(region);
				Iterator polys = m_rightNeighbors.iterator();
				while(polys.hasNext()){
					((DiscreteRegion)polys.next()).removeRegionNeighbor(region);
				}
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Neighbors list: " + m_leftNeighbors);
			}
			if(m_leftNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Deferring to left node and returning.");
				m_leftNode.removeRegion(region);
			}
		}
		if(!array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Region is greater than this node's line.");
			if(!array[2].isEmpty()){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Removing region from right neighbors.");
				m_rightNeighbors.remove(region);
				Iterator polys = m_leftNeighbors.iterator();
				while(polys.hasNext()){
					((DiscreteRegion)polys.next()).removeRegionNeighbor(region);
				}
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Neighbors list: " + m_rightNeighbors);
			}
			if(m_rightNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "Deferring to right node and returning.");
				m_rightNode.removeRegion(region);
			}
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion", "(/removeRegion)");
	}
	public synchronized void addLine(DiscreteRegion owner, RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "(addLine)\nAdding line. This node's line value: " + m_pointA + ", " + m_pointB);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Line to add: " + pointA + ", " + pointB);
		List[] array = RiffPolygonToolbox.getPointSideList(m_pointA, m_pointB, pointA, pointB);
		if(RiffPolygonToolbox.testForColinearity(pointA, pointB, m_pointA, m_pointB)){return;}
		if(array[0].isEmpty()&&array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Polygon has no non-colinear points with this line, returning.\n(/addLine)");
			return;
		}
		if(!array[0].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Line is less than this node's line.");
			if(m_leftNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Deferring to left node and returning.\n(/addLine)");
				m_leftNode.addLine(owner, pointA, pointB);
				return;
			}
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Creating new left node.");
			m_leftNode = new DiscreteRegionBSPNode(m_root, pointA, pointB);
			m_leftNode.categorizeRegion(owner);
		}else if(!array[1].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Line is greater than this node's line.");
			if(m_rightNode!=null){
				assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Deferring to right node and returning.\n(/addLine)");
				m_rightNode.addLine(owner, pointA, pointB);
				return;
			}
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Creating new right node.");
			m_rightNode = new DiscreteRegionBSPNode(m_root, pointA, pointB);
			m_rightNode.categorizeRegion(owner);
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "(/addLine)");
	}
	public void addLine(DiscreteRegion owner, Object pointA, Object pointB){addLine(owner, (RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB);}
	public synchronized void categorizeRegion(DiscreteRegion region){
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/categorizeRegion", "(categorizeRegion)\nCategorizing region. This node's line value: " + m_pointA + ", " + m_pointB);
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/categorizeRegion/data", "Region to categorize: " + region);
		RiffPolygonToolbox.optimizePolygon(region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()&&!array[2].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Region has points which are less than or equal to this node's line, adding to left neighbors.");
			m_leftNeighbors.add(region);
			region.addRegionNeighbors(m_rightNeighbors);
		}
		if(!array[1].isEmpty()&&!array[2].isEmpty()){
			assert RiffToolbox.printDebug("DiscreteRegionBSPNode/addLine", "Region has points which are greater than or equal to this node's line, adding to right neighbors.");
			m_rightNeighbors.add(region);
			region.addRegionNeighbors(m_leftNeighbors);
		}
		assert RiffToolbox.printDebug("DiscreteRegionBSPNode/categorizeRegion", "(/categorizeRegion)");
	}
	public String toString(){
		String string = new String("DiscreteRegionBSPNode: ");
		string += "\nPointA: " + m_pointA;
		string += "\nPointB: " + m_pointB;
		string += "\nLeft neighbors: " + RiffToolbox.displayList(m_leftNeighbors);
		string += "\nRight neighbors: " + RiffToolbox.displayList(m_rightNeighbors);
		string += "\nLeft node: " + m_leftNode;
		string += "\nRight node: " + m_rightNode;
		return string;
	}
}
