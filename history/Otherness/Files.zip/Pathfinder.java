import java.util.*;
import java.awt.Color;
public class Pathfinder{
	private DiscreteRegion m_start, m_destination;
	private List m_usedList;
	private List m_pathList;
	private List m_route;
	private RiffAbsolutePoint m_sourcePoint, m_destinationPoint;
	public Pathfinder(DiscreteRegionBSPNode root, RiffAbsolutePoint startPoint, RiffAbsolutePoint endPoint){
		this(root.findPolygon(startPoint), startPoint, root.findPolygon(endPoint), endPoint);
	}
	public Pathfinder(DiscreteRegion start, RiffAbsolutePoint startPoint, DiscreteRegion destination, RiffAbsolutePoint endPoint){
		m_start=start;
		m_destination=destination;
		m_sourcePoint=startPoint;
		m_destinationPoint=endPoint;
		m_usedList=new LinkedList();
		m_pathList=new LinkedList();
		m_route=new LinkedList();
	}
	public List getRoute(){
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "(getRoute)");
		DiscreteRegion chosenRegion = m_start;
		RiffAbsolutePoint currentPoint = m_sourcePoint;
		if(m_start.equals(m_destination)){
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Start polygon and destination polygon are equal, returning empty list.");
			return m_route;
		}
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "Destination: " + m_destination);
		m_route.add(m_sourcePoint);
		int ticker=0;
		while(!chosenRegion.equals(m_destination)){
			if(ticker>100){
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Emergency failure.");
				return null;
			}
			ticker++;
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "\n\nPathfinder is iterating...(Iteration " + ticker + ")");
			assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Current region: " + chosenRegion);
			Iterator neighborIter = chosenRegion.getNeighbors().iterator();
			if(chosenRegion.getNeighbors().size()==0){
				return null;
			}
			Map neighborsMap = new HashMap();
			while(neighborIter.hasNext()){
				DiscreteRegion neighbor = (DiscreteRegion)neighborIter.next();
				if(m_usedList.contains(neighbor)){continue;}
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Placing neighbor in neighbor-map: "+neighbor);
				RiffAbsolutePoint[]line=RiffPolygonToolbox.getAdjacentEdge(chosenRegion, neighbor);
				RiffAbsolutePoint point=RiffPolygonToolbox.getMinimumPointBetweenLine(line[0], line[1], currentPoint);
				if(!point.equals(currentPoint)){neighborsMap.put(neighbor, point);}
			}
			if(neighborsMap.isEmpty()){
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Stepping back.");
				if(chosenRegion==m_start){return null;}
				m_route.remove(m_route.size()-1);
				m_usedList.add(chosenRegion);
				chosenRegion=(DiscreteRegion)m_pathList.get(m_pathList.size()-1);
				m_pathList.remove(m_pathList.size()-1);
				continue;
			}
			Map valueMap = new HashMap();
			neighborIter = neighborsMap.entrySet().iterator();
			while(neighborIter.hasNext()){
				Map.Entry entry = (Map.Entry)neighborIter.next();
				DiscreteRegion neighbor = (DiscreteRegion)entry.getKey();
				valueMap.put(neighbor, getValue(currentPoint, (RiffAbsolutePoint)entry.getValue(),neighbor));
			}
			Iterator mapIter = valueMap.entrySet().iterator();
			double minimumValue=Double.POSITIVE_INFINITY;
			DiscreteRegion optimumRegion=null;
			while(mapIter.hasNext()){
				Map.Entry entry = (Map.Entry)mapIter.next();
				DiscreteRegion contestingRegion =(DiscreteRegion)entry.getKey();
				double thisValue=((Double)entry.getValue()).doubleValue();
				assert RiffToolbox.printDebug("Pathfinder/getRoute", contestingRegion.getName() + "'s Value: " + thisValue);
				if(RiffToolbox.isLessThan(thisValue,minimumValue)){
					minimumValue=((Double)entry.getValue()).doubleValue();
					optimumRegion=(DiscreteRegion)entry.getKey();
				}else if(RiffToolbox.areEqual(RiffToolbox.EUCLIDEAN, thisValue,minimumValue)){
					assert RiffToolbox.printDebug("Pathfinder/getRoute", "Contestng region: " + contestingRegion.getName() + ", " + optimumRegion.getName());
					if(RiffToolbox.isLessThan(getValue(currentPoint, contestingRegion.getBoundingRectMidPoint(),contestingRegion).doubleValue(),getValue(currentPoint, optimumRegion.getBoundingRectMidPoint(),optimumRegion).doubleValue())){
						optimumRegion=contestingRegion;
						minimumValue=((Double)entry.getValue()).doubleValue();
					}
				}
			}
			if(optimumRegion==null){
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Stepping back.");
				if(chosenRegion==m_start){return null;}
				m_route.remove(m_route.size()-1);
				m_usedList.add(chosenRegion);
				chosenRegion=(DiscreteRegion)m_pathList.get(m_pathList.size()-1);
				m_pathList.remove(m_pathList.size()-1);
				continue;
			}
			currentPoint=(RiffAbsolutePoint)neighborsMap.get(optimumRegion);
			m_route.add(currentPoint);
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Adding to used list: " + chosenRegion);
			m_usedList.add(chosenRegion);
			m_pathList.add(chosenRegion);
			chosenRegion=optimumRegion;
		}
		m_route.add(m_destinationPoint);
		m_pathList.add(m_destination);
		Iterator iter=m_pathList.iterator();
		while(iter.hasNext()){
			((DiscreteRegion)iter.next()).setColor(Color.RED);
		}
		System.out.println(RiffToolbox.displayList(m_pathList));
		return m_route;
	}
	private Double getValue(RiffAbsolutePoint source, RiffAbsolutePoint location, DiscreteRegion region){
		double sourceToLocation = RiffToolbox.getDistance(source, location);
		double locToDestination = RiffToolbox.getDistance(location, m_destinationPoint);
		assert RiffToolbox.printDebug("Pathfinder/getValue", "SourceToLoc: " +sourceToLocation);
		assert RiffToolbox.printDebug("Pathfinder/getValue", "LocToDest: " +locToDestination);
		if(((Terrain)region.getAssetMap().getAsset(Asset.TERRAIN)).getBrushDensity()>0.0d){
			locToDestination=Double.POSITIVE_INFINITY;
		}
		return new Double(sourceToLocation+locToDestination);
	}
	/*public List getRoute(){
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "(getRoute)");
		DiscreteRegion chosenRegion = m_start;
		List route = new LinkedList();
		if(m_start.equals(m_destination)){
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Start polygon and destination polygon are equal, returning empty list.");
			return route;
		}
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "Destination: " + m_destination);
		route.add(chosenRegion.getInteriorPoint());
		int ticker=0;
		while(!chosenRegion.equals(m_destination)){
			if(ticker>20){
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Pathfinding iterator exceeded loop tolerance.");
				route.clear();break;
			}
			ticker++;
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "\nPathfinder is iterating...(Iteration " + ticker + ")");
			assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Current region: " + chosenRegion);
			Map slopeList = new HashMap();
			Set neighbors = chosenRegion.getNeighbors();
			if(neighbors.size()==0){
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "No path available.");
				break;
			}else if(neighbors.contains(m_destination)){
				m_pathList.add(chosenRegion);
				chosenRegion=m_destination;
				m_pathList.add(chosenRegion);
				break;
			}
			assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Neighbors list: " + RiffToolbox.displayList(neighbors));
			Iterator iter=neighbors.iterator();
			double optimumTheta = Math.tan((m_destination.getInteriorPoint().getY()-chosenRegion.getInteriorPoint().getY())/(m_destination.getInteriorPoint().getX()-chosenRegion.getInteriorPoint().getX()));
			assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Optimum theta: " + optimumTheta + ", now generating delta-from-theta list.");
			assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Interior point of destination: " + m_destination.getInteriorPoint());
			while(iter.hasNext()){
				DiscreteRegion region = (DiscreteRegion)iter.next();
				assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Current region: " + region);
				assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Interior point of current: " + region.getInteriorPoint());
				double regionsTheta = Math.tan((m_destination.getInteriorPoint().getY()-region.getInteriorPoint().getY())/(m_destination.getInteriorPoint().getX()-region.getInteriorPoint().getX()));
				assert RiffToolbox.printDebug("Pathfinder/getRoute/data", "Current region's theta: " + regionsTheta);
				slopeList.put(new Double(Math.abs(optimumTheta-regionsTheta)), region);
			}
			double minValue = Double.POSITIVE_INFINITY;
			Double minimumTheta=null;
			iter=slopeList.entrySet().iterator();
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Finding minimum-delta polygon..." + slopeList.size());
			while(iter.hasNext()){
				Map.Entry entry = (Map.Entry)iter.next();
				Double keyValue = ((Double)entry.getKey());
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Region: " + slopeList.get(keyValue));
				if(minValue >= keyValue.doubleValue()){
					if(m_usedList.contains(entry.getValue())){
						assert RiffToolbox.printDebug("Pathfinder/getRoute", "Used-list contains neighbor, continuing...");
						continue;
					}
					minimumTheta = keyValue;
					minValue = keyValue.doubleValue();
					assert RiffToolbox.printDebug("Pathfinder/getRoute", "New minimum: " + minValue);
				}
			}
			if(minimumTheta==null){
				if(m_pathList.size()<=1){
					assert RiffToolbox.printDebug("Pathfinder/getRoute", "All paths attempted, but none successful, returning.");
					route.clear();break;
				}
				chosenRegion=(DiscreteRegion)m_pathList.remove(m_pathList.size()-2);
				m_pathList.remove(m_pathList.size()-1);
				assert RiffToolbox.printDebug("Pathfinder/getRoute", "Stepping back...");
				continue;
			}
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Potential polygon found, setting chosen-region to it, and adding this region to our used list...");
			m_usedList.add(chosenRegion);
			m_pathList.add(chosenRegion);
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Polygon list: " +RiffToolbox.displayList(m_pathList));
			chosenRegion=(DiscreteRegion)slopeList.get(minimumTheta);
		}
		if(chosenRegion.equals(m_destination)){
			assert RiffToolbox.printDebug("Pathfinder/getRoute", "Route found.");
		}
		Iterator routeIter = m_pathList.iterator();
		while(routeIter.hasNext()){
			route.add(((DiscreteRegion)routeIter.next()).getInteriorPoint());
		}
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "Final route: " + route);
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "Final polygon list: " +RiffToolbox.displayList(m_pathList));
		assert RiffToolbox.printDebug("Pathfinder/getRoute", "(/getRoute)");
		return route;
	}*/
}
