import java.util.*;

// In webRFE we assume that all planets are perfectly circular, and the coordinate system on such a planet
// goes from 0 to the circumference value.

public class Planet extends Location{
	private double m_radius;
	private List m_terrainPoints;
	private List m_assetPoints;
	private List m_populations;
	private Map m_tradeLinks;
	public Planet(String name, String adjective, Location absoluteParent, RiffDataPoint offsetPoint, double radius) throws OverwriteException{
		super(Location.PLANET, name, adjective, absoluteParent, offsetPoint, true);
		m_terrainPoints = new Vector();
		m_assetPoints = new Vector();
		m_radius = radius;
	}
	public double getRadius(){return m_radius;}
	public boolean addTerrainPoint(TerrainPoint riffPoint){m_terrainPoints.add(riffPoint);return true;}
	public boolean addAssetPoint(AssetPoint assetPoint){m_assetPoints.add(assetPoint);return true;}
	public void addTradeLink(TradeLink link){
		if(m_tradeLinks.get(link.getSource()) != null){
			((Map)m_tradeLinks.get(link.getSource())).put(link.getDestination(),link);
			return;
		}
		m_tradeLinks.put(link.getSource(), new HashMap());
		addTradeLink(link);
	}
	public List getPopulations(){return m_populations;}
	public boolean iterate(int iterationTime){
		for(int i=0;i<m_assetPoints.size();i++){
			if(((Asset)m_assetPoints.get(i)).iterate(iterationTime)==false){return false;}
		}
		return true;
	}
	public String toString(){
		String string = new String();
		string += super.toString();
		return string;
	}
}
