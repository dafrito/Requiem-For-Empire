public abstract class RiffAbsolutePoint extends RiffDataPoint implements Comparable{
	public RiffAbsolutePoint(){}
	public RiffAbsolutePoint(RiffDataPoint point, Location referenceLocation){
		super(point,referenceLocation);
	}
	public abstract int compareTo(Object o);
	public boolean iterate(int iterationTime){return true;}
	public abstract void setLocation(RiffDataPoint point);
	public abstract boolean equals(Object o);
	public RiffAbsolutePoint getAbsolutePosition(){return this;}
}
