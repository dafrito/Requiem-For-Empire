public class TradeLink{
	private RiffDataPoint m_source;
	private RiffDataPoint m_destination;
	private double m_angle;
	private double m_distance;
	public TradeLink(RiffDataPoint source, RiffDataPoint dest){
		m_source = source;
		m_destination = dest;
	}
	public RiffDataPoint getSource(){return m_source;}
	public RiffDataPoint getDestination(){return m_destination;}
	public double getAngle(){return m_angle;}
	public double getDistance(){return RiffToolbox.getSphericalDistance(m_source, m_destination);}
}
