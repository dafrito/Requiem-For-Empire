public abstract class Action implements Comparable{
	public abstract boolean execute(Order superOrder, int iterationTime);
	public abstract String toString();
	public boolean equals(Object obj){
		return toString().equals(((Action)obj).toString());
	}
	public int compareTo(Object obj){
		return toString().compareTo(((Action)obj).toString());
	}
}
