public class RectangularArea extends RiffSurface{
	private double m_xLength;
	private double m_yLength;
	public RectangularArea(double lat, double longit, double xMag, double yMag){
		m_point = new RiffSpherePoint(lat, longit);
		m_xLength = xMag;
		m_yLength = yMag;
	}
	public double getLeftExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() - m_xLength;}
	public double getRightExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() + m_xLength;}
	public double getBottomExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() - m_yLength;}
	public double getTopExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() + m_yLength;}
	public double getOverlap(RiffDataPoint testPoint){
		RiffSpherePoint point = (RiffSpherePoint)testPoint.getAbsolutePosition();
		if(getLeftExtreme() >= point.getLatitudeDegrees()){return 0.0d;}
		if(getRightExtreme() <= point.getLatitudeDegrees()){return 0.0d;}
		if(getBottomExtreme() >= point.getLongitudeDegrees()){return 0.0d;} 
		if(getTopExtreme() <= point.getLongitudeDegrees()){return 0.0d;}
		return 1.0d;
	}
	public double getOverlap(RiffSurface surface){
		if(getLeftExtreme() >= surface.getRightExtreme()){return 0.0d;}
		if(getRightExtreme() <= surface.getLeftExtreme()){return 0.0d;}
		if(getBottomExtreme() >= surface.getTopExtreme()){return 0.0d;} 
		if(getTopExtreme() <= surface.getBottomExtreme()){return 0.0d;}
		return 1.0d;
	}
}
