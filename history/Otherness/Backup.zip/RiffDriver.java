import java.util.*;

public class RiffDriver{
	public String toString(){
		String string = new String();
		string += "RiffDriver";
		return string;
	}
	public RiffDriver() throws InvalidScenarioDateRangeException{
		GregorianCalendar startDate = new GregorianCalendar(2100, Calendar.MARCH, 1, 5, 25, 00);
		GregorianCalendar endDate = new GregorianCalendar(2200, Calendar.DECEMBER, 25, 12, 00, 00);
		try{
			Scenario scenario = new Scenario("Roman Campaign", new Planet("Earth", "Terran", null, null, 6372.795), ((365/4)*3600*24)/(3600*24), startDate, endDate);
			//scenario.getRootLocation().addAssetPoint(new HabitableStructure(
			Market market = new Market();
			Commodity widgetComm = new Commodity("Widgets");
			Commodity fuelComm = new Commodity("Combustible");
			Commodity foodComm = new Commodity("Food");
			Commodity widgetFluff = new Commodity("Widget Fluff");
			widgetComm.addParent(fuelComm);
			widgetComm.addParent(foodComm);
			
			Organization organization = new Organization(null, "Widget, Inc", "Widget", "Widgettian");
			
			widgetComm.addPrerequisite(widgetFluff, 25);
			market.addLot(new Lot(organization, new Brand("Generic Fluff", widgetFluff, .97, organization), 85, 10000000));
			market.addLot(new Lot(organization, new Brand("Northern Widgets", widgetComm, 1, organization), .85, 39));
			System.out.println(market);
			//	public AssetPoint(Asset asset, RiffDataPoint point, Planet planet){
			new MobileStructure(new AssetPoint((Planet)scenario.getRootElement(),
			
			scenario.iterate();
			
			LogManager.printMessages();
		}catch(OverwriteException ex){
			System.out.println(ex);
		}catch(CommodityMapException ex){
			System.out.println(ex);
		}
		
		/*Location galaxy = new Location(Location.GALAXY, "Foo", "Fooian", true, new Point3d(0.0d,0.0d,0.0d), true);
		GregorianCalendar startDate = new GregorianCalendar(2100, Calendar.MARCH, 1, 5, 25, 00);
		GregorianCalendar endDate = new GregorianCalendar(2200, Calendar.DECEMBER, 25, 12, 00, 00);
		Scenario scenario = new Scenario("RFE Test Scenario", galaxy, 60, startDate, endDate);
		scenario.getRootElement().addChild(new Location(Location.CLUSTER, "Nogrime", "Nogrimian", true, new Point3d(5.0d,5.0d,5.0d), true));
		Location system = new Location(Location.SYSTEM, "Noob", "Noobian", true, new Point3d(5.0d,5.0d,5.0d), false);
		scenario.getRootElement().getLastChild().addChild(system);
		system.addChild(new Planet("TestPlanet", "TestPlanet", new Point3d(350,0,0), 85));
		Enclave enclave = new Enclave("TestEnclave", (Planet)system.getLastChild());
		((Planet)system.getLastChild()).addEnclave(enclave);
		Organization organization = new Organization(null, "Widget, Inc", "Widget", "Widgettian");
		Commodity widget =  new Commodity("Widget");
		Commodity widgetFluff = new Commodity("Widget Fluff");
		widget.addPrerequisite(widgetFluff, new Integer(3));
		Brand brand = new Brand("Widgetty Widget",widget, 85, organization);
		enclave.addAsset(new Structure(organization, enclave, "Widget Factory North", "Widget", "Widgettian North"));
		((Structure)enclave.getLastAsset()).addInventory(new Lot(new Brand("Generic fluff", widgetFluff, 50, organization), 85, 10000000));
		((Structure)enclave.getLastAsset()).addAction(new ProductionAction(brand, 1));
		((Structure)enclave.getLastAsset()).addOrder(new Order(new ProductionAction(brand, 15000), 3));
		enclave.addPopulation(new Population(15000));
		enclave.getLastPopulation().addConsumptionLevel(brand, new Integer(1));
		System.out.println(scenario);
		scenario.iterate();
		scenario.iterate();
		scenario.iterate();
		System.out.println(scenario);*/
	}
	public static void main(String[]args){
		try{
			RiffDriver riffDriver = new RiffDriver();
		}catch(InvalidScenarioDateRangeException ex){
			System.out.println(ex);
		}
	}
};
