public class AssetPoint extends RiffDataPoint{
	protected Asset m_asset;
	public AssetPoint(Asset asset, RiffDataPoint point, Planet planet){
		super(point, planet);
		m_asset = asset;
		planet.addAssetPoint(this);
	}
	public void setAsset(Asset asset){m_asset = asset;}
	public Asset getAsset(){return m_asset;}
	public boolean iterate(int iterationTime){
		return m_asset.iterate(iterationTime);
	}
}
