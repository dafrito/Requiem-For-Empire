import java.util.*;

public class Commodity extends UniqueObject{
	private Map m_prerequisites;
	private String m_name;
	private List m_parents;
	public Commodity(){
		m_prerequisites = new HashMap();
		m_parents = new Vector();
	}
	public Commodity(String name){
		m_name = name;
		m_prerequisites = new HashMap();
		m_parents = new Vector();
	}
	public String getName(){return m_name;}
	public Map getPrerequisites(){return m_prerequisites;}
	public Commodity getPrerequisite(String preString){return (Commodity)m_prerequisites.get(preString);}
	public boolean hasParents(){if(m_parents == null || m_parents.size()==0){return false;}return true;}
	public List getParents(){return m_parents;}
	public void addParent(Commodity parent){m_parents.add(parent);}
	public boolean addPrerequisite(Commodity prereq, int quantity){
		m_prerequisites.put(prereq.getName(), new PrerequisiteLevel(prereq, quantity));
		return true;
	}
	public int hashCode(){return m_name.hashCode();}
	public String toString(){
		String string = new String();
		string += "Commodity: " + m_name + "\n";
		string += "Prerequisites: ";
		Iterator iter = m_prerequisites.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			string += "\n" + ((PrerequisiteLevel)entry.getValue());
		}
		return string;
	}
}
