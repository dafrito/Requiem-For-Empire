import javax.swing.*; // For JPanel, etc.
import java.awt.*;           // For Graphics, etc.
import java.awt.geom.*;      // For Ellipse2D, etc.
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.JOptionPane;

public class RiffGUI extends JPanel implements KeyListener{
	private java.util.List m_points = new LinkedList();
	RiffDataPoint redPoint, greenPoint, bluePoint;
	private final int m_width = 150;
	public RiffGUI(){
		/*JOptionPane.showMessageDialog(this, "The following questions will determine the characteristics of the orbit. The orbit will be calculated fifty times, each time adding the velocity, in radians, to the yaw, pitch, or the roll.");
		double initialYaw = Double.parseDouble(JOptionPane.showInputDialog("Insert initial yaw in radians (Entering 2 yields PI/2), and zero yields zero.", "0"));
		double initialPitch = Double.parseDouble(JOptionPane.showInputDialog("Insert initial pitch in radians (Entering 2 yields PI/2), and zero yields zero.", "0"));
		double initialRoll = Double.parseDouble(JOptionPane.showInputDialog("Insert initial roll in radians (Entering 2 yields PI/2), and zero yields zero.", "0"));
		double yawVelocity =  Double.parseDouble(JOptionPane.showInputDialog("Insert yaw velocity in a divided form of PI. (Entering 2 yields PI/2)", "24"));
		double pitchVelocity =  Double.parseDouble(JOptionPane.showInputDialog("Insert pitch velocity in a divided form of PI. (Entering 2 yields PI/2)", "0"));
		double rollVelocity =  Double.parseDouble(JOptionPane.showInputDialog("Insert roll velocity in a divided form of PI. (Entering 2 yields PI/2)", "0"));
		if(initialYaw != 0.0d){initialYaw = Math.PI / initialYaw;}
		if(initialPitch != 0.0d){initialPitch = Math.PI / initialPitch;}
		if(initialRoll != 0.0d){initialRoll = Math.PI / initialRoll;}
		if(yawVelocity != 0.0d){yawVelocity = Math.PI / yawVelocity;}
		if(pitchVelocity != 0.0d){pitchVelocity = Math.PI / pitchVelocity;}
		if(rollVelocity != 0.0d){rollVelocity = Math.PI / rollVelocity;}
		orbitLoc = new Location(Location.PLANET, "moon", "moon", null, new OrbitingPoint(testLoc, 50.0d, initialYaw,initialPitch, initialRoll,yawVelocity,pitchVelocity,rollVelocity), true);*/
		try{
			Location testLoc1 = new Location(Location.PLANET, "testPlanet1", "fooPlanet", null, new Point3d(m_width*.5,m_width*.5,0.0d), true);
			Location testLoc2 = new Location(Location.PLANET, "testPlanet2", "fooPlanet", null, new Point3d(m_width*.5,m_width*.5, 0.0d), true);
			Location testLoc3 = new Location(Location.PLANET, "testPlanet3", "fooPlanet", null, new Point3d(m_width/4,m_width/4, 0.0d), true);
			Region region = new Region();
			redPoint = new LinearGradient(testLoc1, m_width/2, 10);
			region.addPoint(redPoint);
			greenPoint = new LinearGradient(testLoc2, m_width/2, 1);
			region.addPoint(greenPoint);
			//bluePoint = new RiffDataPoint(new LinearGradient(testLoc3, m_width));
			//region.addPoint(bluePoint);
			
			long time = System.currentTimeMillis();
			System.out.println("Calculating gradient points...");
			
			for(int i =0;i< m_width;i++){
				for(int j=0;j<m_width;j++){
					m_points.add(region.getOverlap(new Point3d(i,j,0)));
				}
			}
			time = System.currentTimeMillis() - time;
			System.out.println("Calculations took " + time + " milliseconds.");
			addKeyListener(this);
		}catch(ZeroRadiusException ex){
			System.out.println(ex);
		}catch(OverwriteException ex){
			System.out.println(ex);
		}
	}
	public void paintComponent(Graphics g){
		clear(g);
		Graphics2D g2d = (Graphics2D)g;
		long time = System.currentTimeMillis();
		System.out.println("Now drawing gradient map...");
		for(int i =0;i< m_width;i++){
			for(int j=0;j<m_width;j++){
				if(m_points.get((i*m_width) + j) == null){System.out.println("It's null");}
				Map map = (Map)m_points.get((i*m_width) + j);
				float red, green, blue;
				red = green = blue = 0;
				if(((Double)map.get(redPoint)) != null){red = ((Double)map.get(redPoint)).floatValue();}
				if(((Double)map.get(greenPoint)) != null){green = ((Double)map.get(greenPoint)).floatValue();}
				if(((Double)map.get(bluePoint)) != null){blue = ((Double)map.get(bluePoint)).floatValue();}
				g2d.setPaint(new Color(red, green, blue));
				g2d.draw(new Line2D.Double(i,j,i,j));
			}
		}
		time = System.currentTimeMillis() - time;
		System.out.println("Draw operation took " + time + " milliseconds.");
	}
	
	public void keyTyped(KeyEvent keyEvent){}
	public void keyReleased(KeyEvent keyEvent){}
	public void keyPressed(KeyEvent keyEvent){}
	protected void clear(Graphics g){super.paintComponent(g);}
	
  	public static void main(String[] args) {
	 	JFrame frame = new JFrame("RiffGUI");
	 	frame.setSize(200, 200);
		frame.setContentPane(new RiffGUI());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
}
