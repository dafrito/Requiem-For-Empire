import java.util.*;
public class Scenario{
	private Location m_rootLocation;
	private String m_scenarioName;
	private Calendar m_gameCalendar;
	private int m_timeScale;
	private int m_numIterations;
	private Calendar m_endDate;
	private Date m_lastIteration;
	private Scenario(){} // explicitly forbidden.
	public Scenario(String scenarioName, Location rootLocation, int timeScale, Calendar startDate, Calendar endDate) throws InvalidScenarioDateRangeException{
		if(startDate.getTime().compareTo(endDate.getTime()) > 0){
			throw(new InvalidScenarioDateRangeException(this));
		}
		m_rootLocation = rootLocation;
		m_timeScale = timeScale;
		m_gameCalendar = startDate;
		m_gameCalendar.setLenient(true);
		m_endDate = endDate;
		m_scenarioName = scenarioName;
		m_lastIteration = new Date(System.currentTimeMillis());
		LogManager.writeDebug(m_scenarioName, "A scenario with the following parameters was created:\n\n" + this);
	}
	public Location getRootLocation(){return m_rootLocation;}
	public boolean setEndDate(Calendar endDate){m_endDate = endDate;return true;}
	public Date getEndDate(){return m_endDate.getTime();}
	public Date getDate(){return m_gameCalendar.getTime();}
	public String getScenarioName(){return m_scenarioName;}
	public boolean iterate(int elapsedTime){
		m_gameCalendar.add(GregorianCalendar.SECOND, m_timeScale);
		try{if(m_rootLocation.iterate(elapsedTime)==false){return false;}}
		catch(Exception ex){System.out.println(ex);return false;}
		m_numIterations++;
		m_lastIteration = new Date(System.currentTimeMillis());
		return true;
	}
	public boolean iterate(){
		return iterate((int)((System.currentTimeMillis() - m_lastIteration.getTime()) / 1000));
	}
	
	public String toString(){
		String string = new String();
		string += "Scenario: " + m_scenarioName + "\n";
		string += "Current date: " + m_gameCalendar.getTime() + "\n";
		string += "End date: " + m_endDate.getTime() + "\n";
		switch(m_timeScale){
		case 60:string += "Timescale: 1 second : 1 game-minute (1:" + m_timeScale + ")\n"; break;
		case 3600:string += "Timescale: 1 second : 1 game-hour (1:" + m_timeScale + ")\n";break;
		case 3600*24:string += "Timescale: 1 second: 1 game-day (1:" + m_timeScale + ")\n";break;
		case (((365/4)*3600*24)/(3600*24)): string += "Timescale: 1 day: 1 season (1:" + m_timeScale + ")\n";break;
		default:string += "Timescale: 1:" + m_timeScale + "\n";
		}
		string += "Number of iterations: " + m_numIterations + "\n";
		string += "Root element data follows: \n";
		string += m_rootLocation;
		return string;
	}
}