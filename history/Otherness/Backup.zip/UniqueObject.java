public class UniqueObject{
	private static long m_uniqueNumCounter=0;
	protected final long m_uniqueNum;
	public UniqueObject(){
		m_uniqueNum = m_uniqueNumCounter++;
	}
	public long getUniqueNum(){return m_uniqueNum;}
}
