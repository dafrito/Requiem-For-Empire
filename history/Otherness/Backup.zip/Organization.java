import java.util.*;

public class Organization extends Asset implements Comparable{
	protected String m_formalName;
	protected String m_shortName;
	protected String m_adjective;
	protected List m_orders;
	protected Map m_actions;
	protected final int SHORTNAMEMAXLENGTH = 30;	
	protected List m_assets;
	public Organization(){
		super();
		m_formalName = new String();
		m_adjective = new String();
		m_shortName = new String();
		m_assets = new LinkedList();
		m_orders = new LinkedList();
		m_actions = new HashMap();
	}
	public Organization(Organization parent, String formal, String adj, String shortName){
		super(parent);
		m_formalName = formal;
		m_adjective = adj;
		m_shortName = shortName;
		m_assets = new LinkedList();
		m_orders = new LinkedList();
		m_actions = new HashMap();
	}
	public String getName(){return getShortName();}
	public String getFormalName(){return m_formalName;}
	public String getShortName(){return m_shortName;}
	public String getAdjective(){return m_adjective;}
	public List getAssets(){return m_assets;}
	public void addLots(List lots){m_assets.addAll(lots);}

	public List getOrders(){return m_orders;}
	public Map getActions(){return m_actions;}
	public void addAction(Action action, double proficiency){m_actions.put(action, new Double(proficiency));}
	public void setActionProficiency(Action action, double proficiency){addAction(action,proficiency);}
	public void setActionObject(Action action, Object object, double proficiency){
		Map map = (Map)m_actions.get(action);
		map.put(object, new Double(proficiency));
	}
	public void addOrder(Order order){
		m_orders.add(order);
	}
	public void removeOrder(Order order){
		if(m_orders.contains(order)){
			m_orders.remove(order);
		}
	}
	
	public boolean addAsset(Asset asset){m_assets.add(asset); return true;}
	public boolean setFormalName(String formalName){m_formalName = formalName;return true;}
	public boolean setAdjective(String adj){m_adjective = adj; return true;}
	public boolean setShortName(String name){
		if(name.length() > SHORTNAMEMAXLENGTH && m_formalName == null){
			return false;
		}
		m_shortName = name;
		return true;
	}
	public boolean equals(Object org){
		return (m_formalName == ((Organization)org).getFormalName());
	}
	public int compareTo(Object org){
		return m_formalName.compareTo(((Organization)org).getFormalName());
	}
	public double getProficiency(Action action){
		return ((Double)m_actions.get(action)).doubleValue();
	}
	public double getProficiency(Action action, Object object){
		return ((Double)((Map)m_actions.get(action)).get(object)).doubleValue();
	}
	public boolean iterate(int iterationTime){
		for(int i=0;i<m_orders.size();i++){
			if(((Order)m_orders.get(i)).execute(iterationTime) == false){
				break;
			}
			m_orders.remove(i);
			i--;
		}
		return true;
	}
	public String toString(){
		String string = new String();

		string += "Organization: " + m_formalName + "\n";
		string += "Short: " + m_shortName + "\n";
		string += "Adjective: " + m_adjective + "\n";
		string += "\n" + RiffToolbox.printUnderline("Actions:", "-");
		/*for(int i = 0;i<m_actions.size();i++){
			string += ((Action)m_actions.get(i)) + "\n";
		}*/
		string += "\n" + RiffToolbox.printUnderline("Orders:", "-");
		for(int i = 0;i<m_orders.size();i++){
			string += ((Order)m_orders.get(i)) + "\n";
		}
		
		string += "\n" + RiffToolbox.printUnderline("Assets:", "-");
		for(int i = 0;i<m_assets.size();i++){
			string += ((Asset)m_assets.get(i)) + "\n";
		}
		return string;
	}
}
