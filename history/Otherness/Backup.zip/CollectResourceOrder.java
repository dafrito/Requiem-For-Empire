public class CollectResourceOrder extends Order{
	private ResourcePoint m_point;
	private double m_quantity;
	private double m_minimumQuality;
	private static CollectResourceAction m_action;
	public CollectResourceOrder(Organization org, ResourcePoint point, double quantity){
		super(org);
		m_point = point;
		m_quantity = quantity;
	}
	public ResourcePoint getResourcePoint(){return m_point;}
	public double getQuantity(){return m_quantity;}
	public boolean execute(int iterationTime){
		if(CollectResourceOrder.m_action == null){
			CollectResourceAction action = new CollectResourceAction();
			RiffActions.addAction(action);
			CollectResourceOrder.m_action = action;
		}
		CollectResourceOrder.m_action.execute(this, iterationTime);
		return true;
	}
	public String toString(){
		String string = new String();
		string += "Order: CollectResourceOrder";
		string += "\nThe organization listed below is to collect a minimum of " + m_quantity + " units of minimum quality, " + m_minimumQuality + ", of the good listed below.";
		string += "\nOrganization: " + m_organization;
		string += "\nResourcePoint: " + m_point;
		return string;
	}
}
