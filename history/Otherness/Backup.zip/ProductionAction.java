import java.util.*;

public class ProductionAction extends Action{
	public static String m_actionName = new String("Production Action");
	public String toString(){return m_actionName;}
	public boolean execute(Order superOrder, int iterationTime){
		ProductionOrder order = (ProductionOrder)superOrder;
		Iterator iter = order.getCommodity().getPrerequisites().entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			if(order.getStructure().assertInventoryLevel((Commodity)entry.getKey(), order.getQuantity() * ((Double)entry.getValue()).doubleValue())==false){
				return false;
			}
		}
		iter = order.getCommodity().getPrerequisites().entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			if(order.getStructure().expendInventoryLevel((Commodity)entry.getKey(),order.getQuantity() * ((Double)entry.getValue()).doubleValue())==false){
				return false;
			}
		}
		order.addLot(new Lot(order.getOrganization(), order.getBrand(), 1, order.getQuantity()));
		return true;
	}
}
