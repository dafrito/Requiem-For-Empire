public class LocationTypeDisplay{
	public static final int LOCATIONTYPE_DONOTDISPLAY = 0;
	public static final int LOCATIONTYPE_DISPLAYASPREFIX = 1;
	public static final int LOCATIONTYPE_DISPLAYASSUFFIX = 2;
	public static final int LOCATIONTYPE_DISPLAYPREFIXNAME = 3;
}
