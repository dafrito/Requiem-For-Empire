import java.util.*;

public class ProductionOrder extends Order{
	private double m_quantity;
	private Brand m_product;
	private static ProductionAction m_action;
	private List m_lots;
	public ProductionOrder(Organization org, Brand product, double quantity){
		super(org);
		m_product = product;
		m_quantity = quantity;
		m_lots = new LinkedList();
	}
	public Structure getStructure(){return (Structure)m_organization;}
	public Brand getBrand(){return m_product;}
	public Commodity getCommodity(){return m_product.getCommodity();}
	public double getQuantity(){return m_quantity;}
	public boolean execute(int iterationTime){
		if(ProductionOrder.m_action == null){
			ProductionAction action = new ProductionAction();
			RiffActions.addAction(action);
			ProductionOrder.m_action = action;
		}
		ProductionOrder.m_action.execute(this, iterationTime);
		if(m_quantity <= 0){return true;}
		m_organization.addLots(m_lots);
		return false;
	}	
	public void addLot(Lot lot){m_lots.add(lot); m_quantity -= lot.getQuantity(); }
	public String toString(){
		String string = new String();
		string += "Order: ProductionOrder";
		string += "\nThe organization listed below is to produce " + getQuantity() + " units of the product listed below.";
		string += "\nOrganization: " + m_organization;
		string += "\nProduct: " + m_product;
		return string;
	}
}
