import java.util.*;

public class Structure extends Organization{
	protected AssetPoint m_location;
	private Personality m_manager;
	protected List m_inventory;
	public Structure(){
		super();
		m_inventory = new LinkedList();
	}
	public Structure(Organization owner, AssetPoint assetPoint, String formal, String adj, String shortName){	
		super(owner, formal, adj, shortName);
		m_inventory = new LinkedList();
		m_location = assetPoint;
		m_location.setAsset(this);
	}	
	public List getInventory(){return m_inventory;}
	public boolean addInventory(Lot lot){m_inventory.add(lot); return true;}
	public boolean assertInventoryLevel(Commodity comm, double quantity){
		double level = 0;
		for(int i=0;i<m_inventory.size();i++){
			Lot lot = (Lot)m_inventory.get(i);
			if(comm == lot.getBrand().getCommodity()){
				level += lot.getQuantity();
				if(level >= quantity){return true;}
			}
		}
		return false;
	}
	public AssetPoint getAssetPoint(){return m_location;}
	public AssetPoint getLocation(){ return getAssetPoint();}
	public void setLocation(RiffDataPoint point){
		m_location.getAbsolutePosition().setLocation(point);
	}
	public boolean expendInventoryLevel(Commodity comm, double quantity){
		double level = quantity;
		for(int i=0;i<m_inventory.size();i++){
			Lot lot = (Lot)m_inventory.get(i);
			if(comm == lot.getBrand().getCommodity()){
				if(lot.getQuantity() >= level){
					lot.setQuantity(lot.getQuantity() - level);
					return true;
				}
				level -= lot.getQuantity();
				lot.setQuantity(0);
			}
		}
		return false;
	}
	public Personality getManager(){return m_manager;}
	public boolean setManager(Personality manager){m_manager = manager;return true;}
	public String toString(){
		String string = new String();
		string += "Manager: " + m_manager + "\n";
		string += "Inventory:\n";
		for(int i =0;i<m_inventory.size();i++){
			string += ((Lot)m_inventory.get(i)).toString();
		}
		return super.toString() + string;
	}
}
