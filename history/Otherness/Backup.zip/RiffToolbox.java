import java.lang.Math;
import java.util.Random;

public class RiffToolbox{
	public static String printUnderline(String baseString, String printChar){
		String string = new String(baseString + "\n");
		for(int i = baseString.length(); i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	public static String printLine(String symbol, int times){
		String string = new String();
		for(int i=0;i<times;i++){
			string += symbol;
		}
		string += "\n";
		return string;
	}
	private static Random m_random;
	public static Random getRandom(){
		if(RiffToolbox.m_random == null){
			RiffToolbox.m_random = new Random();
		}
		return RiffToolbox.m_random;
	}
	public static String printBorder(String baseString, String printChar){
		String string = new String();
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n " + baseString + "\n";
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	public static int compareDoubles(double firstDouble, double secondDouble){
		if(firstDouble < secondDouble){
			return -1;
		}if(firstDouble > secondDouble){
			return 1;
		}return 0;
	}
	public static double convertDegreesToRadians(double degrees){return degrees * Math.PI/180;}
	public static double getSphericalDistance(RiffDataPoint firstPoint, RiffDataPoint secondPoint){
		return RiffToolbox.getSphericalDistance((Planet)firstPoint.getReferenceLocation(), (RiffSpherePoint)firstPoint.getAbsolutePosition(), (RiffSpherePoint)secondPoint.getAbsolutePosition());
	}
	public static double getSphericalDistance(Planet planet, RiffSpherePoint firstPoint, RiffSpherePoint secondPoint){
		double firstLat = Math.toRadians(firstPoint.getLatitudeDegrees());
		double secondLat = Math.toRadians(secondPoint.getLatitudeDegrees());
		double firstLong = Math.toRadians(firstPoint.getLongitudeDegrees());
		double secondLong = Math.toRadians(secondPoint.getLongitudeDegrees());
		double temp = Math.pow(Math.sin((secondLat - firstLat)/2),2) + Math.cos(firstLat) * Math.cos(secondLat) * Math.pow(Math.sin((secondLong - firstLong)/2),2);
		return planet.getRadius() * 2 * Math.asin(Math.min(1, Math.sqrt(temp)));
	}
	public static double getDistance(RiffDataPoint firstPoint, RiffDataPoint secondPoint){
		return getDistance(firstPoint.getAbsolutePosition(), secondPoint.getAbsolutePosition());
	}
	public static double getDistance(Point3d firstTestPoint, Point3d secondTestPoint){
		//( (x-a)2 + (y - b)2 + (z - c)2 )1/2
		Point3d firstPoint = (Point3d)firstTestPoint;
		Point3d secondPoint = (Point3d)secondTestPoint;
		double testDouble = Math.sqrt(Math.pow((secondPoint.getX() - firstPoint.getX()), 2) + Math.pow((secondPoint.getY() - firstPoint.getY()), 2) + Math.pow((secondPoint.getZ() - firstPoint.getZ()), 2));
		return testDouble;
	}
}
