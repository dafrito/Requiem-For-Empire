public class MobileUnit extends Asset{
	private AssetMap m_assets;
	private TradeLink m_tradeLink;
	private double m_offsetPercentage;
	public MobileUnit(Organization owner){
		super(owner);
		m_assets = new AssetMap();
	}
	public TradeLink getTradeLink(){return m_tradeLink;}
	public RiffSpherePoint getAbsolutePosition(){
		if(m_tradeLink==null){return null;}
		double latDelta = ((RiffSpherePoint)m_tradeLink.getDestination().getAbsolutePosition()).getLatitudeDegrees() - ((RiffSpherePoint)m_tradeLink.getSource().getAbsolutePosition()).getLatitudeDegrees();
		double longDelta = ((RiffSpherePoint)m_tradeLink.getDestination().getAbsolutePosition()).getLongitudeDegrees() - ((RiffSpherePoint)m_tradeLink.getSource().getAbsolutePosition()).getLongitudeDegrees();
		double latitude = ((RiffSpherePoint)m_tradeLink.getSource().getAbsolutePosition()).getLatitudeDegrees();
		latitude += m_offsetPercentage * latDelta;
		//latitude -= ((RiffSpherePoint)m_tradeLink.getSource().getAbsolutePosition()).getLatitudeDegrees();
		double longitude = ((RiffSpherePoint)m_tradeLink.getSource().getAbsolutePosition()).getLongitudeDegrees();
		longitude += m_offsetPercentage * longDelta;
		//longitude -= ((RiffSpherePoint)m_tradeLink.getSource().getAbsolutePosition()).getLongitudeDegrees();
		return new RiffSpherePoint(m_tradeLink.getPlanet(), longitude, latitude);
	}
	public double getOffsetPercentage(){return m_offsetPercentage;}
	public void setTradeLink(TradeLink link){m_tradeLink=link;}
	public void setOffsetPercentage(double offset){m_offsetPercentage=offset;}
	public void expendFuel(double time){
		
	}
	public double getVelocity(double time){
		return 8;
	}
	public void iterate(int iterationTime){return;}
	public String toString(){
		String string = new String();
		string += "Mobile Unit: ";
		if(m_tradeLink != null){
			string += "\nCurrently in transit on: " + m_tradeLink;
			string += "\nOffset in %: " + m_offsetPercentage * 100;
		}
		//string += "\nAsset Map: " + m_assets;
		return string;
	}
}
