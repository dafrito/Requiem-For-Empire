import java.util.*;

public class PhysicalRegion extends Region{
	public String toString(){return new String();}
}
