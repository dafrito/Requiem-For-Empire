public class AssetPoint extends RiffDataPoint{
	private AssetMap m_assetMap;
	public AssetPoint(RiffDataPoint point, Planet planet){
		super(point, planet);
		m_assetMap = new AssetMap();
		planet.addAssetPoint(this);
	}
	public AssetMap getAssetMap(){return m_assetMap;}
	public void addAsset(Asset asset) throws CommodityMapException {m_assetMap.addAsset(asset);}
	public void iterate(int iterationTime){}
	public String toString(){
		String string = new String();
		string += "AssetPoint:";
		string += "\nAbsolute position: " + getAbsolutePosition(); 
		//string += "\n" + super.toString();
		return string;
	}
}
