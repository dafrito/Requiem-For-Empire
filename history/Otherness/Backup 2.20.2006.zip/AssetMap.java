import java.util.*;

public class AssetMap{
	private CommodityMapNode m_node;
	private Map m_assetMap; // String, List
	public AssetMap(){
		m_node = new CommodityMapNode();
		m_assetMap = new HashMap();
	}
	public void addAll(List list)throws CommodityMapException{
		for(int i=0;i<list.size();i++){
			addAsset((Asset)list.get(i));
		}
	}
	public CommodityMapNode getCommodityMap(){return m_node;}
	public void addAsset(Asset asset) throws CommodityMapException{
		if(asset.getAssetType() == "Lot"){
			m_node.addLot((Lot)asset);
		}
		if(m_assetMap.get(asset.getAssetType()) == null){
			m_assetMap.put(asset.getAssetType(), new LinkedList());
		}
		((List)m_assetMap.get(asset.getAssetType())).add(asset);
	}
	public String toString(){
		String string = new String();
		string += "AssetMap: ";
		if(m_assetMap.size() == 0){
			string += "\nThis assetMap contains no non-commodity assets.";
		}else if(m_assetMap.size()==1){
			string += "\nThis assetMap contains one non-commodity asset:";
		}else{
			string += "\nThis assetMap contains " + m_assetMap.size() + " non-commodity assets:";
		}
		Iterator iter = m_assetMap.values().iterator();
		while(iter.hasNext()){
			List list = (List)iter.next();
			for(int i=0;i<list.size();i++){
				string += "\n" + list.get(i);
			}
		}
		string += "\nCommodity Assets: " + m_node;
		return string;
	}
}
