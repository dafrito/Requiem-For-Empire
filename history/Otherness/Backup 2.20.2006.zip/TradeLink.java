import java.lang.Math;

public class TradeLink implements Comparable{
	private RiffDataPoint m_source;
	private RiffDataPoint m_destination;
	private Double m_angle;
	private double m_distance;
	private Planet m_planet;
	public TradeLink(RiffDataPoint source, RiffDataPoint dest, Planet planet) throws TradeLinkException{
		m_source = source;
		m_destination = dest;
		if(m_source == m_destination){throw new InvalidTradeLinkException(this);}
		planet.addTradeLink(this);
		m_planet = planet;
	}
	public Planet getPlanet(){return m_planet;}
	public RiffDataPoint getSource(){return m_source;}
	public RiffDataPoint getDestination(){return m_destination;}
	public double getAngle(){
		if(m_angle != null){return m_angle.doubleValue();}
		double longDelta = ((RiffSpherePoint)m_destination.getAbsolutePosition()).getLongitudeRadians() -((RiffSpherePoint)m_source.getAbsolutePosition()).getLongitudeRadians();
		double latDelta = ((RiffSpherePoint)m_destination.getAbsolutePosition()).getLatitudeRadians() -((RiffSpherePoint)m_source.getAbsolutePosition()).getLatitudeRadians();
		if(latDelta == 0){
			if(longDelta <0){
				m_angle = new Double(Math.PI/2.0d);
			}else if(longDelta > 0){
				m_angle = new Double(-Math.PI/2);
			}
			return getAngle();
		}
		m_angle = new Double(Math.atan(longDelta/latDelta));
		return getAngle();
	}
	public double getDistance(){return RiffToolbox.getSphericalDistance(m_source, m_destination);}
	public int compareTo(Object obj){
		getAngle();
		return m_angle.compareTo(new Double(((TradeLink)obj).getAngle()));
	}
	public String toString(){
		String string = new String();
		string += "TradeLink: ";
		string += "\nSource: " + m_source;
		string += "\nDestination: " + m_destination;
		return string;
	}
}
