public abstract class Stipulation implements Comparable{
	protected Relationship m_relationship;
	public abstract String getStipulationType();
	public abstract String toString();
	public abstract boolean equals(Object stip);
	public abstract int compareTo(Object stip);
		
}
