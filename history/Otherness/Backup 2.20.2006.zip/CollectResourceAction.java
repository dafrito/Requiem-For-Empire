public class CollectResourceAction extends Action{
	private static String m_actionName = new String("Collect Resource");
	public String toString(){return m_actionName;}
	public boolean execute(Order superOrder, int iterationTime){
		CollectResourceOrder order = (CollectResourceOrder)superOrder;
		double resource = order.getResourcePoint().getSlice(iterationTime);
		Lot lot = order.getResourcePoint().getLot(resource * order.getOrganization().getProficiency(this, order.getResourcePoint().getCommodity()));
		lot.setDeFactoOwner(order.getOrganization());
		try{
			order.getOrganization().addAsset(lot);
		}catch(CommodityMapException ex){
			order.setException(ex);
		}
		return true;
	}
}
