public abstract class RiffSurface extends RiffDataPoint{
	public abstract double getLeftExtreme();
	public abstract double getRightExtreme();
	public abstract double getTopExtreme();
	public abstract double getBottomExtreme();
}
