import java.lang.Math;

public class LinearGradient extends RiffSurface{
	private double m_exponent;
	private double m_radius;
	public LinearGradient(RiffDataPoint focus, double radius, double exponent) throws ZeroRadiusException{
		m_point = focus;
		m_radius = radius;
		m_exponent = exponent;
		if(m_radius == 0.0d){throw(new ZeroRadiusException(this));}
	}
	public double getOverlap(RiffDataPoint testPoint){
		double distance = RiffToolbox.getDistance(getAbsolutePosition(), testPoint);
		if(Math.abs(distance) > m_radius || m_exponent == 0){return 0.0d; }
		return Math.abs(Math.pow(distance / m_radius,m_exponent)-1.0d);
	}
	public double getLeftExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() - m_radius;}
	public double getRightExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() + m_radius;}
	public double getTopExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() + m_radius;}
	public double getBottomExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() - m_radius;}
	public String toString(){
		String string = new String();
		string += "Linear Gradient\n";
		string += "Focus: " + getAbsolutePosition();
		string += "\nRadius: " + m_radius;
		return string;
	}
}
		
