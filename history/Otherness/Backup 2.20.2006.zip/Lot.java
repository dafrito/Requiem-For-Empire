public class Lot extends Asset{
	private Brand m_brand;
	private double m_quality;
	private double m_quantity;
	public Lot(Organization owner, Brand brand, double quality, double quantity){
		super(owner);
		m_brand = brand;
		m_quality = quality;
		m_quantity = quantity;
		m_assetType = new String("Lot");
	}
	public double getQuality(){return m_quality;}
	public double getQuantity(){return m_quantity;}
	public boolean setQuantity(double quantity){m_quantity = quantity;return true;}
	public Commodity getCommodity(){return m_brand.getCommodity();}
	public Brand getBrand(){return m_brand;}
	public void iterate(int iterationTime){}
	public String toString(){
		String string = new String();
		string += "\n" + RiffToolbox.printUnderline("Lot of " + m_brand.getName(), "-");
		string += "Commodity: " + m_brand.getCommodity().getName() + "\n";
		string += "Quality: " + m_quality + " | Quantity: " + m_quantity;
		return string;
	}
}
