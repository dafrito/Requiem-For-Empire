public class TerrainPoint extends RiffDataPoint{
	public TerrainPoint(RiffDataPoint area, Planet planet){
		super(area, planet);
	}
}
