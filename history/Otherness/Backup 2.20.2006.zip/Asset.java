import java.util.*;

public abstract class Asset extends UniqueObject implements Comparable{
	protected Organization m_deFactoOwner;
	protected Map m_deJureOwners;
	protected String m_assetType = new String("Asset");
	public Asset(){
		m_deJureOwners = new HashMap();
	}
	public Asset(Organization owner){
		m_deFactoOwner = owner;
		m_deJureOwners = new HashMap();
	}
	public String getAssetType(){return m_assetType;}
	public boolean setDeFactoOwner(Organization owner){m_deFactoOwner = owner;return true;}
	public Organization getDeFactoOwner(){return m_deFactoOwner;}
	public Map getAllDeJureOwners(){return m_deJureOwners;}
	public OwnershipClaim getOwnershipContract(Organization owner){return (OwnershipClaim)m_deJureOwners.get(owner);}
	public boolean addOwnershipContract(OwnershipClaim claim){m_deJureOwners.put(claim.getClaimer(), claim);return true;}
	public OwnershipClaim removeOwnershipContract(Organization owner){return (OwnershipClaim)m_deJureOwners.remove(owner);}
	public abstract void iterate(int iterationTime);
	public abstract String toString();
	public boolean equals(Object obj){
		return (getAssetType() == ((Asset)obj).getAssetType());
	}
	public int compareTo(Object obj){
		return getAssetType().compareTo(((Asset)obj).getAssetType());
	}
}
