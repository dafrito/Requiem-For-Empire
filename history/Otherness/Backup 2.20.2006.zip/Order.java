public abstract class Order{
	protected Organization m_organization;
	protected Exception m_exception;
	public Order(Organization organization){
		m_organization = organization;
	}
	public Organization getOrganization(){return m_organization;}
	public void setException(Exception ex){m_exception = ex;}
	public abstract int execute(int iterationTime) throws OrderException;
	public abstract String toString();
}
