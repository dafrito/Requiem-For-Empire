import java.lang.Math;

public class RiffSpherePoint extends RiffAbsolutePoint{
	private double m_latitude;
	private double m_longitude;
	public RiffSpherePoint(Location referenceLocation, double longitude, double latitude){
		super(null, referenceLocation);
		m_latitude = latitude % 90;
		m_longitude = longitude % 180;
	}
	public double getLatitudeDegrees(){return m_latitude;}
	public double getLongitudeDegrees(){return m_longitude;}
	public boolean setLatitudeDegrees(double latitude){m_latitude = latitude % 90;return true;}
	public boolean setLongitudeDegrees(double longitude){m_longitude = longitude % 180;return true;}
	public void setPosition(double lat, double longit){
		m_latitude = lat % 90;
		m_longitude = longit % 180;
	}
	public void setLocation(RiffDataPoint point){
		m_latitude = ((RiffSpherePoint)point.getAbsolutePosition()).getLatitudeDegrees();
		m_longitude = ((RiffSpherePoint)point.getAbsolutePosition()).getLongitudeDegrees();
	}
	public double getLatitudeRadians(){return Math.toRadians(m_latitude);}
	public double getLongitudeRadians(){return Math.toRadians(m_longitude);}
	public boolean setLatitudeRadians(double latitude){m_latitude = Math.toDegrees(latitude);return true;}
	public boolean setLongitudeRadians(double longitude){m_longitude = Math.toDegrees(longitude);return true;}
	public int compareTo(Object o){
		if(getLatitudeDegrees() > ((RiffSpherePoint)o).getLatitudeDegrees()){return 1;}
		if(getLatitudeDegrees() < ((RiffSpherePoint)o).getLatitudeDegrees()){return -1;}
		if(getLongitudeDegrees() > ((RiffSpherePoint)o).getLongitudeDegrees()){return 1;}
		if(getLongitudeDegrees() < ((RiffSpherePoint)o).getLongitudeDegrees()){return -1;}
		return 0;
	}
	public boolean equals(Object o){
		if(compareTo(o) == 0){return true;}
		return false;
	}
	public String toString(){
		String string = new String();
		string += "(" + m_longitude + " degrees longitude, " + m_latitude + " degrees latitude)";
		return string;
	}
}
