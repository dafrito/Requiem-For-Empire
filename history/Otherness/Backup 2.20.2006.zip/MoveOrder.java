import java.util.*;
import java.util.Collections;

public class MoveOrder extends Order{
	private RiffDataPoint m_destination, m_source;
	private double m_offsetPercentage, m_offsetDistance;
	private MobileUnit m_mobileUnit;
	private TradeLink m_tradeLink;
	private List m_tradeLinks;
	private Planet m_planet;
	private static MoveAction m_action;
	private int m_timeSpent;
	public MoveOrder(Organization org, MobileUnit unit, Planet planet, RiffDataPoint source, RiffDataPoint dest){
		super(org);
		m_source = source;
		m_destination = dest;
		m_mobileUnit = unit;
		m_planet = planet;
		m_tradeLinks = getRoute();
		if(m_tradeLinks != null){m_tradeLink = (TradeLink)m_tradeLinks.get(0);}
		m_offsetDistance =0;
	}
	public boolean hasRoute(){return (m_tradeLinks!=null);}
	public MobileUnit getMobileUnit(){return m_mobileUnit;}
	public TradeLink getTradeLink(){return m_tradeLink;}
	public double getOffsetDistance(){return m_offsetDistance;}
	public void addOffsetDistance(double distance){setOffsetDistance(m_offsetDistance + distance);}
	public void setOffsetDistance(double distance){
		System.out.println("Distance traveled: " + distance);
		double percentage = distance / m_tradeLink.getDistance();
		m_offsetDistance = distance;
		m_offsetPercentage = percentage;
		m_mobileUnit.setOffsetPercentage(percentage);
	}
	//public void setLocation(RiffDataPoint point){
	//	m_structure.setLocation(point);
	//}
	private List m_tempFailedList = new LinkedList();
	public List getRoute(){return getRoute(m_source);}
	public List getRoute(RiffDataPoint point){
		Map map = m_planet.getTradeLinks(point);
		if(map==null){return null;}
		if(map.get(m_destination) != null){
			// There is a direct route.
			List list = new LinkedList();
			list.add((TradeLink)map.get(m_destination));
			return list;
		}
		m_tempFailedList.add(point);
		List testList = new LinkedList(map.values());
		Collections.sort(testList);
		for(int i=0;i<testList.size();i++){
			if(m_tempFailedList.contains(((TradeLink)testList.get(i)).getDestination())){
				continue;
			}
			List list = getRoute(((TradeLink)testList.get(i)).getDestination());
			if(list != null){
				List ourList = new LinkedList();
				ourList.add((TradeLink)testList.get(i));
				ourList.addAll(list);
				return ourList;
			}else{
				m_tempFailedList.add(((TradeLink)testList.get(i)).getDestination());
			}
		}
		return null;
	}
	public void setSpentTime(int time){
		m_timeSpent = time;
	}
	public int execute(int iterationTime) throws OrderException{
		if(MoveOrder.m_action == null){
			MoveAction action = new MoveAction();
			RiffActions.addAction(action);
			MoveOrder.m_action = action;
		}
		if(m_tradeLinks == null){
			if(getRoute()==null){
				throw(new NoTravelRouteException(this));
			}
		}
		int totalTime=0;
		for(int i=0;i<m_tradeLinks.size();i++){
			m_tradeLink = (TradeLink)m_tradeLinks.get(i);
			m_mobileUnit.setTradeLink(m_tradeLink);
			MoveOrder.m_action.execute(this, iterationTime);
			totalTime += m_timeSpent;
			if(totalTime >= iterationTime){return totalTime;}
			System.out.println("Point reached.");
			m_tradeLinks.remove(i);
			setOffsetDistance(0.0d);
			i--;
		}
		AssetPoint point = new AssetPoint(m_destination, m_planet);
		try{
		point.addAsset(m_mobileUnit);
		m_mobileUnit.setTradeLink(null);
		}catch(CommodityMapException ex){
			throw new FailedActionException(ex);
		}
		return totalTime;
	}
	public String toString(){
		String string = new String("Move Order:");
		if(m_tradeLinks != null){
			string += "\nRoute: ";
			for(int i=0;i<m_tradeLinks.size();i++){
				string += "\n" + (TradeLink)m_tradeLinks.get(i);
			}
		}else{
			string += "This route does not exist.";
		}
		return string;
	}
}
