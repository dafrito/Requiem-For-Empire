public class NoTravelRouteException extends OrderException{
	private MoveOrder m_order;
	public NoTravelRouteException(MoveOrder order){
		m_order = order;
	}
	public String getMessage(){
		String string = new String();
		string += "An order was to be carried for the mobile unit to move from its source to its destination, but there is no available route.";
		string += "\nOrder: " + m_order;
		return string;
	}
}
