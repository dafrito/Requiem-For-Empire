import javax.swing.*; // For JPanel, etc.
import java.awt.*;           // For Graphics, etc.
import java.awt.geom.*;      // For Ellipse2D, etc.
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.JOptionPane;
import java.lang.Math;
public class RiffGUI extends JPanel implements KeyListener{
	private java.util.List m_points = new LinkedList();
	private AssetPoint m_firstAsset, m_secondAsset;
	private final int m_width = 360;
	private MobileUnit m_truck;
	private Planet m_planet;
	private Organization m_organization;
	private Map m_pointMap;
	public RiffGUI() throws InvalidScenarioDateRangeException{
		GregorianCalendar startDate = new GregorianCalendar(2100, Calendar.MARCH, 1, 5, 25, 00);
		GregorianCalendar endDate = new GregorianCalendar(2200, Calendar.DECEMBER, 25, 12, 00, 00);
		try{
			Scenario scenario = new Scenario("Roman Campaign", new Planet("Earth", "Terran", null, null, 6372.795), ((365/4)*3600*24)/(3600*24), startDate, endDate);
			m_planet = (Planet)scenario.getRootLocation();
			//scenario.getRootLocation().addAssetPoint(new HabitableStructure(
			Market market = new Market();
			Commodity widgetComm = new Commodity("Widgets");
			Commodity fuelComm = new Commodity("Combustible");
			Commodity foodComm = new Commodity("Food");
			Commodity widgetFluff = new Commodity("Widget Fluff");
			widgetComm.addParent(fuelComm);
			widgetComm.addParent(foodComm);
			setFocusable(true);
			m_organization = new Organization(null, "Widget, Inc", "Widget", "Widgettian");
			
			widgetComm.addPrerequisite(widgetFluff, 25);
			market.addLot(new Lot(m_organization, new Brand("Generic Fluff", widgetFluff, .97, m_organization), 85, 10000000));
			market.addLot(new Lot(m_organization, new Brand("Northern Widgets", widgetComm, 1, m_organization), .85, 39));
			//System.out.println(market);
			m_truck = new MobileUnit(m_organization);
			RiffSpherePoint m_pointA = new RiffSpherePoint(scenario.getRootLocation(), 0,45);
			RiffSpherePoint m_pointB= new RiffSpherePoint(scenario.getRootLocation(), 45,0);
			RiffSpherePoint m_pointC= new RiffSpherePoint(scenario.getRootLocation(), 74, 23);
			m_pointMap = new HashMap();
			for(int i=0;i<20;i++){
				m_pointMap.put(new Integer(i), new RiffSpherePoint(scenario.getRootLocation(), Math.random() * 360, Math.random() * 180));
			}
			System.out.println(m_pointMap);
			for(int i=0;i<20;i++){
				Integer intA = new Integer((int)(Math.random() * 19));
				Integer intB;
				do{
					intB = new Integer((int)(Math.random() * 19));
				}while(intA.intValue() == intB.intValue());
				System.out.println(new TradeLink((RiffSpherePoint)m_pointMap.get(intA), (RiffSpherePoint)m_pointMap.get(intB), (Planet)scenario.getRootLocation()));
			}
			System.out.println(scenario.getRootLocation());
			getRoute();
			//System.out.println(scenario.getRootLocation());
			//LogManager.printMessages();
			m_organization.iterate(50);
			addKeyListener(this);
		}catch(OverwriteException ex){
			System.out.println(ex);
		}catch(CommodityMapException ex){
			System.out.println(ex);
		}catch(TradeLinkException ex){
			System.out.println(ex);
		}
	}
	public void getRoute(){
		MoveOrder order;
		do{
			Integer intA = new Integer((int)(Math.random() * 20));
			Integer intB;
			do{
				intB = new Integer((int)(Math.random() * 20));
			}while(intA.intValue() == intB.intValue());
			order= new MoveOrder(m_organization, m_truck, m_planet, (RiffSpherePoint)m_pointMap.get(intA), (RiffSpherePoint)m_pointMap.get(intB));
		}while(!order.hasRoute());
		m_organization.addOrder(order);
	}
	public void paintComponent(Graphics g){
		clear(g);
		Graphics2D g2d = (Graphics2D)g;
		java.util.List list = m_planet.getAllTradeLinks();
		for(int i=0;i<list.size();i++){
			TradeLink link = (TradeLink)list.get(i);
			g2d.draw(new Line2D.Double((((RiffSpherePoint)link.getSource().getAbsolutePosition()).getLongitudeDegrees())*4,
			((RiffSpherePoint)link.getSource().getAbsolutePosition()).getLatitudeDegrees()*4,
			((RiffSpherePoint)link.getDestination().getAbsolutePosition()).getLongitudeDegrees()*4,
			((RiffSpherePoint)link.getDestination().getAbsolutePosition()).getLatitudeDegrees()*4));
		}
		if(m_truck.getAbsolutePosition() == null){getRoute();m_organization.iterate(20);return;}
		g2d.fillOval((int)m_truck.getAbsolutePosition().getLongitudeDegrees()*4-2,
		(int)m_truck.getAbsolutePosition().getLatitudeDegrees()*4-2,
		8,8);
	}
	
	public void keyTyped(KeyEvent keyEvent){
		//System.out.println("Keyhit!");
		if(m_truck.getAbsolutePosition() == null){getRoute();}
		m_organization.iterate(20);
		//System.out.println(m_truck);
		repaint();
	}
	public void keyReleased(KeyEvent keyEvent){}
	public void keyPressed(KeyEvent keyEvent){
	}
	protected void clear(Graphics g){super.paintComponent(g);}
	
  	public static void main(String[] args) {
	 	JFrame frame = new JFrame("RiffGUI");
	 	frame.setSize(720, 360);
		try{
			frame.setContentPane(new RiffGUI());
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
		}catch(InvalidScenarioDateRangeException ex){
			System.out.println(ex);
		}
		
	}
}
