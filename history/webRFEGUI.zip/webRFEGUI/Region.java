import java.util.*;

public class Region{
	protected List m_locationPoints;
	public Region(){
		m_locationPoints = new LinkedList();
	}
	public Map getOverlap(RiffDataPoint point){
		Map map = new HashMap();
		for(int i=0;i<m_locationPoints.size();i++){
			Double myDouble = new Double(((RiffDataPoint)m_locationPoints.get(i)).getOverlap(point));
			if(myDouble.doubleValue() == 0.0d){continue;}
			map.put(((RiffDataPoint)m_locationPoints.get(i)), myDouble);
		}
		return map;
	}
	public boolean addPoint(RiffDataPoint point){m_locationPoints.add(point);return true;}
	public List getPoints(){return m_locationPoints;}
	public String toString(){
		String string = new String();
		string += "Region\n";
		string += "Points in region:\n";
		for(int i=0;i<m_locationPoints.size();i++){
			string += ((RiffDataPoint)m_locationPoints.get(i));
		}
		return string;
	}
}
