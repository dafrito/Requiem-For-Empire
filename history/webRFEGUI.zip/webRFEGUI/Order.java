public abstract class Order{
	protected Exception m_exception;
	public void setException(Exception ex){m_exception = ex;}
	public abstract void execute() throws OrderException;
	public abstract OrderStatus getStatus();
	public abstract String toString();
}
