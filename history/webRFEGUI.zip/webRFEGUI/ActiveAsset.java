import java.util.*;

public abstract class ActiveAsset extends Asset{
	public abstract void iterate(int iterationTime);
	private static final String m_ActiveAssetString = "Active Asset";
	protected AssetMap m_assetMap = new AssetMap();
	public ActiveAsset(){
		super();
	}
	public String getAssetType(){return ActiveAsset.m_ActiveAssetString;}
	public String toString(){
		String string = new String();
		string += "Active Asset: ";
		return string;
	}
	public abstract List getAssetsList(Commodity comm, double quantity);
	public abstract List getAssetsList(Commodity comm);
	public abstract void removeAsset(Asset asset);
	public abstract void removeAssets(List list);
	public abstract void addAssets(List listGoods) throws CommodityMapException;
	public abstract void addAsset(Asset asset) throws CommodityMapException;
}
