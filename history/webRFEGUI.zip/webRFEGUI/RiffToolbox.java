import java.lang.Math;
import java.util.Random;
import java.util.*;
import java.awt.Polygon;
import java.awt.geom.Line2D.Double;
import java.awt.Point;

public class RiffToolbox{
	// Returns the slope of these lines.
	public static double getSlope(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		return (pointB.getY()-pointA.getY())/(pointB.getX()-pointA.getX());
	}
	// Tests if a polygon is convex.
	public static boolean isPolygonConvex(DiscreteRegion region){
		List pointList = region.getPoints();
		Boolean myBool = null;
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint linePointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint linePointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			for(int k=0;k<pointList.size();k++){
				RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(k);
				//(y - y0) (x1 - x0) - (x - x0) (y1 - y0)
				double value = (testPoint.getY() - linePointA.getY())*(linePointB.getX() - linePointA.getX()) - (testPoint.getX() - linePointA.getX())*(linePointB.getY() - linePointA.getY());
				if(myBool == null){
					if(value > 0){
						myBool = new Boolean(true);
					}else if(value < 0){
						myBool = new Boolean(false);
					}
				}else{
					if(value > 0){
						if(myBool.booleanValue() == true){continue;}
						return false;
					}else if(value < 0){
						if(myBool.booleanValue() == false){continue;}
						return false;
					}else{
						continue;
					}
				}
			}
		}
		return true;
	}
	public static List optimizePolygons(Collection list){
		Iterator iter = list.iterator();
		List polygons = new LinkedList();
		while(iter.hasNext()){
			DiscreteRegion region = (DiscreteRegion)iter.next();
			region = RiffToolbox.optimizePolygon(region);
			if(region==null){continue;}
			polygons.add(region);
		}
		return polygons;
	}
	// Removes overlapping points, points that are not essential, and also confirms that the polygon is at least three points, and invalidate self-intersecting polygons.
	public static DiscreteRegion optimizePolygon(DiscreteRegion originalRegion){
		DiscreteRegion region = new DiscreteRegion(originalRegion);
		// Fail if not at least a triangle
		if(region.getPoints().size()<3){
			LogManager.writeLog("RiffToolbox", "DiscreteRegion invalid because it has less than 3 points.");
			return null;
		}
		// Remove all overlapping points.
		for(int i=0;i<region.getPoints().size();i++){
			for(int j=0;j<region.getPoints().size();j++){
				if(i==j){continue;}
				if(region.getPoints().get(i).equals(region.getPoints().get(j))){
					region.removePoint(j);
					j--;
					i--;
				}
			}
		}
		// Remove all unnecessary points.
		for(int i=0;i<region.getPoints().size();i++){
			if(region.getPoints().isEmpty()==true){return null;}
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)region.getPoints().get(i);
			for(int j=1;j<region.getPoints().size();j++){
				if(i==j){continue;}
				RiffAbsolutePoint pointB = (RiffAbsolutePoint)region.getPoints().get(j);
				double slope = RiffToolbox.getSlope(pointA, pointB);
				for(int k=0;k<region.getPoints().size();k++){
					if(k==i || k==j){continue;}
					RiffAbsolutePoint pointC = (RiffAbsolutePoint)region.getPoints().get(k);
					double testSlope = RiffToolbox.getSlope(pointA, pointC);
					if(testSlope==slope){
						double y = slope * (pointC.getX() - pointA.getX()) + pointA.getY();
						if(y==pointC.getY()){
							if(RiffToolbox.getDistance(pointA, pointB) + RiffToolbox.getDistance(pointB, pointC) == RiffToolbox.getDistance(pointA, pointC)){
								System.out.println("Attempting to remove this point:" + pointB);
								System.out.println("In order to create the more optimal line with these points:");
								System.out.println("First point: " + pointA);
								System.out.println("Second point: " + pointC);
								if(RiffToolbox.confirmInteriorLine(pointA, pointC, region)){
									LogManager.writeLog("RiffToolbox", "Removing this point: " + pointB);
									region.removePoint(j);
									j--;
								}
								continue;
							}
						}else if(RiffToolbox.getDistance(pointB, pointC) + RiffToolbox.getDistance(pointA, pointC) == RiffToolbox.getDistance(pointA, pointB)){
							System.out.println("Attempting to remove this point:" + pointC);
							System.out.println("In order to create the more optimal line with these points:");
							System.out.println("First point: " + pointA);
							System.out.println("Second point: " + pointB);
							if(RiffToolbox.confirmInteriorLine(pointA, pointB, region)){
								LogManager.writeLog("RiffToolbox", "Removing this point: " + pointC);
								region.removePoint(k);
								k--;
							}
							continue;
						}else if(RiffToolbox.getDistance(pointB, pointA) + RiffToolbox.getDistance(pointA, pointC) == RiffToolbox.getDistance(pointC, pointB)){
							System.out.println("Attempting to remove this point:" + pointA);
							System.out.println("In order to create the more optimal line with these points:");
							System.out.println("First point: " + pointC);
							System.out.println("Second point: " + pointB);
							if(RiffToolbox.confirmInteriorLine(pointC, pointB, region)){
								LogManager.writeLog("RiffToolbox", "Removing this point: " + pointA);
								region.removePoint(i);
								i--;
							}
							continue;
						}
					}
				}
			}
		}
		// Test for self-intersections
		for(int i=0;i<region.getPoints().size();i++){
			for(int j=0;j<region.getPoints().size();j++){
				if(i==j){continue;}
				System.out.println("Testing for self-intersection...");
				if(getIntersection((RiffAbsolutePoint)region.getPoints().get(i),(RiffAbsolutePoint)region.getPoints().get((i+1)%region.getPoints().size()),(RiffAbsolutePoint)region.getPoints().get(j),(RiffAbsolutePoint)region.getPoints().get((j+1)%region.getPoints().size()))){
					System.out.println("Polygon intersects itself and is invalid, reutrning null from optimized polygon.");
					return null;
				}
			}
		}
		// Fail if not at least a triangle
		if(region.getPoints().size()<3){
			LogManager.writeLog("RiffToolbox", "DiscreteRegion invalid because it has less than 3 points.");
			return null;
		}
		return region;
	}
	public static String displayList(Collection list){return displayList(list, "item", "items");}
	public static String displayList(Collection list, String singular){return displayList(list, singular, new String(singular + "s"));}
	public static String displayList(Collection list, String singular, String plural){
		String string = new String();
		if(list==null||list.isEmpty()){
			string += "\nThis list is empty.";
			return string;
		}else if(list.size()==1){
			string += "\nThis list contains one " + singular;
		}else{
			string += "\nThis list contains " + list.size() + " " + plural;
		}
		Iterator iter = list.iterator();
		while(iter.hasNext()){
			string += "\n" + iter.next();
		}
		return string;
	}
	
	// Tests how many times a line, using the coord's as the first point, and the extreme right point of the poly, crosses any other border.
	public static int getCrosses(double xCoord, double yCoord, DiscreteRegion region){
		System.out.println("Testing for crosses for x-coord:" + xCoord + " and y-coord: " + yCoord);
		List pointList = region.getPoints();
		int crosses=0;
		double xExtremeCoord=java.lang.Double.NEGATIVE_INFINITY;
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(i);
			if(testPoint.getX()>xExtremeCoord){
				xExtremeCoord=testPoint.getX();
			}
		}
		xExtremeCoord+=1.0f;
		System.out.println("This line extends to x-coord: " + xExtremeCoord + " and y-coord: " + yCoord);
		RiffEuclideanPoint crossExtremePoint = new RiffEuclideanPoint("Extreme right-point", null, xExtremeCoord, yCoord, 0);
		RiffEuclideanPoint crossMidPoint= new RiffEuclideanPoint("MidPoint", null, xCoord, yCoord, 0);
		List overlappedVertices = new LinkedList();
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint testPointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			if(testPointA.getY()==yCoord){
				if(overlappedVertices.contains(testPointA)){continue;
				}else{
					overlappedVertices.add(testPointA);
				}
			}else if(testPointB.getY()==yCoord){
				if(overlappedVertices.contains(testPointB)){continue;
				}else{
					overlappedVertices.add(testPointB);
				}
			}
			if(RiffToolbox.getIntersection(crossMidPoint, crossExtremePoint, testPointA, testPointB)){
				crosses++;
			}
		}
		System.out.println("Total Crosses: " + crosses);
		return crosses;
	}
	
	// Removes overlapping polygons and creates new ones with the characteristics of the previous two merged together.
	/*public static void removeOverlappingPolygons(DiscreteRegionBinaryTree tree){
		tree.get
		
	}*/
	
	// Tests if (pointA, pointB) intersects (testPointA, testPointB)
	public static boolean getIntersection(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, RiffAbsolutePoint testPointA, RiffAbsolutePoint testPointB){
		System.out.println("Testing for intersection between these two sets of points...");
		System.out.println("First control point: [" + pointA + "] Second Control Point: [" + pointB + "]");
		if(pointA.equals(pointB)){
			System.out.println("First control point is equal to second control point, returning false.");
			return false;
		}
		double slope = RiffToolbox.getSlope(pointA, pointB);
		double testSlope = RiffToolbox.getSlope(testPointA, testPointB);
		if(testPointA.equals(testPointB)){
			System.out.println("First test point is equal to second test point, returning false.");
			return false;
		}
		System.out.println("First test-point: [" + testPointA + "] Second test-point: [" + testPointB + "]");
		if((pointA.equals(testPointA) || pointA.equals(testPointB))||(pointB.equals(testPointA) || pointB.equals(testPointB))){
			System.out.println("One of the testpoints is equal to one of the other points, returning false.");
			return false;
		}
		if(Math.max(pointB.getX(), pointA.getX()) < Math.min(testPointA.getX(), testPointB.getX())){
			System.out.println("The maximum x-value of the control points is less than the minimum X-value of the testPoints, returning false."); 
			return false;
		}
		if(Math.min(pointB.getX(), pointA.getX()) > Math.max(testPointA.getX(), testPointB.getX())){
			System.out.println("The minimum x-value of the control points is greater than the maximum X-value of the testPoints, returning false.");
			return false;
		}
		if(Math.max(pointA.getY(),pointB.getY()) < Math.min(testPointA.getY(), testPointB.getY())){
			System.out.println("The minimum Y-value of the control points is greater than the maximum Y-value of the testPoints, returning false.");
			return false;
		}
		if(Math.min(pointA.getY(),pointB.getY()) > Math.max(testPointA.getY(), testPointB.getY())){
			System.out.println("The minimum Y-value of the control points is greater than the maximum Y-value of the testPoints, returning false.");
			return false;
		}
		double xIntersection = ((-slope * pointA.getX() + pointA.getY()) - (-testSlope * testPointA.getX() + testPointA.getY()))/(testSlope-slope);
		System.out.println("The X-intercept between these two points is: " + xIntersection);
		if(xIntersection < Math.min(testPointA.getX(), testPointB.getX())){
			System.out.println("The X-intercept is less than the minimum of the X-values of the testPoints, returning false.");
			return false;
		}
		if(xIntersection > Math.max(testPointA.getX(), testPointB.getX())){
			System.out.println("The X-intercept is greater than the maximum of the X-values of the testPoints, returning false.");
			return false;
		}
		if(xIntersection < Math.min(pointA.getX(), pointB.getX())){
			System.out.println("The X-intercept is less than the minimum of the X-values of the control points, returning false.");
			return false;
		}
		if(xIntersection > Math.max(pointA.getX(), pointB.getX())){
			System.out.println("The X-intercept is greater than the maximum of the X-values of the control points, returning false.");
			return false;
		}
		double yIntersection = slope * xIntersection + (-slope * pointA.getX() + pointA.getY());
		System.out.println("The Y-intercept between these two points is: " + yIntersection);
		if(yIntersection < Math.min(testPointA.getY(), testPointB.getY())){
			System.out.println("The Y-intercept is less than the minimum of the Y-values of the testPoints, returning false.");
			return false;
		}
		if(yIntersection > Math.max(testPointA.getY(), testPointB.getY())){
			System.out.println("The Y-intercept is greater than the maximum of the Y-values of the testPoints, returning false.");
			return false;
		}
		if(yIntersection < Math.min(pointA.getY(), pointB.getY())){
			System.out.println("The Y-intercept is less than the minimum of the Y-values of the control points, returning false.");
			return false;
		}
		if(yIntersection > Math.max(pointA.getY(), pointB.getY())){
			System.out.println("The Y-intercept is greater than the maximum of the Y-values of the control points, returning false.");
			return false;
		}
		System.out.println("These lines intersect.");
		return true;
	}
	// Confirms that the line formed by the two points is an interior line.
	public static boolean confirmInteriorLine(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, DiscreteRegion region){
		List pointList = region.getPoints();
		System.out.println("Confirming interior line with these points: " + pointA.getName() + " and " + pointB.getName());
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint testPointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			if((testPointA.equals(pointA) && testPointB.equals(pointB))||(testPointA.equals(pointB) && testPointB.equals(pointA))){return false;}
			if(RiffToolbox.getIntersection(pointA, pointB, testPointA, testPointB)){
				return false;
			}
		}
		System.out.println("No intersections found, checking for crosses.");
		int crosses=RiffToolbox.getCrosses(pointA.getX()+(pointB.getX()-pointA.getX())/2,pointA.getY()+(pointB.getY()-pointA.getY())/2, region);
		if(crosses==0||crosses%2==0){return false;}
		System.out.println("Interior line confirmed.");
		return true;
	}
	// This process converts a concave polygon to a list of convex polygons.
	public static List convertPolyToConvex(DiscreteRegion originalRegion){
		System.out.println("Attempting to convert this polygon into its convex parts...");
		System.out.println(originalRegion);
		DiscreteRegion region = RiffToolbox.optimizePolygon(originalRegion);
		System.out.println("Optimized region: " + region);
		if(region==null){return null;}
		List convexPolygons = new LinkedList();
		if(RiffToolbox.isPolygonConvex(region)==true){
			System.out.println("This polygon is convex, so adding it to the list and returning.");
			convexPolygons.add(region);
			return convexPolygons;
		}
		System.out.println("This polygon is concave. Attempting to subdivide...");
		DiscreteRegion testRegion = new DiscreteRegion();
		List pointList = region.getPoints();
		for(int i=0;i<pointList.size();i++){
			boolean alreadyCreated = false;
			System.out.println("Attempting to form a triangle from these points:");
			System.out.println("First point: " + pointList.get(i) + ", Second Point: " + (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()) + ", Third point: " + (RiffAbsolutePoint)pointList.get((i+2)%pointList.size())); 
			if(RiffToolbox.confirmInteriorLine((RiffAbsolutePoint)pointList.get(i),(RiffAbsolutePoint)pointList.get((i+2)%pointList.size()),region)==false){
				System.out.println("Failed interior-line test.");
				continue;
			}
			testRegion = new DiscreteRegion();
			testRegion.addPoint((RiffAbsolutePoint)pointList.get(i));
			testRegion.addPoint((RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
			testRegion.addPoint((RiffAbsolutePoint)pointList.get((i+2)%pointList.size()));
			for(int k=0;k<convexPolygons.size();k++){
				if(testRegion.equals(convexPolygons.get(k))){alreadyCreated=true;break;}
			}
			if(alreadyCreated){System.out.println("Polygon already created.");continue;}
			System.out.println("Removing this point: " + (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
			region.removePoint((RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
			System.out.println("Yielding the new triangle and this remaining region: " + region);
			convexPolygons.add(testRegion);
			
			convexPolygons.addAll(RiffToolbox.convertPolyToConvex(region));
			break;
		}
		return convexPolygons;
	}
	// Converts the list of polygons into convex polygons, returning the list of these.
	public static List convertPolyToConvex(List polygons){
		List list = new LinkedList();
		for(int i=0;i<polygons.size();i++){
			list.addAll(RiffToolbox.convertPolyToConvex((DiscreteRegion)polygons.get(i)));
		}
		return list;
	}
	// Takes a list of convex, non-overlapping polygons, and joins them if they share a common border and their joined polygon is convex. This function
	// returns this list, or the originalPolygon in a list if no polygons were joined.
	public static List joinPolygons(List polyList){
		List optimizedList = new LinkedList();
		for(int i=0;i<polyList.size();i++){
			for(int j=0;j<polyList.size();j++){
				if(i==j){continue;}
				DiscreteRegion firstRegion = (DiscreteRegion)polyList.get(i);
				DiscreteRegion secondRegion = (DiscreteRegion)polyList.get(j);
				for(int q=0;q<firstRegion.getPoints().size();q++){
					for(int x=0;x<secondRegion.getPoints().size();x++){
						if(!firstRegion.getPoints().get(q).equals(secondRegion.getPoints().get(x))&&!firstRegion.getPoints().get((q+1)%firstRegion.getPoints().size()).equals(secondRegion.getPoints().get(x))){continue;}
						if(!firstRegion.getPoints().get(q).equals(secondRegion.getPoints().get((x+1)%secondRegion.getPoints().size()))&&!firstRegion.getPoints().get((q+1)%firstRegion.getPoints().size()).equals(secondRegion.getPoints().get((x+1)%secondRegion.getPoints().size()))){continue;}
						DiscreteRegion testRegion = new DiscreteRegion();
						List pointSideList = RiffToolbox.getPointSideList(firstRegion, (RiffAbsolutePoint)firstRegion.getPoints().get(q), (RiffAbsolutePoint)firstRegion.getPoints().get((q+1)%firstRegion.getPoints().size()));
						if(((List)pointSideList.get(0)).isEmpty()){
							int firstPoint=q;
							if(q>(q+1)%firstRegion.getPoints().size()){
								firstPoint=(q+1)%firstRegion.getPoints().size();
							}
							for(int offsetPoint=0;offsetPoint<firstRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)firstRegion.getPoints().get((firstPoint+offsetPoint)%firstRegion.getPoints().size()));
							}
							firstPoint=x;
							if(x>(x+1)%secondRegion.getPoints().size()){
								firstPoint=(x+1)%secondRegion.getPoints().size();
							}
							for(int offsetPoint=1;offsetPoint<secondRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)secondRegion.getPoints().get((firstPoint+offsetPoint)%secondRegion.getPoints().size()));
							}
						}else{
							int firstPoint=x;
							if(x>(x+1)%secondRegion.getPoints().size()){
								firstPoint=(x+1)%secondRegion.getPoints().size();
							}
							for(int offsetPoint=0;offsetPoint<secondRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)secondRegion.getPoints().get((firstPoint+offsetPoint)%secondRegion.getPoints().size()));
							}
							firstPoint=q;
							if(q>(q+1)%firstRegion.getPoints().size()){
								firstPoint=(q+1)%firstRegion.getPoints().size();
							}
							for(int offsetPoint=1;offsetPoint<firstRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)firstRegion.getPoints().get((firstPoint+offsetPoint)%firstRegion.getPoints().size()));
							}
						}
						if(RiffToolbox.isPolygonConvex(testRegion)==false){continue;}
						optimizedList.add(testRegion);
						polyList.remove(firstRegion);
						polyList.remove(secondRegion);
						optimizedList.addAll(polyList);
						return RiffToolbox.joinPolygons(optimizedList);
					}
				}
			}
		}
		return polyList;
	}
	// Using the two given points to create a line, it returns a list. This list contains two lists, one containing all the points
	// on the left side, and one containing all the points on the right.
	public static List getPointSideList(DiscreteRegion region, RiffAbsolutePoint linePointA, RiffAbsolutePoint linePointB){
		List leftPoints = new LinkedList();
		List rightPoints = new LinkedList();
		for(int k=0;k<region.getPoints().size();k++){
			RiffAbsolutePoint testPoint = (RiffAbsolutePoint)region.getPoints().get(k);
			double value = (testPoint.getY() - linePointA.getY())*(linePointB.getX() - linePointA.getX()) - (testPoint.getX() - linePointA.getX())*(linePointB.getY() - linePointA.getY());
			if(value > 0){
				leftPoints.add(testPoint);
			}else if(value<0){
				rightPoints.add(testPoint);
			}
		}
		List fullList = new Vector();
		fullList.add(leftPoints);
		fullList.add(rightPoints);
		return fullList;
	}
	// Creates a Java-displayable polygon from the discreteRegion
	public static Polygon getPolygonFromDiscreteRegion(DiscreteRegion region){
		Polygon poly = new Polygon();
		for(int i=0;i<region.getPoints().size();i++){
			poly.addPoint((int)((RiffAbsolutePoint)region.getPoints().get(i)).getX(),(int)((RiffAbsolutePoint)region.getPoints().get(i)).getY());
		}
		return poly;
	}
	// Creates a list of lines from the discreteRegion
	public static List getLineListFromDiscreteRegion(DiscreteRegion region){
		List list = new LinkedList();
		for(int i=0;i<region.getPoints().size();i++){
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)region.getPoints().get(i);
			RiffAbsolutePoint pointB = (RiffAbsolutePoint)region.getPoints().get((i+1)%region.getPoints().size());
			list.add(new java.awt.geom.Line2D.Double(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY()));
		}
		return list;
	}
	public static String printUnderline(String baseString, String printChar){
		String string = new String(baseString + "\n");
		for(int i = baseString.length(); i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	public static String printLine(String symbol, int times){
		String string = new String();
		for(int i=0;i<times;i++){
			string += symbol;
		}
		string += "\n";
		return string;
	}
	private static Random m_random;
	public static Random getRandom(){
		if(RiffToolbox.m_random == null){
			RiffToolbox.m_random = new Random();
		}
		return RiffToolbox.m_random;
	}
	public static DiscreteRegion createRegion(DiscreteRegion region, int regionNum){
		switch(regionNum){
		case 0:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 288,78,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 263,46,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 196,100,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 239,79,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 264,72,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 263,96,0));
			return region;
		case 1:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 516,239,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 488,230,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 502,192,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 456,163,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 456,246,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 384,265,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 460,104,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 523,145,0));
			return region;
		case 2:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 50,50,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 75,75,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 100,100,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 125,125,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 150,150,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 250,50,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 225,50,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 150,125,0));
			region.addPoint(new RiffEuclideanPoint("I", null, 75,50,0));
			return region;
		case 3:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 300,158,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 328,73,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 226,140,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 346,219,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 445,110,0));
			return region;
		case 4:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 583,164,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 542,148,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 515,127,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 529,102,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 547,89,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 545,73,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 525,61,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 493,75,0));
			region.addPoint(new RiffEuclideanPoint("I", null, 471,97,0));
			region.addPoint(new RiffEuclideanPoint("J", null, 448,73,0));
			region.addPoint(new RiffEuclideanPoint("K", null, 508,43,0));
			region.addPoint(new RiffEuclideanPoint("L", null, 576,53,0));
			region.addPoint(new RiffEuclideanPoint("M", null, 608,125,0));
			return region;
		default:
			return null;
		}
	}
	public static RiffAbsolutePoint convertPointToEuclidean(Point point){
		return new RiffEuclideanPoint(null, point.getX(), point.getY(),0);
	}
	public static void determineMemoryUsage()
	{
		System.gc();
		long free = Runtime.getRuntime().freeMemory();
		long total = Runtime.getRuntime().totalMemory();
		long max = Runtime.getRuntime().maxMemory();
		System.out.println("Free memory in this chunk: " + (total-free));
		System.out.println("Total memory chunk size: " + total);
	    	System.out.println("Percentage used: " + 100*((double)total-(double)free)/(double)total);
		System.out.println("Maximum memory: " + max);
	}
	public static String printBorder(String baseString, String printChar){
		String string = new String();
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n " + baseString + "\n";
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	public static int compareDoubles(double firstDouble, double secondDouble){
		if(firstDouble < secondDouble){
			return -1;
		}if(firstDouble > secondDouble){
			return 1;
		}return 0;
	}
	public static double convertDegreesToRadians(double degrees){return degrees * Math.PI/180;}	
	public static double getDistance(RiffDataPoint firstPoint, RiffDataPoint secondPoint){
		return getDistance(firstPoint.getAbsolutePosition(), secondPoint.getAbsolutePosition());
	}
	public static double getDistance(RiffAbsolutePoint firstPoint, RiffAbsolutePoint secondPoint){
		return Math.sqrt(Math.pow(secondPoint.getX()-firstPoint.getX(), 2) + Math.pow(secondPoint.getY()-firstPoint.getY(),2));
	}
	public static double getDistance(RiffSpherePoint firstPoint, RiffSpherePoint secondPoint){
		Planet planet = (Planet)firstPoint.getReferenceLocation();
		double firstLat = Math.toRadians(firstPoint.getLatitudeDegrees());
		double secondLat = Math.toRadians(secondPoint.getLatitudeDegrees());
		double firstLong = Math.toRadians(firstPoint.getLongitudeDegrees());
		double secondLong = Math.toRadians(secondPoint.getLongitudeDegrees());
		double temp = Math.pow(Math.sin((secondLat - firstLat)/2),2) + Math.cos(firstLat) * Math.cos(secondLat) * Math.pow(Math.sin((secondLong - firstLong)/2),2);
		return planet.getRadius() * 2 * Math.asin(Math.min(1, Math.sqrt(temp)));
	}
	public static double getDistance(RiffEuclideanPoint firstPoint, RiffEuclideanPoint secondPoint){
		//( (x-a)2 + (y - b)2 + (z - c)2 )1/2
		double testDouble = Math.sqrt(Math.pow((secondPoint.getX() - firstPoint.getX()), 2) + Math.pow((secondPoint.getY() - firstPoint.getY()), 2) + Math.pow((secondPoint.getZ() - firstPoint.getZ()), 2));
		return testDouble;
	}
}
