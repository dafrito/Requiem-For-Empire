public class CommodityConversionEfficiency{
	private Commodity m_commodity;
	private double m_efficiency;
	public CommodityConversionEfficiency(Commodity commodity, double efficiency){
		m_commodity = commodity;
		m_efficiency = efficiency;
	}
	public double getEfficiency(){return m_efficiency;}
	public void setEfficiency(double efficiency){m_efficiency=efficiency;}
	public Commodity getCommodity(){return m_commodity;}
}
