public class OverwritingNameChangeException extends Exception{
	private Object m_parent;
	private String m_foundChild;
	private String m_newName;
	public OverwritingNameChangeException(Object parent, String foundChild, String newName){
		m_parent = parent;
		m_foundChild = foundChild;
		m_newName = newName;
	}
	public String getMessage(){
		String string = new String();
		string += "During a name-change operation, a value was found when using the potential key.\n";
		string += "Parent:\n" + m_parent;
		string += "\nChild that was found:\n" + m_foundChild;
		string += "\nKey used:\n" + m_newName;
		return string;
	}
}
