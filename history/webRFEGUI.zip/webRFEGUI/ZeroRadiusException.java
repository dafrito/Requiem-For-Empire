public class ZeroRadiusException extends LocationException{
	private RiffDataPoint m_area;
	public ZeroRadiusException(RiffDataPoint area){
		m_area = area;
	}
	public String toString(){
		String string = new String();
		string += "A gradient was initialized with a radius of zero, which could potentially result in a div/0 operation.\n";
		string += "Area Function:\n" + m_area;
		return string;
	}
}
