import java.util.*;

public class DiscreteRegion implements Comparable{
	private List m_points;
	private double m_leftExtreme, m_rightExtreme, m_topExtreme, m_bottomExtreme;
	private RiffAbsolutePoint m_midPoint;
	public DiscreteRegion(){
		m_points = new Vector();
		resetExtrema();
	}
	public DiscreteRegion(DiscreteRegion otherRegion){
		m_points = new Vector(otherRegion.getPoints());
		m_leftExtreme=otherRegion.getLeftExtreme();
		m_rightExtreme=otherRegion.getRightExtreme();
		m_topExtreme=otherRegion.getTopExtreme();
		m_bottomExtreme=otherRegion.getBottomExtreme();
	}
	public double getLeftExtreme(){return m_leftExtreme;}
	public double getRightExtreme(){return m_rightExtreme;}
	public double getTopExtreme(){return m_topExtreme;}
	public double getBottomExtreme(){return m_bottomExtreme;}
	public RiffAbsolutePoint getMidPoint(){
		if(m_midPoint==null){
			m_midPoint = new RiffEuclideanPoint(null, getLeftExtreme()+((getRightExtreme()-getLeftExtreme())/2),  getBottomExtreme()+((getTopExtreme()-getBottomExtreme())/2), 0);
		}
		return m_midPoint;
	}
	public List getPoints(){return new LinkedList(m_points);}
	public void addPoint(RiffAbsolutePoint point){
		testExtrema(point);
		m_points.add(point);
	}
	public void removePoint(int pointNum){
		RiffAbsolutePoint point = (RiffAbsolutePoint)m_points.get(pointNum);
		removePoint(point);
	}
	public void removePoint(RiffAbsolutePoint point){
		if(!m_points.contains(point)){return;}
		m_points.remove(point);
		if(point.getX()==m_leftExtreme||point.getX()==m_rightExtreme||point.getY()==m_topExtreme||point.getY()==m_bottomExtreme){
			recalculateExtrema();
		}
	}
	private void testExtrema(RiffAbsolutePoint point){
		if(point.getX()<m_leftExtreme){
			m_leftExtreme=point.getX();
		}
		if(point.getX()>m_rightExtreme){
			m_rightExtreme=point.getX();
		}
		if(point.getY()<m_bottomExtreme){
			m_bottomExtreme=point.getY();
		}
		if(point.getY()>m_topExtreme){
			m_topExtreme=point.getY();
		}
	}
	private void resetExtrema(){
		m_leftExtreme=java.lang.Double.POSITIVE_INFINITY;
		m_rightExtreme=java.lang.Double.NEGATIVE_INFINITY;
		m_topExtreme=m_rightExtreme;
		m_bottomExtreme=m_leftExtreme;
	}
	private void recalculateExtrema(){
		resetExtrema();
		for(int i=0;i<m_points.size();i++){
			testExtrema((RiffAbsolutePoint)m_points.get(i));
		}
	}
	public String toString(){
		String string = new String();
		string += "Discrete Region: ";
		string += "\nPoints list: " + RiffToolbox.displayList(m_points, "point");
		string += "\nLeft Extrema: " + m_leftExtreme;
		string += "\nRight Extrema: " + m_rightExtreme;
		string += "\nTop Extrema: " + m_topExtreme;
		string += "\nBottom Extrema: " + m_bottomExtreme;
		return string;
	}
	public boolean equals(Object o){
		return(m_points.containsAll(((DiscreteRegion)o).getPoints())&&((List)((DiscreteRegion)o).getPoints()).containsAll(m_points));
	}
	public int compareTo(Object o){
		return getMidPoint().compareTo(((DiscreteRegion)o).getMidPoint());
	}
	public int hashCode(){
		return m_points.hashCode();
	}
}
