public class InvalidTradeLinkException extends TradeLinkException{
	private TradeLink m_link;
	public InvalidTradeLinkException(TradeLink link){
		m_link = link;
	}
	public String getMessage(){
		String string = new String();
		string += "The following trade link has a source and destination that is identical, making the angle impossible to calculate.";
		string += "\nTrade Link: " + m_link;
		return string;
	}
}
