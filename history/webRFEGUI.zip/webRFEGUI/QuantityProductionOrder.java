import java.util.*;

public class QuantityProductionOrder extends Order{
	private double m_totalQuantity, m_remainingQuantity;
	private Brand m_product;
	private static ProductionAction m_action;
	private ActiveAsset m_activeAsset;
	private OrderStatus m_orderStatus;
	public QuantityProductionOrder(ActiveAsset activeAsset, Brand product, double totalQuantity){
		m_product = product;
		m_remainingQuantity = m_totalQuantity = totalQuantity;
		m_activeAsset = activeAsset;
	}
	public Brand getBrand(){return m_product;}
	public Commodity getCommodity(){return m_product.getCommodity();}
	public double getTotalQuantity(){return m_totalQuantity;}
	public double getRemainingQuantity(){return m_remainingQuantity;}
	public void setQuantity(double quant){
		m_remainingQuantity -= m_totalQuantity - quant;
	}
	public OrderStatus getStatus(){return m_orderStatus;}
	public void execute() throws OrderException{
		if(m_totalQuantity != -1 && m_remainingQuantity < 0){m_orderStatus=new OrderStatus(OrderStatus.STATUS_COMPLETE);return;}
		if(QuantityProductionOrder.m_action == null){
			ProductionAction action = new ProductionAction();
			RiffActions.addAction(action);
			QuantityProductionOrder.m_action = action;
		}
		QuantityProductionOrder.m_action.execute(this);
	}
	public ActiveAsset getActiveAsset(){return m_activeAsset;}
	public String toString(){
		String string = new String();
		string += "Order: QuantityProductionOrder";
		string += "\nThe active asset listed below is to produce " + getTotalQuantity() + " units of the product listed below.";
		string += "\nThe order has " + getRemainingQuantity() + " units remaining to be made.";
		string += "\nActive asset: " + m_activeAsset;
		string += "\nProduct: " + m_product;
		return string;
	}
}
