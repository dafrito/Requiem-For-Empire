/*import java.util.*;

public class DiscreteRegionBinaryNode{
	private DiscreteRegionBinaryNode m_leftNode;
	private DiscreteRegionBinaryNode m_internalNode;
	private DiscreteRegionBinaryNode m_rightNode;
	private List m_leftSurfaceList;
	private List m_rightSurfaceList;
	private boolean m_isLongitudeMap;
	double m_value;
	public DiscreteRegionBinaryNode(RiffSurface surface, double value, boolean isLongitude){
		m_value=value;
		m_isLongitudeMap=isLongitude;
		if(m_isLongitudeMap == true){
			
		}
	}
	public DiscreteRegionBinaryNode getLeftNode(){return m_leftNode;}
	public DiscreteRegionBinaryNode getRightNode(){return m_rightNode;}
	public void inputValue(RiffSurface surface){
		if(m_isLongitudeMap){
			if(m_value < surface.getLeftExtreme()){
				if(m_rightNode != null){
					m_rightNode.inputValue(surface);
				}else{
					m_rightNode = new DiscreteRegionBinaryNode(surface, surface.getLeftExtreme(), true);
				}
			}else if(m_value > surface.getRightExtreme()){
				if(m_rightNode != null){
					m_leftNode.inputValue(surface);
				}else{
					m_leftNode = new DiscreteRegionBinaryNode(surface, surface.getRightExtreme(), true);
				}
			}
			if(m_value > surface.getLeftExtreme() && m_value < surface.getRightExtreme()){
				m_internalNode.inputValue(surface);
			}
		}
		
		/*if(m_isLongitudeMap){
			if(m_value < surface.getLeftExtreme()){
				if(m_rightNode != null){
					m_rightNode.inputValue(surface);
				}else{
					m_rightNode = new DiscreteRegionBinaryNode(surface, surface.getLeftExtreme(), true);
				}
			}else if(m_value > surface.getRightExtreme()){
				if(m_rightNode != null){
					m_leftNode.inputValue(surface);
				}else{
					m_leftNode = new DiscreteRegionBinaryNode(surface, surface.getRightExtreme(), true);
				}
			}
			if(m_value > surface.getLeftExtreme() && m_value < surface.getRightExtreme()){
				m_internalNode.inputValue(surface);
			}
		}else{
			if(m_value < surface.getBottomExtreme()){
				if(m_rightNode != null){
					m_rightNode.inputValue(surface);
				}else{
					m_rightNode = new DiscreteRegionBinaryNode(surface, surface.getBottomExtreme(), false);
				}
			}else if(m_value > surface.getTopExtreme()){
				if(m_rightNode != null){
					m_leftNode.inputValue(surface);
				}else{
					m_leftNode = new DiscreteRegionBinaryNode(surface, surface.getTopExtreme(), false);
				}
			}
			else if(m_value > surface.getBottomExtreme() && m_value < surface.getTopExtreme()){
				m_surfaceList.add(surface);
			}
		}
	}
}*/
