public class RiffDataPoint implements Comparable{
	protected RiffDataPoint m_point;
	protected Location m_referenceLocation;
	protected String m_pointName;
	public RiffDataPoint(){}
	public RiffDataPoint(RiffDataPoint point, Location referenceLocation){
		m_point = point;
		m_referenceLocation = referenceLocation;
	}
	public String getName(){return m_pointName;}
	public void setName(String name){m_pointName=name;}
	public Location getReferenceLocation(){return m_referenceLocation;}
	public boolean setReferenceLocation(Location referenceLocation){m_referenceLocation = referenceLocation;return true;}
	public double getOverlap(RiffDataPoint point){return m_point.getOverlap(point);}
	public RiffAbsolutePoint getAbsolutePosition(){return m_point.getAbsolutePosition();}
	public void iterate(int iterationTime){m_point.iterate(iterationTime);}
	public int compareTo(Object obj){
		return getAbsolutePosition().compareTo(((RiffDataPoint)obj).getAbsolutePosition());
	}
	public boolean equals(Object obj){
		return getAbsolutePosition().equals(((RiffDataPoint)obj).getAbsolutePosition());
	}
	public String toString(){
		String string = new String();
		string += "RiffDataPoint:";
		if(m_referenceLocation != null){
			string += "\nReference Location: " + m_referenceLocation;
			string += "\nPoint: " + m_point;
		}else{string += "\nThis is a root location.";}
		return string;
	}
}
