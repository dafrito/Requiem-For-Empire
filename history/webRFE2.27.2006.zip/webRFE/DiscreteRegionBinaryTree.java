public class DiscreteRegionBinaryTree{
	public DiscreteRegionBinaryTree(){
		
	}
}
