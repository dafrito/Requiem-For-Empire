public class DiscreteTerrainRegion{
	private Terrain m_terrain;
	private DiscreteRegion m_region;
	private double m_multiplier;
	public DiscreteTerrainRegion(Terrain terrain, DiscreteRegion region, double multiplier){
		m_terrain=terrain;
		m_region=region;
		m_multiplier=multiplier;
	}
	public Terrain getTerrain(){return m_terrain;}
	public DiscreteRegion getRegion(){return m_region;}
	public double getMultiplier(){return m_multiplier;}
}
