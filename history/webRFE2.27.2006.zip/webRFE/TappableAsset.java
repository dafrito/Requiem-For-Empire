import java.util.*;

public class TappableAsset extends ActiveAsset{
	private Brand m_lotToCreate;
	private List m_returnableAssets;
	private static final String m_TappableAssetString = new String("Tappable Asset");
	public TappableAsset(Brand brand){
		super();
		m_lotToCreate = brand;
	}
	public void iterate(int iterationTime){
	}
	public String getAssetType(){return TappableAsset.m_TappableAssetString;}
	public String toString(){
		String string = new String();
		string += "Tappable Asset: ";
		string += "\nAssets: " + m_assetMap;
		string += "\nLot to create: " + m_lotToCreate;
		return string;
	}
	public List getAssetsList(Commodity comm, double quantity){
		return m_assetMap.getLotList(comm);
	}
	public List getAssetsList(Commodity comm){
		return m_assetMap.getLotList(comm);
	}
	public void removeAsset(Asset asset){
		m_assetMap.removeAsset(asset);
	}
	public void removeAssets(List list){
		for(int i=0;i<list.size();i++){
			removeAsset((Asset)list.get(i));
		}
	}
	public void addAssets(List listGoods) throws CommodityMapException{
		for(int i=0;i<listGoods.size();i++){
			addAsset((Asset)listGoods.get(i));
		}
	}
	public void addAsset(Asset asset) throws CommodityMapException{
		if(asset.getAssetType().equals("Lot") && ((Lot)asset).getBrand() == m_lotToCreate){
			if(m_returnableAssets == null){
				m_returnableAssets = new LinkedList();
			}
			m_returnableAssets.add(asset);
		}else{
			m_assetMap.addAsset(asset);
		}
	}
	public List tap(int iterationTime) throws OrderException{
		if(m_returnableAssets != null){
			m_returnableAssets.clear();
		}
		QuantityProductionOrder order = new QuantityProductionOrder(this, m_lotToCreate, -1);
		order.execute();
		return m_returnableAssets;
	}
}
