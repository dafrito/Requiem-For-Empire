public class PlanetRegionMap{
	private Planet m_planet;
	private double m_gradientPrecision;
	public PlanetRegionMap(Planet planet, double gradientPrecision){
		m_planet=planet;
		m_gradientPrecision=gradientPrecision;
	}
	public void calculateRegions(){
		
	}
}
