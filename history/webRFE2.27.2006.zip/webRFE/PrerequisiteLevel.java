public class PrerequisiteLevel{
	private Commodity m_prerequisite;
	private double m_quantity;
	public PrerequisiteLevel(Commodity pre, double quantity){
		m_prerequisite = pre;
		m_quantity = quantity;
	}
	public double getQuantity(){return m_quantity;}
	public Commodity getCommodity(){return m_prerequisite;}
	public void setQuantity(double quantity){m_quantity = quantity;}
	public int hashCode(){return m_prerequisite.hashCode();}
}
