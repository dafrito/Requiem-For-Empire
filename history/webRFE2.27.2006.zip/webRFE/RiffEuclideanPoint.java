public class RiffEuclideanPoint extends RiffAbsolutePoint{
	private double m_x, m_y, m_z;
	public RiffEuclideanPoint(Location referenceLocation, double x, double y, double z){
		this(null, referenceLocation,x,y,z);
	}
	public RiffEuclideanPoint(String name, Location referenceLocation, double x, double y, double z){
		super(null, referenceLocation);
		m_pointName = name;
		m_x=x;
		m_y=y;
		m_z=z;
	}
	public boolean equals(Object o){
		RiffEuclideanPoint testPoint = (RiffEuclideanPoint)((RiffDataPoint)o).getAbsolutePosition();
		if(m_x==testPoint.getX()&&m_y==testPoint.getY()&&m_z==testPoint.getZ()){
			return true;
		}
		return false;
	}
	public int compareTo(Object o){
		RiffEuclideanPoint testPoint = (RiffEuclideanPoint)((RiffDataPoint)o).getAbsolutePosition();
		if(m_x>testPoint.getX()){return 1;}
		if(m_x<testPoint.getX()){return -1;}
		if(m_y>testPoint.getY()){return 1;}
		if(m_y<testPoint.getY()){return -1;}
		if(m_z>testPoint.getZ()){return 1;}
		if(m_z<testPoint.getZ()){return -1;}
		return 0;
	}
	public void setX(double x){m_x=x;}
	public void setY(double y){m_y=y;}
	public void setZ(double z){m_z=z;}
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public String toString(){
		String string = new String();
		string += "RiffEuclideanPoint: " + m_pointName;
		string += "\nX: " + m_x;
		string += "\nY: " + m_y;
		string += "\nZ: " + m_z;
		return string;
	}
}
