public abstract class RiffAbsolutePoint extends RiffDataPoint implements Comparable{
	public RiffAbsolutePoint(){}
	public RiffAbsolutePoint(RiffDataPoint point, Location referenceLocation){
		super(point,referenceLocation);
	}
	public abstract double getX();
	public abstract double getY();
	public abstract int compareTo(Object o);
	public void iterate(int iterationTime){}
	public abstract boolean equals(Object o);
	public RiffAbsolutePoint getAbsolutePosition(){return this;}
}
