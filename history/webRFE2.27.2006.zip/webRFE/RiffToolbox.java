import java.lang.Math;
import java.util.Random;
import java.util.*;
import java.awt.Polygon;
import java.awt.geom.Line2D.Double;

public class RiffToolbox{
	public static String printUnderline(String baseString, String printChar){
		String string = new String(baseString + "\n");
		for(int i = baseString.length(); i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	public static String printLine(String symbol, int times){
		String string = new String();
		for(int i=0;i<times;i++){
			string += symbol;
		}
		string += "\n";
		return string;
	}
	private static Random m_random;
	public static Random getRandom(){
		if(RiffToolbox.m_random == null){
			RiffToolbox.m_random = new Random();
		}
		return RiffToolbox.m_random;
	}
	//(y - y0) (x1 - x0) - (x - x0) (y1 - y0)
	// Y is latitude
	// X is longitude
	public static boolean isPolygonConvex(DiscreteRegion region){
		List pointList = region.getPoints();
		Boolean myBool = null;
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint linePointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint linePointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			for(int k=0;k<pointList.size();k++){
				RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(k);
				double value = (testPoint.getY() - linePointA.getY())*(linePointB.getX() - linePointA.getX()) - (testPoint.getX() - linePointA.getX())*(linePointB.getY() - linePointA.getY());
				if(myBool == null){
					if(value > 0){
						myBool = new Boolean(true);
					}else if(value < 0){
						myBool = new Boolean(false);
					}
				}else{
					if(value > 0){
						if(myBool.booleanValue() == true){continue;}
						return false;
					}else if(value < 0){
						if(myBool.booleanValue() == false){continue;}
						return false;
					}else{
						continue;
					}
				}
			}
		}
		return true;
	}
	public static List convertPolyToConvex(List polygons){
		List list = new LinkedList();
		for(int i=0;i<polygons.size();i++){
			list.addAll(RiffToolbox.convertPolyToConvex((DiscreteRegion)polygons.get(i)));
		}
		return list;
	}
	public static DiscreteRegion optimizePolygon(DiscreteRegion originalRegion){
		DiscreteRegion region = new DiscreteRegion(originalRegion);
		List pointList = region.getPoints();
		// Fail if not at least a triangle
		if(region.getPoints().size()<3){
			LogManager.writeLog("RiffToolbox", "DiscreteRegion invalid because it has less than 3 points.");
			return null;
		}
		// Remove all overlapping points.
		for(int i=0;i<pointList.size();i++){
			for(int j=1;j<pointList.size();j++){
				if(i==j){continue;}
				if(i!=j&&((RiffAbsolutePoint)pointList.get(i)).equals(pointList.get(j))){
					pointList.remove(j);j--;i--;
				}
			}
		}
		// Remove all unnecessary points.
		for(int i=0;i<pointList.size();i++){
			if(pointList.isEmpty()==true){return null;}
			LogManager.writeLog("RiffToolbox", "i: " + i + ", size: " + pointList.size());
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)pointList.get(i);
			for(int j=1;j<pointList.size();j++){
				if(i==j){continue;}
				RiffAbsolutePoint pointB = (RiffAbsolutePoint)pointList.get(j);
				LogManager.writeLog("RiffToolbox", "1st: " + pointA);
				LogManager.writeLog("RiffToolbox", "2nd: " + pointB);
				double slope = RiffToolbox.getSlope(pointA, pointB);
				LogManager.writeLog("RiffToolbox", "Slope: " + slope);
				for(int k=0;k<pointList.size();k++){
					if(k==i || k==j){continue;}
					RiffAbsolutePoint pointC = (RiffAbsolutePoint)pointList.get(k);
					double testSlope = RiffToolbox.getSlope(pointA, pointC);
					LogManager.writeLog("RiffToolbox", "1st: " + pointA);
					LogManager.writeLog("RiffToolbox", "3rd: " + pointC);
					LogManager.writeLog("RiffToolbox", "Test slope: " + testSlope);
					if(testSlope==slope){
						double y = slope * (pointC.getX() - pointA.getX()) + pointA.getY();
						if(y==pointC.getY()){
							if(RiffToolbox.getDistance(pointA, pointB) + RiffToolbox.getDistance(pointB, pointC) == RiffToolbox.getDistance(pointA, pointC)){
								System.out.println("Attempting to remove this point:" + pointB);
								System.out.println("In order to create the more optimal line with these points:");
								System.out.println("First point: " + pointA);
								System.out.println("Second point: " + pointC);
								if(RiffToolbox.confirmInteriorLine(pointA, pointC, region)){
									LogManager.writeLog("RiffToolbox", "Removing this point: " + pointB);
									pointList.remove(j);
									j--;
								}
								continue;
							}
						}else if(RiffToolbox.getDistance(pointB, pointC) + RiffToolbox.getDistance(pointA, pointC) == RiffToolbox.getDistance(pointA, pointB)){
							System.out.println("Attempting to remove this point:" + pointC);
							System.out.println("In order to create the more optimal line with these points:");
							System.out.println("First point: " + pointA);
							System.out.println("Second point: " + pointB);
							if(RiffToolbox.confirmInteriorLine(pointA, pointB, region)){
								LogManager.writeLog("RiffToolbox", "Removing this point: " + pointC);
								pointList.remove(k);
								k--;
							}
							continue;
						}else if(RiffToolbox.getDistance(pointB, pointA) + RiffToolbox.getDistance(pointA, pointC) == RiffToolbox.getDistance(pointC, pointB)){
							System.out.println("Attempting to remove this point:" + pointA);
							System.out.println("In order to create the more optimal line with these points:");
							System.out.println("First point: " + pointC);
							System.out.println("Second point: " + pointB);
							if(RiffToolbox.confirmInteriorLine(pointC, pointB, region)){
								LogManager.writeLog("RiffToolbox", "Removing this point: " + pointA);
								pointList.remove(i);
								i--;
							}
							continue;
						}
					}
				}
			}
		}
		// Fail if not at least a triangle
		if(region.getPoints().size()<3){
			LogManager.writeLog("RiffToolbox", "DiscreteRegion invalid because it has less than 3 points.");
			return null;
		}
		return region;
	}
	public static boolean confirmInteriorLine(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, DiscreteRegion region){
		List pointList = region.getPoints();
		if(pointA.equals(pointB)){return false;}
		double slope = RiffToolbox.getSlope(pointA, pointB);
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint testPointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			if((pointA.equals(testPointA) || pointA.equals(testPointB))||(pointB.equals(testPointA) || pointB.equals(testPointB))){continue;}
			double testSlope = RiffToolbox.getSlope(testPointA, testPointB);
			double xIntersection = ((-slope * pointA.getX() + pointA.getY()) - (-testSlope * testPointA.getX() + testPointA.getY()))/(testSlope-slope);
			if(xIntersection < Math.min(testPointA.getX(), testPointB.getX())){continue;}
			if(xIntersection > Math.max(testPointA.getX(), testPointB.getX())){continue;}
			if(xIntersection < Math.min(pointA.getX(), pointB.getX())){continue;}
			if(xIntersection > Math.max(pointA.getX(), pointB.getX())){continue;}
			double yIntersection = slope * xIntersection + (-slope * pointA.getX() + pointA.getY());
			if(yIntersection < Math.min(testPointA.getY(), testPointB.getY())){continue;}
			if(yIntersection > Math.max(testPointA.getY(), testPointB.getY())){continue;}
			if(yIntersection < Math.min(pointA.getY(), pointB.getY())){continue;}
			if(yIntersection > Math.max(pointA.getY(), pointB.getY())){continue;}
			System.out.println("Failed pointA: " + pointA);
			System.out.println("Failed pointB: " + pointB);
			System.out.println("Intersected pointA: " + testPointA);
			System.out.println("Intersected pointB: " + testPointB);
			System.out.println("X-intercept: " + xIntersection);
			System.out.println("Y-intercept: " + yIntersection);
			return false;
		}
		return true;
	}
	public static Polygon getPolygonFromDiscreteRegion(DiscreteRegion region){
		Polygon poly = new Polygon();
		for(int i=0;i<region.getPoints().size();i++){
			poly.addPoint((int)((RiffAbsolutePoint)region.getPoints().get(i)).getX(),(int)((RiffAbsolutePoint)region.getPoints().get(i)).getY());
		}
		return poly;
	}
	public static List getLineListFromDiscreteRegion(DiscreteRegion region){
		List list = new LinkedList();
		for(int i=0;i<region.getPoints().size();i++){
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)region.getPoints().get(i);
			RiffAbsolutePoint pointB = (RiffAbsolutePoint)region.getPoints().get((i+1)%region.getPoints().size());
			list.add(new java.awt.geom.Line2D.Double(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY()));
		}
		return list;
	}
	public static double getSlope(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		return (pointB.getY()-pointA.getY())/(pointB.getX()-pointA.getX());
	}
	public static List convertPolyToConvex(DiscreteRegion originalRegion){
		DiscreteRegion region = RiffToolbox.optimizePolygon(originalRegion);
		if(region==null){return null;}
		List convexPolygons = new LinkedList();
		if(RiffToolbox.isPolygonConvex(region)==true){
			List list = new LinkedList();
			list.add(region);
			return list;
		}
		DiscreteRegion testRegion = new DiscreteRegion();
		List pointList = region.getPoints();
		for(int i=0;i<pointList.size();i++){
			for(int j=0;j<pointList.size();j++){
				boolean alreadyCreated = false;
				if(i==j || pointList.get(i).equals(pointList.get(j)) || pointList.get((i+1)%pointList.size()).equals(pointList.get(j))){continue;}
				if(RiffToolbox.confirmInteriorLine((RiffAbsolutePoint)pointList.get(i),(RiffAbsolutePoint)pointList.get(j),region)==false){continue;}
				if(RiffToolbox.confirmInteriorLine((RiffAbsolutePoint)pointList.get((i+1)%pointList.size()),(RiffAbsolutePoint)pointList.get(j),region)==false){continue;}
				testRegion.addPoint((RiffAbsolutePoint)pointList.get(i));
				testRegion.addPoint((RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
				testRegion.addPoint((RiffAbsolutePoint)pointList.get(j));
				for(int k=0;k<convexPolygons.size();k++){
					if(testRegion.equals(convexPolygons.get(k))){alreadyCreated=true;break;}
				}
				if(alreadyCreated){continue;}
				List pointSideList = RiffToolbox.getPointSideList(region, (RiffAbsolutePoint)pointList.get(i), (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
				List leftSideList = (List)pointSideList.get(0);
				Boolean onLeftSideFlag;
				for(int q=0;q<testRegion.size();q++){
					if(onLeftSideFlag==null){
						onLeftSideFlag = new Boolean(leftSideList.contains(testRegion.get(q)));
						continue;
					}
					if(leftSideList.contains(testRegion.get(q))){
						if(onLeftSideFlag.booleanValue() == true){continue;
						}else{onLeftSideFlag=null;break;}
					}else{
						if(onLeftSideFlag.booleanValue() == false){continue;
						}else{onLeftSideFlag=null;break;}
					}
				}
				List pointSideList = RiffToolbox.getPointSideList(region, (RiffAbsolutePoint)pointList.get(i), (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
				List leftSideList = (List)pointSideList.get(0);
				Boolean onLeftSideFlag;
				for(int q=0;q<testRegion.size();q++){
					if(onLeftSideFlag==null){
						onLeftSideFlag = new Boolean(leftSideList.contains(testRegion.get(q)));
						continue;
					}
					if(leftSideList.contains(testRegion.get(q))){
						if(onLeftSideFlag.booleanValue() == true){continue;
						}else{onLeftSideFlag=null;break;}
					}else{
						if(onLeftSideFlag.booleanValue() == false){continue;
						}else{onLeftSideFlag=null;break;}
					}
				}
				List pointSideList = RiffToolbox.getPointSideList(region, (RiffAbsolutePoint)pointList.get(i), (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
				List leftSideList = (List)pointSideList.get(0);
				Boolean onLeftSideFlag;
				for(int q=0;q<testRegion.size();q++){
					if(onLeftSideFlag==null){
						onLeftSideFlag = new Boolean(leftSideList.contains(testRegion.get(q)));
						continue;
					}
					if(leftSideList.contains(testRegion.get(q))){
						if(onLeftSideFlag.booleanValue() == true){continue;
						}else{onLeftSideFlag=null;break;}
					}else{
						if(onLeftSideFlag.booleanValue() == false){continue;
						}else{onLeftSideFlag=null;break;}
					}
				}
			}
		}
		return convexPolygons;
	}
	public static List getPointSideList(DiscreteRegion region, RiffAbsolutePoint linePointA, RiffAbsolutePoint linePointB){
		List leftPoints = new LinkedList();
		List rightPoints = new LinkedList();
		for(int k=0;k<pointList.size();k++){
			RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(k);
			double value = (testPoint.getY() - linePointA.getY())*(linePointB.getX() - linePointA.getX()) - (testPoint.getX() - linePointA.getX())*(linePointB.getY() - linePointA.getY());
			if(value > 0){
				leftPoints.add(testPoint);
			}else{
				rightPoints.add(testPoint);
			}
		}
		List fullList = new Vector();
		fullList.add(leftPoints);
		fullList.add(rightPoints);
	}
	public static String printBorder(String baseString, String printChar){
		String string = new String();
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n " + baseString + "\n";
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	public static int compareDoubles(double firstDouble, double secondDouble){
		if(firstDouble < secondDouble){
			return -1;
		}if(firstDouble > secondDouble){
			return 1;
		}return 0;
	}
	public static double convertDegreesToRadians(double degrees){return degrees * Math.PI/180;}	
	public static double getDistance(RiffDataPoint firstPoint, RiffDataPoint secondPoint){
		return getDistance(firstPoint.getAbsolutePosition(), secondPoint.getAbsolutePosition());
	}
	public static double getDistance(RiffAbsolutePoint firstPoint, RiffAbsolutePoint secondPoint){
		return Math.sqrt(Math.pow(secondPoint.getX()-firstPoint.getX(), 2) + Math.pow(secondPoint.getY()-firstPoint.getY(),2));
	}
	public static double getDistance(RiffSpherePoint firstPoint, RiffSpherePoint secondPoint){
		Planet planet = (Planet)firstPoint.getReferenceLocation();
		double firstLat = Math.toRadians(firstPoint.getLatitudeDegrees());
		double secondLat = Math.toRadians(secondPoint.getLatitudeDegrees());
		double firstLong = Math.toRadians(firstPoint.getLongitudeDegrees());
		double secondLong = Math.toRadians(secondPoint.getLongitudeDegrees());
		double temp = Math.pow(Math.sin((secondLat - firstLat)/2),2) + Math.cos(firstLat) * Math.cos(secondLat) * Math.pow(Math.sin((secondLong - firstLong)/2),2);
		return planet.getRadius() * 2 * Math.asin(Math.min(1, Math.sqrt(temp)));
	}
	public static double getDistance(RiffEuclideanPoint firstPoint, RiffEuclideanPoint secondPoint){
		//( (x-a)2 + (y - b)2 + (z - c)2 )1/2
		double testDouble = Math.sqrt(Math.pow((secondPoint.getX() - firstPoint.getX()), 2) + Math.pow((secondPoint.getY() - firstPoint.getY()), 2) + Math.pow((secondPoint.getZ() - firstPoint.getZ()), 2));
		return testDouble;
	}
}
