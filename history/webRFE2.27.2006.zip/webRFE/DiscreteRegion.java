import java.util.*;

public class DiscreteRegion{
	List m_points;
	public DiscreteRegion(){
		m_points = new Vector();
	}
	public DiscreteRegion(DiscreteRegion otherRegion){
		m_points = new Vector(otherRegion.getPoints());
	}
	public void addPoint(RiffAbsolutePoint point){m_points.add(point);}
	public List getPoints(){return m_points;}
	public String toString(){
		String string = new String();
		string += "Discrete Region: ";
		if(m_points.size() > 1){string += "\nThis region has " + m_points.size() + " points:\n";
		}else if(m_points.size() == 1){string += "\nThis region has 1 point:\n";
		}else{
			string += "\nThis region has no points.";
			return string;
		}
		for(int i=0;i<m_points.size();i++){
			string += "\n" + (RiffDataPoint)m_points.get(i);
		}
		return string;
	}
}
