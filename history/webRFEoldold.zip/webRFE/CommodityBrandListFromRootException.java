public class CommodityBrandListFromRootException extends CommodityMapException{
	private CommodityMapNode m_node;
	private Brand m_brand;
	public CommodityBrandListFromRootException(CommodityMapNode node, Brand brand){
		m_node = node;
		m_brand = brand;
	}
	public String getMessage(){
		String string = new String();
		string += "An attempt was made to retrieve a list of lots from the root node of the commodity map.";
		string += "\nNode: " + m_node;
		string += "\nBrand: " + m_brand;
		return string;
	}
}
