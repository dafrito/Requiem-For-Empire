import javax.swing.*; // For JPanel, etc.
import java.awt.*;           // For Graphics, etc.
import java.awt.geom.*;      // For Ellipse2D, etc.
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

public class RiffOverlappingGUI extends JPanel implements KeyListener{
	private int m_polygonCycler;
	private boolean m_cyclePolygons, m_showLabels;
	private String m_statusText;
	private java.util.List m_regions = new LinkedList();
	private SplitterThread m_thread;
	private DiscreteRegionBSPNode m_root;
	public RiffOverlappingGUI(){
		m_regions = RiffToolbox.getDiscreteRegionsFromFile("dump.txt");
		m_statusText=new String();
		m_showLabels=true;
		setFocusable(true);
		addKeyListener(this);
	}
	public synchronized void setStatusText(String string){m_statusText=string;repaint();}
	public void paintComponent(Graphics g){
		clear(g);
		Graphics2D g2d = (Graphics2D)g;
		if(m_thread!=null&&!m_thread.isAlive()){
			m_root = m_thread.getRoot();
			if(m_root!=null){
				m_regions = m_root.getTempList();
			}
		}
		/*java.util.List allRegions = new LinkedList();
		if(m_cyclePolygons){
			allRegions.addAll(m_root.getTempList());
			allRegions.addAll(m_root.getPolyList());
			System.out.println(allRegions.size());
			if(m_polygonCycler<0){m_polygonCycler=allRegions.size()-1;}
			int i=m_polygonCycler%allRegions.size();
			m_polygonCycler=i;
			g2d.setColor(new Color(.25f, .25f + RiffToolbox.getRandom().nextFloat()%.75f, .25f + RiffToolbox.getRandom().nextFloat()%.75f, .25f + RiffToolbox.getRandom().nextFloat()%.75f));
			g2d.fillPolygon(RiffGraphicsToolbox.getPolygonFromDiscreteRegion((DiscreteRegion)allRegions.get(i)));
			if(m_showLabels){
				java.util.List pointList = ((DiscreteRegion)allRegions.get(i)).getPoints();
				for(int j=0;j<pointList.size();j++){
					g2d.setColor(Color.BLACK);
					if(((RiffAbsolutePoint)pointList.get(j)).getName()!=null){
						g2d.drawString(((RiffAbsolutePoint)pointList.get(j)).getName(),(int)((RiffAbsolutePoint)pointList.get(j)).getX(),(int)((RiffAbsolutePoint)pointList.get(j)).getY());
					}
				}
			}
			return;
		}
		if(m_root!=null){
			allRegions.addAll(m_root.getPolyList());
		} 
		for(int i=0;i<allRegions.size();i++){
			java.util.List pointList = ((DiscreteRegion)allRegions.get(i)).getPoints();
			if(m_showLabels){
				for(int j=0;j<pointList.size();j++){
					g2d.setColor(Color.BLACK);
					if(((RiffAbsolutePoint)pointList.get(j)).getName()!=null){
						g2d.drawString(((RiffAbsolutePoint)pointList.get(j)).getName(),(int)((RiffAbsolutePoint)pointList.get(j)).getX(),(int)((RiffAbsolutePoint)pointList.get(j)).getY());
					}
				}
			}
			g2d.setColor(Color.YELLOW);
			g2d.fillPolygon(RiffGraphicsToolbox.getPolygonFromDiscreteRegion((DiscreteRegion)allRegions.get(i)));
		}*/
		/*allRegions.clear();
		if(m_root!=null){
			allRegions.addAll(m_root.getTempList());
		}
		for(int i=0;i<allRegions.size();i++){
			java.util.List pointList = ((DiscreteRegion)allRegions.get(i)).getPoints();
			if(m_showLabels){
				for(int j=0;j<pointList.size();j++){
					g2d.setColor(Color.BLACK);
					if(((RiffAbsolutePoint)pointList.get(j)).getName()!=null){
						g2d.drawString(((RiffAbsolutePoint)pointList.get(j)).getName(),(int)((RiffAbsolutePoint)pointList.get(j)).getX(),(int)((RiffAbsolutePoint)pointList.get(j)).getY());
					}
				}
			}
			g2d.setColor(Color.BLUE);
			g2d.fillPolygon(RiffGraphicsToolbox.getPolygonFromDiscreteRegion((DiscreteRegion)allRegions.get(i)));
		}*/
		m_statusText = "";
		java.util.List allRegions = new LinkedList();
		if(m_root!=null){
			allRegions.addAll(m_root.getPolyList());
		}else{
			allRegions =m_regions;
		}
		for(int i=0;i<allRegions.size();i++){
			if(m_cyclePolygons){
				if(m_polygonCycler<0){m_polygonCycler=allRegions.size()-1;}
				i=m_polygonCycler%allRegions.size();
				m_polygonCycler=i;
				m_statusText += "(Now on polygon " + i + ")";
			}
			java.util.List pointList = ((DiscreteRegion)allRegions.get(i)).getPoints();
			if(m_showLabels){
				for(int j=0;j<pointList.size();j++){
					g2d.setColor(Color.BLACK);
					if(((RiffAbsolutePoint)pointList.get(j)).getName()!=null){
						g2d.drawString(((RiffAbsolutePoint)pointList.get(j)).getName(),(int)((RiffAbsolutePoint)pointList.get(j)).getX(),(int)((RiffAbsolutePoint)pointList.get(j)).getY());
					}
				}
			}
			g2d.setColor(new Color(.25f, .25f + RiffToolbox.getRandom().nextFloat()%.75f, .25f + RiffToolbox.getRandom().nextFloat()%.75f, .25f + RiffToolbox.getRandom().nextFloat()%.75f));
			g2d.fillPolygon(RiffGraphicsToolbox.getPolygonFromDiscreteRegion((DiscreteRegion)allRegions.get(i)));
			if(m_cyclePolygons){break;}
		}
		if(m_thread!=null){m_statusText += m_thread.getStatusText();}
		g2d.setColor(Color.BLACK);
		g2d.drawString(m_statusText, 5, getHeight()-5);
	}
	public void keyTyped(KeyEvent keyEvent){}
	public void keyReleased(KeyEvent keyEvent){}
	public synchronized void keyPressed(KeyEvent keyEvent){
		switch(keyEvent.getKeyCode()){
			case KeyEvent.VK_LEFT:
			m_polygonCycler--;
			break;
			case KeyEvent.VK_RIGHT:
			m_polygonCycler++;
			break;
			case KeyEvent.VK_CAPS_LOCK:
			try{
				String string = RiffToolbox.getParseableDiscreteRegions(m_regions);
				FileWriter writer = new FileWriter("quickDump.txt");
				writer.write(string);
				writer.close();
			}catch(IOException ex){
				System.out.println(ex);
			}
			break;
			case KeyEvent.VK_T:
			RiffToolbox.toggleDebugSpew();
			break;
			case KeyEvent.VK_SPACE:
			m_cyclePolygons = !m_cyclePolygons;
			break;
			case KeyEvent.VK_CONTROL:
			m_showLabels = !m_showLabels;
			break;
			case KeyEvent.VK_ENTER:
			m_thread = new SplitterThread(this, m_root, m_regions,false);
			m_thread.start();
			break;
			case KeyEvent.VK_BACK_QUOTE:
			System.out.println(RiffToolbox.displayList(m_regions));
			break;
		}
		repaint();
	}
	protected void clear(Graphics g){super.paintComponent(g);}
	public static void main(String[] args) {
	 	JFrame frame = new JFrame("RiffOverlappingGUI");
	 	frame.setSize(500, 500);
		frame.setContentPane(new RiffOverlappingGUI());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
