public abstract class RiffAbsolutePoint extends RiffDataPoint implements Comparable{
	public RiffAbsolutePoint(){}
	public RiffAbsolutePoint(RiffDataPoint point, Location referenceLocation){
		super(point,referenceLocation);
	}
	public abstract double getX();
	public abstract double getY();
	public abstract void setX(double x);
	public abstract void setY(double y);
	public abstract int compareTo(Object o);
	public void iterate(int iterationTime){}
	public boolean equals(Object o){
		RiffAbsolutePoint testPoint = (RiffAbsolutePoint)o;
		if((getY()==((RiffAbsolutePoint)o).getY()&&getX()==((RiffAbsolutePoint)o).getX())==true){
			if(m_referenceLocation!=null){
				if(testPoint.getReferenceLocation()==null){return false;}
				return m_referenceLocation.equals(((RiffAbsolutePoint)o).getReferenceLocation());
			}else{
				if(testPoint.getReferenceLocation()==null){return true;}
				return false;
			}
		}
		return false;
	}
	public RiffAbsolutePoint getAbsolutePosition(){return this;}
}
