public class OrderStatus{
	protected static final int STATUS_COMPLETE=0;
	protected static final int STATUS_GENERALFAILURE=1;
	protected static final int STATUS_MISSINGRESOURCE=2;
	protected final int m_statusCode;
	public OrderStatus(int code){
		m_statusCode=code;
	}
	public int getOrderStatus(){return m_statusCode;}
}
