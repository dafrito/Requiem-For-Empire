import java.lang.Math;
/*
public class MoveAction extends Action{
	private static String m_actionName = new String("MoveAction");
	public String toString(){return m_actionName;}
	public boolean execute(Order superOrder, int iterationTime){
		MoveOrder order = (MoveOrder)superOrder;
		System.out.println("Total distance: " + order.getTradeLink().getDistance());
		System.out.println("Remaining distance: " + (order.getTradeLink().getDistance() - order.getOffsetDistance()));
		System.out.println("Distance traveled this turn: " + order.getMobileUnit().getVelocity(iterationTime) * iterationTime);
		if( order.getTradeLink().getDistance() - order.getOffsetDistance() >= order.getMobileUnit().getVelocity(iterationTime) * iterationTime){
			order.addOffsetDistance(order.getMobileUnit().getVelocity(iterationTime) * iterationTime);
			order.getMobileUnit().expendFuel(iterationTime);
			order.setSpentTime(iterationTime);
			return false;
		}else{
			double overage = order.getTradeLink().getDistance() - order.getOffsetDistance() - (order.getMobileUnit().getVelocity(iterationTime) * iterationTime);
			overage *= -1;
			double time = overage / order.getMobileUnit().getVelocity(iterationTime);
			System.out.println("Overage distance: " +overage);
			System.out.println("Time in overage: " + time);
			order.getMobileUnit().expendFuel(iterationTime - time);
			order.setSpentTime((int)(iterationTime - time));
			//order.getMobileUnit().getLocation().getAbsolutePosition().setLocation(order.getTradeLink().getDestination());
			return true;
		}
	}
}*/
