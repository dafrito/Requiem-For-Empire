public class RiffTester{
	public static void main(String[]args){
		RiffPolygonToolbox.testForColinearity(new RiffEuclideanPoint("A", null, 25.0, 25.0, 0), new RiffEuclideanPoint("B", null, 75.0, 75.0, 0), new RiffEuclideanPoint("C", null, 50.0, 50.0, 0), new RiffEuclideanPoint("D", null, 100.0, 100.0, 0));
	}
}
