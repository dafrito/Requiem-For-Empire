import java.util.*;

public class DiscreteRegionBSPNode{
	private RiffAbsolutePoint m_pointA, m_pointB;
	private DiscreteRegionBSPNode m_leftNode, m_rightNode;
	private List m_leftNeighbors;
	private List m_rightNeighbors;
	private List m_tempList;
	public DiscreteRegionBSPNode(Object a, Object b){
		this((RiffAbsolutePoint)a, (RiffAbsolutePoint)b);
	}
	public DiscreteRegionBSPNode(DiscreteRegion region){
		this(region.getPoints().get(0), region.getPoints().get(1));
		addRegion(region);
	}
	public DiscreteRegionBSPNode(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		m_pointA=pointA;
		m_pointB=pointB;
		m_leftNeighbors = new Vector();
		m_rightNeighbors = new Vector();
		m_tempList = new LinkedList();
	}
	public synchronized void addToTempList(List list){
		m_tempList.addAll(list);
	}
	public synchronized List getTempList(){return m_tempList;}
	public synchronized void addToTempList(DiscreteRegion region){
		m_tempList.add(region);
	}
	public synchronized void removeFromTempList(DiscreteRegion region){
		m_tempList.remove(region);
	}
	public synchronized List getPotentialList(DiscreteRegion region){
		RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Testing region against this line: " + region);
		RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Line: " + m_pointA + ", " + m_pointB);
		RiffPolygonToolbox.assertCCWPolygon(region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()&&!array[1].isEmpty()){
			RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Region is straddling this line, returning full list.");
			Set polys = new HashSet();
			polys.addAll(getPolyList());
			return new LinkedList(polys);
		}else if(!array[0].isEmpty()){
			RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Region is less than this line");
			if(m_leftNode!=null){
				RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Deferring to left node.");
				return m_leftNode.getPotentialList(region);
			}
			RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Left node is null, so returning left neighbors: " + RiffToolbox.displayList(m_leftNeighbors));
			return m_leftNeighbors;
		}else if(!array[1].isEmpty()){
			RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Region is greater than this line");
			if(m_rightNode!=null){
				RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Deferring to right node.");
				return m_rightNode.getPotentialList(region);
			}
			RiffToolbox.printDebug("DiscreteRegionBSPNode/getPotentialList/heavyDebug", "Right node is null, so returning right neighbors: " + RiffToolbox.displayList(m_rightNeighbors));
			return m_rightNeighbors;
		}
		return null;
	}
	public synchronized Set getPolyList(){
		Set list = new HashSet();
		list.addAll(m_leftNeighbors);
		list.addAll(m_rightNeighbors);
		if(m_leftNode!=null){list.addAll(m_leftNode.getPolyList());}
		if(m_rightNode!=null){list.addAll(m_rightNode.getPolyList());}
		return list;
	}
	public synchronized void addRegion(DiscreteRegion region){
		RiffPolygonToolbox.optimizePolygon(region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()&&!array[1].isEmpty()){
			DiscreteRegion splitPolygon = RiffPolygonToolbox.splitPolygonUsingEdge(region, m_pointA, m_pointB,true);
			if(splitPolygon==null){
				RiffToolbox.toggleDebugSpew();
				RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/heavyDebug", "DEATH EXCEPTION. Null region, wtf? : " + splitPolygon);
				for(int i=0;i<array.length;i++){
					RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/heavyDebug", "Pointside result " + i + ": " + array[i]);
				}
				RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/heavyDebug", "Points to split with: " + m_pointA + ", " + m_pointB);
				RiffToolbox.printDebug("DiscreteRegionBSPNode/addRegion/heavyDebug", "Region to split: " + region);
				}
			addRegion(region);
			addRegion(splitPolygon);
			return;
		}
		if(!array[0].isEmpty()){
			if(!array[2].isEmpty()){
				m_leftNeighbors.add(region);
			}
			if(m_leftNode!=null){
				m_leftNode.addRegion(region);
				return;
			}
			List pointList = region.getPoints();
			for(int i=0;i<pointList.size();i++){
				addLine(region, pointList.get(i),pointList.get((i+1)%pointList.size()));
			}
		}else if(!array[1].isEmpty()){
			if(!array[2].isEmpty()){
				m_rightNeighbors.add(region);
			}
			if(m_rightNode!=null){
				m_rightNode.addRegion(region);
				return;
			}
			List pointList = region.getPoints();
			for(int i=0;i<pointList.size();i++){
				addLine(region, pointList.get(i),pointList.get((i+1)%pointList.size()));
			}
		}
	}
	public synchronized void removeRegion(DiscreteRegion region){
		RiffPolygonToolbox.assertCCWPolygon(region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()){
			if(!array[2].isEmpty()){
				m_leftNeighbors.remove(region);
			}
			if(m_leftNode!=null){
				m_leftNode.removeRegion(region);
				return;
			}
		}else if(!array[1].isEmpty()){
			if(!array[2].isEmpty()){
				m_rightNeighbors.remove(region);
			}
			if(m_rightNode!=null){
				m_rightNode.removeRegion(region);
				return;
			}
		}
	}
	public synchronized void addLine(DiscreteRegion owner, RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		List[] array = RiffPolygonToolbox.getPointSideList(m_pointA, m_pointB, pointA, pointB);
		if(!array[0].isEmpty()){
			if(m_leftNode!=null){
				m_leftNode.addLine(owner, pointA, pointB);
				return;
			}
			m_leftNode = new DiscreteRegionBSPNode(pointA, pointB);
			m_leftNode.categorizeRegion(owner);
		}else if(!array[1].isEmpty()){
			if(m_rightNode!=null){
				m_rightNode.addLine(owner, pointA, pointB);
				return;
			}
			m_rightNode = new DiscreteRegionBSPNode(pointA, pointB);
			m_rightNode.categorizeRegion(owner);
		}
	}
	public void categorizeRegion(DiscreteRegion region){
		RiffPolygonToolbox.assertCCWPolygon(region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, m_pointA, m_pointB);
		if(!array[0].isEmpty()&&!array[2].isEmpty()){
			m_leftNeighbors.add(region);
		}else if(!array[1].isEmpty()&&!array[2].isEmpty()){
			m_rightNeighbors.add(region);
		}
	}
	public void addLine(DiscreteRegion owner, Object pointA, Object pointB){addLine(owner, (RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB);}
	public String toString(){
		String string = new String("DiscreteRegionBSPNode: ");
		string += "\nPointA: " + m_pointA;
		string += "\nPointB: " + m_pointB;
		string += "\nLeft neighbors: " + RiffToolbox.displayList(m_leftNeighbors);
		string += "\nRight neighbors: " + RiffToolbox.displayList(m_rightNeighbors);
		string += "\nLeft node: " + m_leftNode;
		string += "\nRight node: " + m_rightNode;
		return string;
	}
}
