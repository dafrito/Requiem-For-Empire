import javax.swing.*; // For JPanel, etc.
import java.awt.*;           // For Graphics, etc.
import java.awt.geom.*;      // For Ellipse2D, etc.
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.JOptionPane;
import java.lang.Math;
import java.io.*;

//public Brand(String name, Commodity commodity, double quality)
//public Lot(Brand brand, double quality, double quantity)
//public AssetPoint(RiffDataPoint point, Planet planet, Asset asset)
//public RiffSpherePoint(Location referenceLocation, double longitude, double latitude)
//public Terrain(double brushDensity, double elevation, double temperature, double cohesion, double waterDepth)
//public LinearGradient(RiffDataPoint focus, double radius, double exponent) throws ZeroRadiusException

public class RiffOverlappingSplitterGUI extends JPanel implements KeyListener, MouseListener{
	private java.util.List m_oldRegionList = new LinkedList();
	private java.util.List m_unsplitRegions = new LinkedList();
	private int m_polygonCycler;
	private boolean m_cyclePolygons, m_showLabels;
	private DiscreteRegion m_drawingRegion;
	private SplitterThread m_splittingThread;
	private String m_statusText;
	private DiscreteRegionBSPNode m_root;
	public RiffOverlappingSplitterGUI(){
		java.util.List regions = RiffToolbox.getDiscreteRegionsFromFile("dump.txt");
		m_unsplitRegions.addAll(regions);
		m_splittingThread = new SplitterThread(this, m_root, regions, true);
		m_splittingThread.start();
		m_statusText = "Awaiting drawing instructions.";
		m_showLabels=true;
		setFocusable(true);
		addKeyListener(this);
		addMouseListener(this);
	}
	public void paintComponent(Graphics g){
		clear(g);
		if(m_splittingThread !=null){
			m_statusText = m_splittingThread.getStatusText();
			if(!m_splittingThread.isAlive()){
				m_root=m_splittingThread.getRoot();
				m_splittingThread=null;
			}
		}
		Graphics2D g2d = (Graphics2D)g;
		if(m_splittingThread!=null){
			m_statusText = m_splittingThread.getStatusText();
			g2d.drawString(m_statusText , 5, getHeight()-5);
		}else{
			if(m_root!=null){g2d.drawString(m_statusText + "(Finished Region List Size: " + m_root.getPolyList().size() + ")", 5, getHeight()-5);}
		}
		if(m_root!=null){
			java.util.List regions = new LinkedList(m_root.getPolyList());
			for(int i=0;i<regions.size();i++){
				if(m_cyclePolygons){
					if(m_polygonCycler<0){m_polygonCycler=regions.size()-1;}
					i=m_polygonCycler%regions.size();
					m_polygonCycler=i;
				}
				java.util.List pointList = ((DiscreteRegion)regions.get(i)).getPoints();
				if(m_showLabels){
					for(int j=0;j<pointList.size();j++){
						g2d.setColor(Color.BLACK);
						if(((RiffAbsolutePoint)pointList.get(j)).getName()!=null){
							g2d.drawString(((RiffAbsolutePoint)pointList.get(j)).getName(),(int)((RiffAbsolutePoint)pointList.get(j)).getX(),(int)((RiffAbsolutePoint)pointList.get(j)).getY());
						}
					}
				}
				g2d.setColor(new Color(.25f, .25f + RiffToolbox.getRandom().nextFloat()%.75f, .25f + RiffToolbox.getRandom().nextFloat()%.75f, .25f + RiffToolbox.getRandom().nextFloat()%.75f));
				g2d.fillPolygon(RiffGraphicsToolbox.getPolygonFromDiscreteRegion((DiscreteRegion)regions.get(i)));
				if(m_cyclePolygons){break;}
			}
		}
		if(m_drawingRegion!=null){
			g2d.setColor(Color.BLACK);
			g2d.drawPolygon(RiffGraphicsToolbox.getPolygonFromDiscreteRegion(m_drawingRegion));
		}
	}
	public void mouseClicked(MouseEvent e){
		if(m_drawingRegion==null){m_drawingRegion=new DiscreteRegion();}
		m_drawingRegion.addPoint(new RiffEuclideanPoint("Point " + (m_drawingRegion.getPoints().size()+1), null, e.getX(),e.getY(),0));
		repaint();
	}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void keyTyped(KeyEvent keyEvent){}
	public void keyReleased(KeyEvent keyEvent){}
	public void keyPressed(KeyEvent keyEvent){
		switch(keyEvent.getKeyCode()){
			case KeyEvent.VK_LEFT:
			m_polygonCycler--;
			break;
			case KeyEvent.VK_RIGHT:
			m_polygonCycler++;
			break;
			case KeyEvent.VK_SPACE:
			m_cyclePolygons = !m_cyclePolygons;
			break;
			case KeyEvent.VK_CONTROL:
			m_showLabels = !m_showLabels;
			break;
			case KeyEvent.VK_T:
			RiffToolbox.toggleDebugSpew();
			break;
			case KeyEvent.VK_CAPS_LOCK:
			try{
				String string = RiffToolbox.getParseableDiscreteRegions(m_unsplitRegions);
				FileWriter writer = new FileWriter("dump.txt");
				System.out.println(string);
				writer.write(string);
				writer.close();
			}catch(IOException ex){
				System.out.println(ex);
			}
			break;
			case KeyEvent.VK_ENTER:
			if(m_splittingThread!=null&&m_splittingThread.isAlive()==false){
				m_statusText = "Splitting thread is not complete - cannot begin a new splitting process";
				break;
			}
			if(m_drawingRegion==null){break;}
			m_unsplitRegions.add(new DiscreteRegion(m_drawingRegion));
			m_splittingThread = new SplitterThread(this, m_root, new DiscreteRegion(m_drawingRegion), true);
			m_splittingThread.start();
			m_drawingRegion=null;
			break;
		}
		repaint();
	}
	protected void clear(Graphics g){super.paintComponent(g);}
  	public static void main(String[] args) {
	 	JFrame frame = new JFrame("RiffOverlappingSplitterGUI");
	 	frame.setSize(500, 500);
		frame.setContentPane(new RiffOverlappingSplitterGUI());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
