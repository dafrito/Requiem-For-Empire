public class Personality extends Organization{
	public Personality(){
		new Organization();
	}
}
