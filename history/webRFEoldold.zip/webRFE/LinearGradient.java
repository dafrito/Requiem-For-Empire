import java.lang.Math;
import java.util.*;

public class LinearGradient extends RiffSurface{
	private double m_exponent;
	private double m_radius;
	private static final int m_polygonVertices = 4;
	public LinearGradient(RiffDataPoint focus, double radius, double exponent) throws ZeroRadiusException{
		m_point = focus;
		m_radius = radius;
		m_exponent = exponent;
		if(m_radius == 0.0d){throw(new ZeroRadiusException(this));}
	}
	public List getPolygons(double gradientPrecision){
		List list = new LinkedList();
		double radius =0;
		DiscreteRegion lastRegion = null;
		for(double i=1.0d; i>0.0d; i -= gradientPrecision){
			System.out.println("Entering sequence. i is at: " + i);
			radius += gradientPrecision * m_radius;
			DiscreteRegion newRegion = new DiscreteRegion();
			for(int j=0;j<LinearGradient.m_polygonVertices;j++){
				double radianOffset = ((Math.PI * 2)/m_polygonVertices) *  j;
				double longOffset = Math.cos(radianOffset) * radius;
				double latOffset = Math.sin(radianOffset) * radius;
				newRegion.addPoint(new RiffSpherePoint(getReferenceLocation(), ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() + longOffset, ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() + latOffset));				
			}
			if(lastRegion==null){
				list.add(newRegion);
				lastRegion=newRegion;
			}else{
				DiscreteRegion fullRegion = new DiscreteRegion();
				for(int q=0;q<=lastRegion.getPoints().size()/2;q++){
					fullRegion.getPoints().add(lastRegion.getPoints().get(q));
				}
				for(int q=0;q<=newRegion.getPoints().size()/2;q++){
					fullRegion.getPoints().add(newRegion.getPoints().get((newRegion.getPoints().size()/2)- q));
				}
				lastRegion=newRegion;
				list.add(fullRegion);
			}
		}
		//public DiscreteTerrainRegion(Terrain terrain, DiscreteRegion region, double multiplier){
		return list;
	}
	public double getOverlap(RiffDataPoint testPoint){
		double distance = RiffToolbox.getDistance(getAbsolutePosition(), testPoint);
		if(Math.abs(distance) > m_radius || m_exponent == 0){return 0.0d; }
		return Math.abs(Math.pow(distance / m_radius,m_exponent)-1.0d);
	}
	public double getLeftExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() - m_radius;}
	public double getRightExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLatitudeDegrees() + m_radius;}
	public double getTopExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() + m_radius;}
	public double getBottomExtreme(){return ((RiffSpherePoint)getAbsolutePosition()).getLongitudeDegrees() - m_radius;}
	public String toString(){
		String string = new String();
		string += "Linear Gradient\n";
		string += "Focus: " + getAbsolutePosition();
		string += "\nRadius: " + m_radius;
		return string;
	}
}
		
