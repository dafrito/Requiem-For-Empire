import java.util.*;

public class RiffPolygonToolbox{
	// Returns the slope of these lines.
	public static double getSlope(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		return (pointB.getY()-pointA.getY())/(pointB.getX()-pointA.getX());
	}
	public static double getSlope(Object a, Object b){return RiffPolygonToolbox.getSlope((RiffAbsolutePoint)a,(RiffAbsolutePoint)b);}
	public static boolean areSlopesEqual(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, RiffAbsolutePoint testPointA, RiffAbsolutePoint testPointB){
		if(RiffToolbox.areEqual(pointB.getX(),pointA.getX())){
			if(RiffToolbox.areEqual(testPointA.getX(), testPointB.getX())){
				return true;
			}
		}
		return RiffToolbox.areEqual(Math.abs(RiffPolygonToolbox.getSlope(pointA, pointB)), Math.abs(RiffPolygonToolbox.getSlope(testPointA, testPointB)));
	}
	// Tests if a polygon is convex.
	public static boolean isPolygonConvex(DiscreteRegion region){
		List pointList = region.getPoints();
		Boolean myBool = null;
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint linePointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint linePointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			for(int k=0;k<pointList.size();k++){
				RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(k);
				//(y - y0) (x1 - x0) - (x - x0) (y1 - y0)
				double value = (testPoint.getY() - linePointA.getY())*(linePointB.getX() - linePointA.getX()) - (testPoint.getX() - linePointA.getX())*(linePointB.getY() - linePointA.getY());
				if(myBool == null){
					if(value > 0){
						myBool = new Boolean(true);
					}else if(value < 0){
						myBool = new Boolean(false);
					}
				}else{
					if(value > 0){
						if(myBool.booleanValue() == true){continue;}
						return false;
					}else if(value < 0){
						if(myBool.booleanValue() == false){continue;}
						return false;
					}else{
						continue;
					}
				}
			}
		}
		return true;
	}
	// Takes a collection of discrete regions and optimizes them one by one, returning the optimized polygon list at the end.
	public static List optimizePolygons(Collection list){
		Iterator iter = list.iterator();
		List polygons = new LinkedList();
		while(iter.hasNext()){
			DiscreteRegion region = (DiscreteRegion)iter.next();
			region = RiffPolygonToolbox.optimizePolygon(region);
			if(region==null){continue;}
			polygons.add(region);
		}
		return polygons;
	}
	public static boolean testForColinearity(RiffAbsolutePoint pointA, DiscreteRegion region){
		List pointList = region.getPoints();
		for(int i=0;i<pointList.size();i++){
			if(pointA.equals(pointList.get(i))||pointA.equals(pointList.get((i+1)%pointList.size()))){continue;}
			if(RiffToolbox.areEqual(pointA.getY(), RiffPolygonToolbox.getSlope(pointList.get(i), pointList.get((i+1)%pointList.size())) * (pointA.getX() - ((RiffAbsolutePoint)pointList.get(i)).getX()) + ((RiffAbsolutePoint)pointList.get(i)).getY())){
				return true;
			}
		}
		return false;
	}
	public static boolean testForColinearity(Object a, DiscreteRegion b){return RiffPolygonToolbox.testForColinearity((RiffAbsolutePoint)a,b);}
	// Removes overlapping points, points that are not essential, and also confirms that the polygon is at least three points, and invalidate self-intersecting polygons.
	public static DiscreteRegion optimizePolygon(DiscreteRegion region){
		if(region.isOptimized()){
			RiffToolbox.printDebug("Polygon/optimizePolygon", "Region already optimized.");
			return region;
		}
		List pointList = region.getPoints();
		// Fail if not at least a triangle
		if(pointList.size()<3){
			RiffToolbox.printDebug("Polygon/optimizePolygon", "DiscreteRegion invalid because it has less than 3 points.");
			return null;
		}
		// Remove all overlapping points.
		for(int i=0;i<pointList.size();i++){
			for(int j=0;j<pointList.size();j++){
				if(i==j){continue;}
				if(pointList.get(i).equals(pointList.get(j))){
					RiffToolbox.printDebug("Polygon/optimizePolygon/heavyDebug", "Removing this point: " + pointList.get(j));
					pointList.remove(j);
					j--;
				}
			}
		}
		// Remove all unnecessary points.
		for(int i=0;i<pointList.size();i++){
			if(pointList.size()<3){return null;}
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)pointList.get(i);
			for(int j=1;j<pointList.size();j++){
				if(i==j){continue;}
				RiffAbsolutePoint pointB = (RiffAbsolutePoint)pointList.get(j);
				double slope = RiffPolygonToolbox.getSlope(pointA, pointB);
				for(int k=0;k<pointList.size();k++){
					if(k==i || k==j){continue;}
					RiffAbsolutePoint pointC = (RiffAbsolutePoint)pointList.get(k);
					double testSlope = RiffPolygonToolbox.getSlope(pointA, pointC);
					if(testSlope==slope){
						double y = slope * (pointC.getX() - pointA.getX()) + pointA.getY();
						if(y==pointC.getY()){
							if(RiffToolbox.getDistance(pointA, pointB) + RiffToolbox.getDistance(pointB, pointC) == RiffToolbox.getDistance(pointA, pointC)){
								RiffToolbox.printDebug("Polygon/optimizePolygon", "Attempting to remove this point:" + pointB);
								RiffToolbox.printDebug("Polygon/optimizePolygon", "In order to create the more optimal line with these points:");
								RiffToolbox.printDebug("Polygon/optimizePolygon", "First point: " + pointA);
								RiffToolbox.printDebug("Polygon/optimizePolygon", "Second point: " + pointC);
								if(RiffPolygonToolbox.confirmInteriorLine(pointA, pointC, region)){
									RiffToolbox.printDebug("Polygon/optimizePolygon", "Removing this point: " + pointB);
									pointList.remove(j);
									j--;
								}
								continue;
							}
						}else if(RiffToolbox.getDistance(pointB, pointC) + RiffToolbox.getDistance(pointA, pointC) == RiffToolbox.getDistance(pointA, pointB)){
							RiffToolbox.printDebug("Polygon/optimizePolygon", "Attempting to remove this point:" + pointC);
							RiffToolbox.printDebug("Polygon/optimizePolygon", "In order to create the more optimal line with these points:");
							RiffToolbox.printDebug("Polygon/optimizePolygon", "First point: " + pointA);
							RiffToolbox.printDebug("Polygon/optimizePolygon", "Second point: " + pointB);
							if(RiffPolygonToolbox.confirmInteriorLine(pointA, pointB, region)){
								RiffToolbox.printDebug("Polygon/optimizePolygon", "Removing this point: " + pointC);
								pointList.remove(k);
								k--;
							}
							continue;
						}else if(RiffToolbox.getDistance(pointB, pointA) + RiffToolbox.getDistance(pointA, pointC) == RiffToolbox.getDistance(pointC, pointB)){
							RiffToolbox.printDebug("Polygon/optimizePolygon", "Attempting to remove this point:" + pointA);
							RiffToolbox.printDebug("Polygon/optimizePolygon", "In order to create the more optimal line with these points:");
							RiffToolbox.printDebug("Polygon/optimizePolygon", "First point: " + pointC);
							RiffToolbox.printDebug("Polygon/optimizePolygon", "Second point: " + pointB);
							if(RiffPolygonToolbox.confirmInteriorLine(pointC, pointB, region)){
								RiffToolbox.printDebug("Polygon/optimizePolygon", "Removing this point: " + pointA);
								pointList.remove(i);
								i--;
							}
							continue;
						}
					}
				}
			}
		}
		// Test for self-intersections
		for(int i=0;i<pointList.size();i++){
			for(int j=0;j<pointList.size();j++){
				if(i==j){continue;}
				RiffToolbox.printDebug("Polygon/optimizePolygon/heavyDebug", "Testing for self-intersection...");
				boolean flag=false;
				if(RiffPolygonToolbox.getIntersection(flag, pointList.get(i),pointList.get((i+1)%pointList.size()),pointList.get(j),pointList.get((j+1)%pointList.size()))!=null){
					if(!flag){
						RiffToolbox.printDebug("Polygon/optimizePolygon", "Polygon intersects itself and is invalid, reutrning null from optimized polygon.");
						return null;
					}
				}
			}
		}
		// Fail if not at least a triangle
		if(pointList.size()<3){
			RiffToolbox.printDebug("Polygon/optimizePolygon", "DiscreteRegion invalid because it has less than 3 points.");
			return null;
		}
		region.setPointList(pointList);
		RiffPolygonToolbox.assertCCWPolygon(region);
		RiffToolbox.printDebug("Polygon/optimizePolygon", "Setting optimized.");
		region.setOptimized(true);
		return region;
	}
	// Tests how many times a line, using the coord's as the first point, and the extreme right point of the poly, crosses any other border.
	public static int getCrosses(double xCoord, double yCoord, DiscreteRegion region){
		RiffToolbox.printDebug("Polygon/Polygon/getCrosses", "Testing for crosses for x-coord:" + xCoord + " and y-coord: " + yCoord);
		List pointList = region.getPoints();
		int crosses=0;
		double xExtremeCoord=Double.NEGATIVE_INFINITY;
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(i);
			if(testPoint.getX()>xExtremeCoord){
				xExtremeCoord=testPoint.getX();
			}
		}
		xExtremeCoord+=1.0f;
		RiffToolbox.printDebug("Polygon/getCrosses", "This line extends to x-coord: " + xExtremeCoord + " and y-coord: " + yCoord);
		RiffEuclideanPoint crossExtremePoint = new RiffEuclideanPoint("Extreme right-point", null, xExtremeCoord, yCoord, 0);
		RiffEuclideanPoint crossMidPoint= new RiffEuclideanPoint("MidPoint", null, xCoord, yCoord, 0);
		List overlappedVertices = new LinkedList();
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint testPointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			if(testPointA.getY()==yCoord){
				if(overlappedVertices.contains(testPointA)){continue;
				}else{
					overlappedVertices.add(testPointA);
				}
			}else if(testPointB.getY()==yCoord){
				if(overlappedVertices.contains(testPointB)){continue;
				}else{
					overlappedVertices.add(testPointB);
				}
			}
			boolean flag=false;
			if(RiffPolygonToolbox.getIntersection(flag, crossMidPoint, crossExtremePoint, testPointA, testPointB)!=null){
				if(!flag){crosses++;}
			}
		}
		RiffToolbox.printDebug("Polygon/getCrosses", "Total Crosses: " + crosses);
		return crosses;
	}
	public static boolean testforRegionPointSideIntersection(DiscreteRegion region, DiscreteRegion otherRegion){
		List regionList = region.getPoints();
		for(int i=0;i<regionList.size();i++){
			List[] array = RiffPolygonToolbox.getPointSideList(otherRegion, (RiffAbsolutePoint)regionList.get(i), (RiffAbsolutePoint)regionList.get((i+1)%regionList.size()));
			RiffToolbox.printDebug("Polygon/getPointSidePolygonTest/heavyDebug", "Now entering Pointside Polygon test, points follow:\nFirst point: " + (RiffAbsolutePoint)regionList.get(i));
			RiffToolbox.printDebug("Polygon/getPointsidePolygonTest/heavyDebug", "Second point: "  +(RiffAbsolutePoint)regionList.get((i+1)%regionList.size()));
			if(!array[0].isEmpty()){
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "This line failed the point-side test against this region:");
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "First point: " + (RiffAbsolutePoint)regionList.get(i));
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "Second point: "  +(RiffAbsolutePoint)regionList.get((i+1)%regionList.size()));
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "Region: " + otherRegion);
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "First array: " + array[0]);
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "Second array: " + array[1]);
				RiffToolbox.printDebug("Polygon/getPointSidePolygonTest", "Third array: " + array[2]);
				return true;
			}
			RiffToolbox.printDebug("Polygon/getPointSidePolygonTest/heavyDebug", "This line passed the test.");
		}
		RiffToolbox.printDebug("Polygon/getPointSidePolygonTest/heavyDebug", "This polygon passed the point side polygon test.");
		return false;
	}
	public static boolean getBoundingRectIntersection(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, RiffAbsolutePoint pointC, RiffAbsolutePoint pointD){
		if(RiffToolbox.isLessThan(Math.max(pointA.getX(), pointB.getX()),  Math.min(pointC.getX(), pointD.getX()))){return false;}
		if(RiffToolbox.isGreaterThan(Math.min(pointA.getX(), pointB.getX()), Math.max(pointC.getX(), pointD.getX()))){return false;}
		if(RiffToolbox.isLessThan(Math.max(pointA.getY(), pointB.getY()), Math.min(pointC.getY(), pointD.getY()))){return false;}
		if(RiffToolbox.isGreaterThan(Math.min(pointA.getY(), pointB.getY()), Math.max(pointC.getY(), pointD.getY()))){return false;}
		return true;
	}
	public static void snapVertices(List polygons){
		RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "Testing for snappable vertices.");
		for(int i=0;i<polygons.size();i++){
			List pointList = ((DiscreteRegion)polygons.get(i)).getPoints();
			for(int j=0;j<polygons.size();j++){
				RiffPolygonToolbox.optimizePolygon((DiscreteRegion)polygons.get(j));
				if(i==j){continue;}
				List otherPointList = ((DiscreteRegion)polygons.get(j)).getPoints();
				for(int k=0;k<pointList.size();k++){
					for(int l=0;l<otherPointList.size();l++){
						if(pointList.get(k).equals(otherPointList.get(l))){
							RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "Snapping vertices.");
							RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "Testing this point: " + pointList.get(k));
							RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "Against this point: " + otherPointList.get(l));
							((RiffEuclideanPoint)otherPointList.get(l)).duplicate((RiffEuclideanPoint)pointList.get(k));
							RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "PointA: " + pointList.get(k));
							RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "PointB: " + otherPointList.get(l));
						}
						//RiffToolbox.printDebug("Polygon/snapVertices/heavyDebug", "Points are not equal.");
					}
				}
			}
		}
	}
	public static boolean getBoundingRectIntersection(Object a, Object b, Object c, Object d){return RiffPolygonToolbox.getBoundingRectIntersection((RiffAbsolutePoint)a, (RiffAbsolutePoint)b, (RiffAbsolutePoint)c, (RiffAbsolutePoint)d);}
	// Removes all empty spaces by either joining, or creating, polygons to make a complete spherical mesh.
	/*public static void snapAllPolygons(List polygons){
		for(int i=0;i<polygons.size();i++){
			DiscreteRegion region = (DiscreteRegion)polygons.get(i);
			for(int j=0;j<polygons.size();j++){
				if(i==j){continue;}
				DiscreteRegion otherRegion = (DiscreteRegion)polygons.get(j);
				
				
	}*/
	// Removes overlapping polygons and creates new ones with the characteristics of the previous two merged together.
	public static DiscreteRegionBSPNode removeOverlappingPolygons(DiscreteRegionBSPNode root, DiscreteRegion region,boolean recurse){
		if(region==null||root==null){
			RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Region or root are null, returning...");
			return root;
		}
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "\n\nNow detecting and removing overlapping polygons.");
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Current region: " + region);
		//RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Current root node: " + root);
		List potentialList = root.getPotentialList(region);
		if(potentialList==null||potentialList.size()==0){
			RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Potential intersection list from BSP tree is null or zero-size");
			root.addRegion(region);
			return root;
		}
		List regionPoints = region.getPoints();
		for(int i=0;i<potentialList.size();i++){
			if(potentialList.get(i).equals(region)){return root;}
			DiscreteRegion otherRegion = (DiscreteRegion)potentialList.get(i);
			List otherRegionPoints = otherRegion.getPoints();
			if(region.checkClearedRegionMap(otherRegion)){
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Intersection map check returned true, continuing...");
				potentialList.remove(otherRegion);i--;continue;
			}
			if(!RiffPolygonToolbox.getBoundingRectIntersection(region, otherRegion)){
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Polygons do not intersect with their bounding rects, continuing...");
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Failed Region: " + otherRegion);
				region.addRegionToMap(otherRegion);
				otherRegion.addRegionToMap(region);
				potentialList.remove(otherRegion);i--;continue;
			}
			if(!RiffPolygonToolbox.testforRegionPointSideIntersection(region, otherRegion)&&!RiffPolygonToolbox.testforRegionPointSideIntersection(otherRegion,region)){
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Polygons do not intersect according to the point-side polygon test");
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Non-intersecting Region: " + otherRegion);
				region.addRegionToMap(otherRegion);
				otherRegion.addRegionToMap(region);
				potentialList.remove(otherRegion);i--;continue;
			}
			for(int k=0;k<regionPoints.size();k++){
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "\nBeginning new test with these points as the potential intersecting line:");
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "First point: " + regionPoints.get(k));
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Second point: " + regionPoints.get((k+1)%regionPoints.size() ));
				if(!RiffPolygonToolbox.getBoundingRectIntersection(regionPoints.get(k), regionPoints.get((k+1)%regionPoints.size()), otherRegion)){
					RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "The current line's bounding rect does not overlap the other region's, continuing...");
					RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Failed Region: " + otherRegion);
					continue;
				}
				DiscreteRegion oldRegion = new DiscreteRegion(otherRegion);
				DiscreteRegion newRegion = RiffPolygonToolbox.splitPolygonUsingEdge(otherRegion, regionPoints.get(k), regionPoints.get((k+1)%regionPoints.size()), false);
				if(newRegion==null){
					RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "New-region is null, continuing...");
					continue;
				}else{
					root.removeRegion(oldRegion);
					if(recurse){
						root=RiffPolygonToolbox.removeOverlappingPolygons(root, otherRegion,recurse);
						return RiffPolygonToolbox.removeOverlappingPolygons(root, newRegion,recurse);
					}else{
						root.removeFromTempList(oldRegion);
						root.addToTempList(region);
						root.addToTempList(otherRegion);
						root.addToTempList(newRegion);
						return root;
					}
				}
			}
			for(int k=0;k<otherRegionPoints.size();k++){
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "\nBeginning new test with these points as the potential intersecting line:");
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "First point: " + otherRegionPoints.get(k));
				RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Second point: " + otherRegionPoints.get((k+1)%otherRegionPoints.size() ));
				if(!RiffPolygonToolbox.getBoundingRectIntersection(otherRegionPoints.get(k), otherRegionPoints.get((k+1)%otherRegionPoints.size()), region)){
					RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "The current line's bounding rect does not overlap the other region's, continuing...");
					continue;
				}
				DiscreteRegion oldRegion = new DiscreteRegion(region);
				DiscreteRegion newRegion = RiffPolygonToolbox.splitPolygonUsingEdge(region, otherRegionPoints.get(k), otherRegionPoints.get((k+1)%otherRegionPoints.size()), false);
				if(newRegion==null){
					RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "New-region is null, continuing...");
					continue;
				}else{
					root.removeRegion(oldRegion);
					if(recurse){
						root=RiffPolygonToolbox.removeOverlappingPolygons(root, region,recurse);
						root=RiffPolygonToolbox.removeOverlappingPolygons(root, newRegion,recurse);
						return RiffPolygonToolbox.removeOverlappingPolygons(root, otherRegion,recurse);
					}else{
						root.removeFromTempList(oldRegion);
						root.addToTempList(region);
						root.addToTempList(otherRegion);
						root.addToTempList(newRegion);
						return root;
					}
				}
			}
			region.addRegionToMap(otherRegion);
			otherRegion.addRegionToMap(region);
		}
		root.removeFromTempList(region);
		root.addRegion(region);
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Natural return.");
		return root;
	}
	public static boolean getBoundingRectIntersection(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, DiscreteRegion region){
		if(RiffToolbox.isLessThan(Math.max(pointA.getX(), pointB.getX()), region.getLeftExtreme())){return false;}
		if(RiffToolbox.isGreaterThan(Math.min(pointA.getX(), pointB.getX()), region.getRightExtreme())){return false;}
		if(RiffToolbox.isLessThan(Math.max(pointA.getY(), pointB.getY()), region.getBottomExtreme())){return false;}
		if(RiffToolbox.isGreaterThan(Math.min(pointA.getY(), pointB.getY()), region.getTopExtreme())){return false;}
		return true;
	}
	public static boolean getBoundingRectIntersection(Object pointA, Object pointB, DiscreteRegion region){
		return RiffPolygonToolbox.getBoundingRectIntersection((RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB, region);
	}
	// Tests for intersections of this line provided by the two points against the lines of the region provided.
	public static List getIntersections(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, DiscreteRegion region){
		List pointList = region.getPoints();
		List intersectPoints = new LinkedList();
		boolean tangentFlag = false;
		if(!RiffPolygonToolbox.getBoundingRectIntersection(pointA, pointB, region)){return intersectPoints;}
		for(int i=0;i<pointList.size();i++){
			boolean flag=false;
			RiffAbsolutePoint intersectPoint = RiffPolygonToolbox.getIntersection(flag, pointA, pointB, pointList.get(i), pointList.get((i+1)%pointList.size()));
			if(intersectPoint==null){tangentFlag=false;continue;
			}else if(flag){
				if(!tangentFlag){
					tangentFlag=true;
				}else{
					intersectPoints.add(new Integer(i));intersectPoints.add(pointList.get(i));
					tangentFlag=false;
				}
			}else{
				tangentFlag=false;
				intersectPoints.add(new Integer(i)); intersectPoints.add(intersectPoint);
			}
		}
		return intersectPoints;
	}
	// Helper function
	public static List getIntersections(Object a, Object b, DiscreteRegion region){return RiffPolygonToolbox.getIntersections((RiffAbsolutePoint)a, (RiffAbsolutePoint)b, region);}
	// Takes two points and extends their line so that the x-value provided by the extension is at an endpoint of the line.
	public static double getExtensionPoint(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, double extension){ 
		return RiffPolygonToolbox.getSlope(pointA, pointB) * (extension - pointA.getX()) + pointA.getY();
	}
	// Extends a line, provided by the two points, in both directions so that their x coordinates are equal to the left and right double values provided with correct slope.
	public static List getExtensionPoints(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, DiscreteRegion region){
		List pointList = new LinkedList();
		RiffToolbox.printDebug("Polygon/getExtensionPoints/heavyDebug", "Extending these points to these extensions:");
		RiffToolbox.printDebug("Polygon/getExtensionPoints/heavyDebug", "First point: " + pointA);
		RiffToolbox.printDebug("Polygon/getExtensionPoints/heavyDebug", "Second point: " + pointB);
		double YValue = RiffPolygonToolbox.getExtensionPoint(pointA, pointB, region.getLeftExtreme()-1.0d);
		double XValue = region.getLeftExtreme()-1.0d;
		if(RiffToolbox.isGreaterThan(YValue, region.getTopExtreme())){
			YValue = region.getTopExtreme()+1.0d;
			XValue = (YValue - pointA.getY()) / RiffPolygonToolbox.getSlope(pointA, pointB) + pointA.getX();
		}else if(RiffToolbox.isLessThan(YValue, region.getBottomExtreme())){
			YValue = region.getBottomExtreme()-1.0d;
			XValue = (YValue - pointA.getY()) / RiffPolygonToolbox.getSlope(pointA, pointB) + pointA.getX();
		}
		pointList.add(new RiffEuclideanPoint(pointA.getName(), null, XValue, YValue, 0.0d));
		YValue = RiffPolygonToolbox.getExtensionPoint(pointA, pointB, region.getRightExtreme()+1.0d);
		XValue = region.getRightExtreme()+1.0d;
		if(RiffToolbox.isGreaterThan(YValue, region.getTopExtreme())){
			YValue = region.getTopExtreme()+1.0d;
			XValue = (YValue - pointA.getY()) / RiffPolygonToolbox.getSlope(pointA, pointB) + pointA.getX();
		}else if(RiffToolbox.isLessThan(YValue, region.getBottomExtreme())){
			YValue = region.getBottomExtreme()-1.0d;
			XValue = (YValue - pointA.getY()) / RiffPolygonToolbox.getSlope(pointA, pointB) + pointA.getX();
		}
		pointList.add(new RiffEuclideanPoint(pointB.getName(), null, XValue, YValue, 0.0d));
		RiffToolbox.printDebug("Polygon/getExtensionPoints/heavyDebug", "List of extended points: " + RiffToolbox.displayList(pointList));
		RiffToolbox.printDebug("Polygon/getExtensionPoints/heavyDebug", "Slope: " + RiffPolygonToolbox.getSlope(pointA, pointB));
		RiffToolbox.printDebug("Polygon/getExtensionPoints/heavyDebug", "Slope: " + RiffPolygonToolbox.getSlope(pointList.get(0), pointList.get(1)));
		return pointList;
	}
	// Helper function.
	public static List getExtensionPoints(Object pointA, Object pointB, DiscreteRegion region){
		return RiffPolygonToolbox.getExtensionPoints((RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB, region);
	}
	// m(x-h)+k
	public static boolean testForColinearity(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, RiffAbsolutePoint testPointA, RiffAbsolutePoint testPointB){
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Testing these points for colinearity: " + pointA + ", " + pointB);
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Against these points: " + testPointA + ", " + testPointB);
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "First line slope: " + RiffPolygonToolbox.getSlope(pointA, pointB));
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Second line slope: " + RiffPolygonToolbox.getSlope(testPointA, testPointB));
		if(!RiffPolygonToolbox.areSlopesEqual(pointA, pointB, testPointA, testPointB)){
			RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Slopes are not equal. Difference: " + (1 * Math.abs(RiffPolygonToolbox.getSlope(pointA, pointB) - RiffPolygonToolbox.getSlope(testPointA, testPointB))));
			return false;
		}
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Slope are equal. Difference: " + (1 * Math.abs(RiffPolygonToolbox.getSlope(pointA, pointB) - RiffPolygonToolbox.getSlope(testPointA, testPointB))));
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "First point-slope test: " + (RiffPolygonToolbox.getSlope(pointA, pointB) * (testPointA.getX()-pointA.getX()) + pointA.getY()));
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Expected value: " + testPointA.getY());
		if(!RiffToolbox.areEqual(RiffPolygonToolbox.getSlope(pointA, pointB) * (testPointA.getX()-pointA.getX()) + pointA.getY(), testPointA.getY())){return false;}
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Second point-slope test: " +(RiffPolygonToolbox.getSlope(pointA, pointB) * (testPointB.getX()-pointA.getX()) + pointA.getY()));
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "Expected value: " + testPointB.getY());
		if(!RiffToolbox.areEqual(RiffPolygonToolbox.getSlope(pointA, pointB) * (testPointB.getX()-pointA.getX()) + pointA.getY(),testPointB.getY())){return false;}
		RiffToolbox.printDebug("Polygon/testForColinearity/heavyDebug", "They are colinear.");
		return true;
	}
	// Tests if (pointA, pointB) intersects (testPointA, testPointB), and returns the point if it does.
	public static RiffAbsolutePoint getIntersection(boolean tangentFlag, RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, RiffAbsolutePoint testPointA, RiffAbsolutePoint testPointB){
		RiffToolbox.printDebug("Polygon/getIntersection", "First control point: [" + pointA + "]\nSecond Control Point: [" + pointB + "]");
		RiffToolbox.printDebug("Polygon/getIntersection", "First test point: [" + testPointA + "]\nSecond test Point: [" + testPointB + "]");
		// Check for invalid lines.
		if(pointA.equals(pointB)){
			RiffToolbox.printDebug("Polygon/getIntersection", "First control point is equal to second control point, returning null.");
			return null;
		}
		if(testPointA.equals(testPointB)){
			RiffToolbox.printDebug("Polygon/getIntersection", "First test point is equal to second test point, returning null.");
			return null;
		}
		// Get slopes.
		double slope = RiffPolygonToolbox.getSlope(pointA, pointB);
		double testSlope = RiffPolygonToolbox.getSlope(testPointA, testPointB);
		// Test for colinearity of these points.
		if(RiffPolygonToolbox.testForColinearity(pointA, pointB, testPointA, testPointB)){
			RiffToolbox.printDebug("Polygon/getIntersection", "These lines are colinear, returning null.");
			return null;
		}
		// Test for infinite slopes, and if found, get real intersection points.
		if(Math.abs(slope)==Double.POSITIVE_INFINITY){
			RiffToolbox.printDebug("Polygon/getIntersection", "Slope of the control points is infinite.");
			if(RiffToolbox.isGreaterThan(pointA.getX(), Math.max(testPointA.getX(), testPointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is greater than the maximum X-value of the test points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(pointA.getX(), Math.max(testPointA.getX(), testPointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is equal to the maximum X-value of the test points, setting tangent flag.");
				tangentFlag=true;
			}
			if(RiffToolbox.isLessThan(pointA.getX(), Math.min(testPointA.getX(), testPointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is less than the minimum X-value of the test points, returning null.");
				RiffToolbox.printDebug("Polygon/getIntersection", "PointA X-value: " + pointA.getX());
				RiffToolbox.printDebug("Polygon/getIntersection", "Minimum test X-value: " + Math.min(testPointA.getX(), testPointB.getX()));
				return null;
			}else if(RiffToolbox.areEqual(pointA.getX(), Math.min(testPointA.getX(), testPointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is equal to the minimum X-value of the test points, setting tangent flag.");
				tangentFlag=true;
			}
			double yValue = testSlope * (pointA.getX() - testPointA.getX()) + testPointA.getY();
			if(RiffToolbox.isGreaterThan(yValue, Math.max(testPointA.getY(), testPointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is greater than the maximum Y-value of the test points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(yValue, Math.max(testPointA.getY(), testPointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the maximum Y-value of the test points, setting tangent flag.");
				tangentFlag=true;
			} 
			if(RiffToolbox.isLessThan(yValue, Math.min(testPointA.getY(), testPointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is greater than the minimum Y-value of the test points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(yValue, Math.min(testPointA.getY(), testPointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the minimum Y-value of the test points, setting tangent flag.");
				tangentFlag=true;
			}
			RiffToolbox.printDebug("Polygon/getIntersection", "\nThese lines intersect. Point: " + pointA.getX() + ", " + yValue);
			return new RiffEuclideanPoint("Intersection Point between (" + pointA.getName() + "," + pointB.getName() + ") and (" + testPointA.getName() + "," + testPointB.getName() + ")", null, pointA.getX(), yValue, 0.0f);
		}
		if(Math.abs(testSlope)==Double.POSITIVE_INFINITY){
			RiffToolbox.printDebug("Polygon/getIntersection", "Slope of the test points is infinite.");
			if(RiffToolbox.isGreaterThan(testPointA.getX(), Math.max(pointA.getX(), pointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is greater than the maximum X-value of the control points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(testPointA.getX(), Math.max(pointA.getX(), pointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is equal to the maximum X-value of the control points, setting tangent flag.");
				tangentFlag=true;
			}
			if(RiffToolbox.isLessThan(testPointA.getX(), Math.min(pointA.getX(), pointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is less than the minimum X-value of the control points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(testPointA.getX(), Math.min(pointA.getX(), pointB.getX()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The X-value is equal to the minimum X-value of the control points, setting tangent flag.");
				tangentFlag=true;
			}
			double yValue = slope * (testPointA.getX() - pointA.getX()) + pointA.getY();
			if(RiffToolbox.isGreaterThan(yValue, Math.max(pointA.getY(), pointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is greater than the maximum Y-value of the control points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(yValue, Math.max(pointA.getY(), pointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the maximum Y-value of the control points, setting tangent flag.");
				tangentFlag=true;
			} 
			if(RiffToolbox.isLessThan(yValue, Math.min(pointA.getY(), pointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is greater than the minimum Y-value of the control points, returning null.");
				return null;
			}else if(RiffToolbox.areEqual(yValue, Math.min(pointA.getY(), pointB.getY()))){
				RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the minimum Y-value of the control points, setting tangent flag.");
				tangentFlag=true;
			}
			RiffToolbox.printDebug("Polygon/getIntersection", "\nThese lines intersect.Point: " + pointA.getX() + ", " +  yValue);
			return new RiffEuclideanPoint("Intersection Point between (" + pointA.getName() + "," + pointB.getName() + ") and (" + testPointA.getName() + "," + testPointB.getName() + ")", null, testPointA.getX(), yValue, 0.0f);
		}
		// Bounding rect testing of the two lines.
		if(RiffToolbox.isLessThan(Math.max(pointB.getX(), pointA.getX()), Math.min(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The maximum x-value of the control points is less than the minimum X-value of the testPoints, returning null."); 
			return null;
		}else if(RiffToolbox.areEqual(Math.max(pointB.getX(), pointA.getX()), Math.min(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The maximum x-value of the control points is equal to the minimum X-value of the testPoints, setting tangent flag."); 
			tangentFlag=true;
		}
		if(RiffToolbox.isGreaterThan(Math.min(pointB.getX(), pointA.getX()), Math.max(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The minimum x-value of the control points is greater than the maximum X-value of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(Math.min(pointB.getX(), pointA.getX()), Math.max(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The minimum x-value of the control points is equal to the maximum X-value of the testPoints, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isLessThan(Math.max(pointA.getY(),pointB.getY()), Math.min(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The maximum Y-value of the control points is less than the minimum Y-value of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(Math.max(pointA.getY(),pointB.getY()), Math.min(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The maximum Y-value of the control points is equal to the minimum  Y-value of the testPoints, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isGreaterThan(Math.min(pointA.getY(),pointB.getY()), Math.max(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The minimum Y-value of the control points is greater than the maximum Y-value of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(Math.min(pointA.getY(),pointB.getY()), Math.max(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The minimum Y-value of the control points is equal to than the maximum Y-value of the testPoints, setting tangent flag.");
			tangentFlag=true;
		}
		// X-intersection testing.
		double xIntersection = ((-slope * pointA.getX() + pointA.getY()) - (-testSlope * testPointA.getX() + testPointA.getY()))/(testSlope-slope);
		RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept between these two points is: " + xIntersection);
		if(RiffToolbox.isLessThan(xIntersection, Math.min(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is less than the minimum of the X-values of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(xIntersection, Math.min(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is equal to the minimum of the X-values of the testPoints, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isGreaterThan(xIntersection, Math.max(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is greater than the maximum of the X-values of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(xIntersection, Math.max(testPointA.getX(), testPointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is equal to the maximum of the X-values of the testPoints, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isLessThan(xIntersection, Math.min(pointA.getX(), pointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is less than the minimum of the X-values of the control points, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(xIntersection, Math.min(pointA.getX(), pointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is equal to the minimum of the X-values of the control points, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isGreaterThan(xIntersection, Math.max(pointA.getX(), pointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is greater than the maximum of the X-values of the control points, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(xIntersection, Math.max(pointA.getX(), pointB.getX()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The X-intercept is equal to the maximum of the X-values of the control points, setting tangent flag.");
			tangentFlag=true;
		}
		// Y-intersection testing.
		double yIntersection = slope * xIntersection + (-slope * pointA.getX() + pointA.getY());
		RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept between these two points is: " + yIntersection);
		if(RiffToolbox.isLessThan(yIntersection, Math.min(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is less than the minimum of the Y-values of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(yIntersection, Math.min(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the minimum of the Y-values of the testPoints, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isGreaterThan(yIntersection, Math.max(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is greater than the maximum of the Y-values of the testPoints, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(yIntersection, Math.max(testPointA.getY(), testPointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the maximum of the Y-values of the testpoints, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isLessThan(yIntersection, Math.min(pointA.getY(), pointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is less than the minimum of the Y-values of the control points, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(yIntersection, Math.min(pointA.getY(), pointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the minimum of the Y-values of the control points, setting tangent flag.");
			tangentFlag=true;
		}
		if(RiffToolbox.isGreaterThan(yIntersection, Math.max(pointA.getY(), pointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is greater than the maximum of the Y-values of the control points, returning null.");
			return null;
		}else if(RiffToolbox.areEqual(yIntersection, Math.max(pointA.getY(), pointB.getY()))){
			RiffToolbox.printDebug("Polygon/getIntersection", "The Y-intercept is equal to the maximum of the Y-values of the control points, setting tangent flag.");
			tangentFlag=true;
		}
		// New point creation of intersection.
		RiffToolbox.printDebug("Polygon/getIntersection", "\nThese lines intersect.\n");
		return new RiffEuclideanPoint("(" + pointA.getName() + "," + pointB.getName() + ")+(" + testPointA.getName() + "," + testPointB.getName() + ")", null, xIntersection, yIntersection, 0.0f);
	}
	// Helper function.
	public static RiffAbsolutePoint getIntersection(boolean tangent, Object pointA, Object pointB, Object pointC, Object pointD ){
		return RiffPolygonToolbox.getIntersection(tangent, (RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB, (RiffAbsolutePoint)pointC, (RiffAbsolutePoint)pointD);
	}
	// Confirms that the line formed by the two points is an interior line.
	public static boolean confirmInteriorLine(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, DiscreteRegion region){
		List pointList = region.getPoints();
		RiffToolbox.printDebug("Polygon/confirmInteriorLine", "Confirming interior line with these points: " + pointA.getName() + " and " + pointB.getName());
		for(int i=0;i<pointList.size();i++){
			RiffAbsolutePoint testPointA = (RiffAbsolutePoint)pointList.get(i);
			RiffAbsolutePoint testPointB = (RiffAbsolutePoint)pointList.get((i+1)%pointList.size());
			if((testPointA.equals(pointA) && testPointB.equals(pointB))||(testPointA.equals(pointB) && testPointB.equals(pointA))){return false;}
			boolean flag=false;
			if(RiffPolygonToolbox.getIntersection(flag, pointA, pointB, testPointA, testPointB)!=null&&!flag){
				return false;
			}
		}
		RiffToolbox.printDebug("Polygon/confirmInteriorLine", "No intersections found, checking for crosses.");
		int crosses=RiffPolygonToolbox.getCrosses(pointA.getX()+(pointB.getX()-pointA.getX())/2,pointA.getY()+(pointB.getY()-pointA.getY())/2, region);
		if(crosses==0||crosses%2==0){return false;}
		RiffToolbox.printDebug("Polygon/confirmInteriorLine", "Interior line confirmed.");
		return true;
	}
	// This process converts a concave polygon to a list of convex polygons.
	public static List convertPolyToConvex(DiscreteRegion originalRegion){
		RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Attempting to convert this polygon into its convex parts...");
		RiffToolbox.printDebug("Polygon/convertPolyToConvex", originalRegion);
		DiscreteRegion region = RiffPolygonToolbox.optimizePolygon(originalRegion);
		RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Optimized region: " + region);
		if(region==null){return null;}
		List convexPolygons = new LinkedList();
		if(RiffPolygonToolbox.isPolygonConvex(region)==true){
			RiffToolbox.printDebug("Polygon/convertPolyToConvex", "This polygon is convex, so adding it to the list and returning.");
			convexPolygons.add(region);
			return convexPolygons;
		}
		RiffToolbox.printDebug("Polygon/convertPolyToConvex", "This polygon is concave. Attempting to subdivide...");
		DiscreteRegion testRegion = new DiscreteRegion();
		List pointList = region.getPoints();
		for(int i=0;i<pointList.size();i++){
			boolean alreadyCreated = false;
			RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Attempting to form a triangle from these points:");
			RiffToolbox.printDebug("Polygon/convertPolyToConvex", "First point: " + pointList.get(i) + ", Second Point: " + (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()) + ", Third point: " + (RiffAbsolutePoint)pointList.get((i+2)%pointList.size())); 
			if(RiffPolygonToolbox.confirmInteriorLine((RiffAbsolutePoint)pointList.get(i),(RiffAbsolutePoint)pointList.get((i+2)%pointList.size()),region)==false){
				RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Failed interior-line test.");
				continue;
			}
			testRegion = new DiscreteRegion();
			testRegion.addPoint((RiffAbsolutePoint)pointList.get(i));
			testRegion.addPoint((RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
			testRegion.addPoint((RiffAbsolutePoint)pointList.get((i+2)%pointList.size()));
			for(int k=0;k<convexPolygons.size();k++){
				if(testRegion.equals(convexPolygons.get(k))){alreadyCreated=true;break;}
			}
			if(alreadyCreated){RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Polygon already created.");continue;}
			RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Removing this point: " + (RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
			region.removePoint((RiffAbsolutePoint)pointList.get((i+1)%pointList.size()));
			RiffToolbox.printDebug("Polygon/convertPolyToConvex", "Yielding the new triangle and this remaining region: " + region);
			convexPolygons.add(testRegion);
			
			convexPolygons.addAll(RiffPolygonToolbox.convertPolyToConvex(region));
			break;
		}
		return convexPolygons;
	}
	// Converts the list of polygons into convex polygons, returning the list of these.
	public static List convertPolyToConvex(List polygons){
		List list = new LinkedList();
		for(int i=0;i<polygons.size();i++){
			list.addAll(RiffPolygonToolbox.convertPolyToConvex((DiscreteRegion)polygons.get(i)));
		}
		return list;
	}
	// Tests for bounding rect intersection between the two regions.
	public static boolean getBoundingRectIntersection(DiscreteRegion region, DiscreteRegion otherRegion){
		if(region.getLeftExtreme()>=otherRegion.getRightExtreme()){return false;}
		if(region.getRightExtreme()<=otherRegion.getLeftExtreme()){return false;}
		if(region.getTopExtreme()<=otherRegion.getBottomExtreme()){return false;}
		if(region.getBottomExtreme()>=otherRegion.getTopExtreme()){return false;}
		return true;
	}
	// Takes a list of convex, non-overlapping polygons, and joins them if they share a common border and their joined polygon is convex. This function
	// returns this list, or the originalPolygon in a list if no polygons were joined.
	public static List joinPolygons(List polyList){
		List optimizedList = new LinkedList();
		for(int i=0;i<polyList.size();i++){
			for(int j=0;j<polyList.size();j++){
				if(i==j){continue;}
				DiscreteRegion firstRegion = (DiscreteRegion)polyList.get(i);
				DiscreteRegion secondRegion = (DiscreteRegion)polyList.get(j);
				for(int q=0;q<firstRegion.getPoints().size();q++){
					for(int x=0;x<secondRegion.getPoints().size();x++){
						if(!firstRegion.getPoints().get(q).equals(secondRegion.getPoints().get(x))&&!firstRegion.getPoints().get((q+1)%firstRegion.getPoints().size()).equals(secondRegion.getPoints().get(x))){continue;}
						if(!firstRegion.getPoints().get(q).equals(secondRegion.getPoints().get((x+1)%secondRegion.getPoints().size()))&&!firstRegion.getPoints().get((q+1)%firstRegion.getPoints().size()).equals(secondRegion.getPoints().get((x+1)%secondRegion.getPoints().size()))){continue;}
						DiscreteRegion testRegion = new DiscreteRegion();
						List[] pointSideArray = RiffPolygonToolbox.getPointSideList(firstRegion, (RiffAbsolutePoint)firstRegion.getPoints().get(q), (RiffAbsolutePoint)firstRegion.getPoints().get((q+1)%firstRegion.getPoints().size()));
						if(pointSideArray[0].isEmpty()){
							int firstPoint=q;
							if(q>(q+1)%firstRegion.getPoints().size()){
								firstPoint=(q+1)%firstRegion.getPoints().size();
							}
							for(int offsetPoint=0;offsetPoint<firstRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)firstRegion.getPoints().get((firstPoint+offsetPoint)%firstRegion.getPoints().size()));
							}
							firstPoint=x;
							if(x>(x+1)%secondRegion.getPoints().size()){
								firstPoint=(x+1)%secondRegion.getPoints().size();
							}
							for(int offsetPoint=1;offsetPoint<secondRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)secondRegion.getPoints().get((firstPoint+offsetPoint)%secondRegion.getPoints().size()));
							}
						}else{
							int firstPoint=x;
							if(x>(x+1)%secondRegion.getPoints().size()){
								firstPoint=(x+1)%secondRegion.getPoints().size();
							}
							for(int offsetPoint=0;offsetPoint<secondRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)secondRegion.getPoints().get((firstPoint+offsetPoint)%secondRegion.getPoints().size()));
							}
							firstPoint=q;
							if(q>(q+1)%firstRegion.getPoints().size()){
								firstPoint=(q+1)%firstRegion.getPoints().size();
							}
							for(int offsetPoint=1;offsetPoint<firstRegion.getPoints().size();offsetPoint++){
								testRegion.addPoint((RiffAbsolutePoint)firstRegion.getPoints().get((firstPoint+offsetPoint)%firstRegion.getPoints().size()));
							}
						}
						if(RiffPolygonToolbox.isPolygonConvex(testRegion)==false){continue;}
						optimizedList.add(testRegion);
						polyList.remove(firstRegion);
						polyList.remove(secondRegion);
						optimizedList.addAll(polyList);
						return RiffPolygonToolbox.joinPolygons(optimizedList);
					}
				}
			}
		}
		return polyList;
	}
	public static void assertCCWPolygon(DiscreteRegion region){
		if(region.isOptimized()){return;}
		RiffToolbox.printDebug("Polygon/assertCCWPolygon/heavyDebug", "Region: " + region);
		List[] array = RiffPolygonToolbox.getPointSideList(region, region.getInteriorPoint());
		RiffToolbox.printDebug("Polygon/assertCCWPolygon/heavyDebug", "Left side: " + RiffToolbox.displayList(array[0]));
		RiffToolbox.printDebug("Polygon/assertCCWPolygon/heavyDebug", "Right side: " + RiffToolbox.displayList(array[1]));
		RiffToolbox.printDebug("Polygon/assertCCWPolygon/heavyDebug", "Indeterminate side: " + RiffToolbox.displayList(array[2]));
		if(!array[2].isEmpty()){
			RiffToolbox.printDebug("Polygon/assertCCWPolygon/error", "Unanticipated in assertyCCWPoly, region: " + region);
			return;
		}
		if(array[0].isEmpty()){
			RiffToolbox.printDebug("Polygon/assertCCWPolygon/heavyDebug", "Polygon is clockwise");
			region.reversePoints();
		}else if(array[1].isEmpty()){
			RiffToolbox.printDebug("Polygon/assertCCWPolygon/heavyDebug", "Polygon is CCW");
		}
	}
	public static RiffAbsolutePoint getMidPointOfLine(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		double xValue = Math.min(pointA.getX(), pointB.getX()) + .5 * (Math.max(pointA.getX(), pointB.getX()) - Math.min(pointA.getX(), pointB.getX()));
		double yValue = Math.min(pointA.getY(), pointB.getY()) + .5 * (Math.max(pointA.getY(), pointB.getY()) - Math.min(pointA.getY(), pointB.getY()));
		RiffToolbox.printDebug("Polygon/getMidPointOfLine/heavyDebug", "PointA: " + pointA);
		RiffToolbox.printDebug("Polygon/getMidPointOfLine/heavyDebug", "PointB: " + pointB);
		RiffAbsolutePoint point = new RiffEuclideanPoint(null, xValue, yValue, 0.0d);
		RiffToolbox.printDebug("Polygon/getMidPointOfLine/heavyDebug", "Midpoint: " + point);
		return point;
	}
	public static RiffAbsolutePoint getMidPointOfLine(Object pointA, Object pointB){
		return RiffPolygonToolbox.getMidPointOfLine((RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB);
	}
	public static DiscreteRegion splitPolygonUsingEdge(DiscreteRegion otherRegion, RiffAbsolutePoint pointA, RiffAbsolutePoint pointB, boolean hyperPlane){
		java.util.List otherRegionPoints = otherRegion.getPoints();
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Extending along these points: " + pointA + ", " + pointB);
		java.util.List extendedPointsList = RiffPolygonToolbox.getExtensionPoints(pointA, pointB, otherRegion);
		List intersectedList = RiffPolygonToolbox.getIntersections(extendedPointsList.get(0), extendedPointsList.get(1), otherRegion);
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", intersectedList);
		if(intersectedList.size()!=4){
			RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "No or insufficient intersections, continuing...");
			return null;
		}
		if(!hyperPlane&&!RiffPolygonToolbox.getBoundingRectIntersection(pointA, pointB,intersectedList.get(1), intersectedList.get(3))){
			RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Bounding rect test failed, continuing...");
			return null;
		}
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Creating new polygon.");
		DiscreteRegion newRegion = new DiscreteRegion();
		newRegion.addPoint((RiffAbsolutePoint)intersectedList.get(1));
		for(int q=Math.min(((Integer)intersectedList.get(0)).intValue(),((Integer)intersectedList.get(2)).intValue());q<Math.max(((Integer)intersectedList.get(0)).intValue(),((Integer)intersectedList.get(2)).intValue());q++){
			newRegion.addPoint((RiffAbsolutePoint)otherRegionPoints.get(q+1));
		}
		newRegion.addPoint((RiffAbsolutePoint)intersectedList.get(3));
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "New region formed: " + newRegion);
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", RiffToolbox.displayList(intersectedList));
		otherRegion.addPointAt(((Integer)intersectedList.get(0)).intValue()+1, (RiffAbsolutePoint)intersectedList.get(1));
		otherRegion.addPointAt(((Integer)intersectedList.get(2)).intValue()+2, (RiffAbsolutePoint)intersectedList.get(3));
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", RiffToolbox.displayList(otherRegion.getPoints()));
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Minimum point removal value: " + Math.min(((Integer)intersectedList.get(0)).intValue(),((Integer)intersectedList.get(2)).intValue()));
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Maximum point removal value: " + Math.max(((Integer)intersectedList.get(0)).intValue(),((Integer)intersectedList.get(2)).intValue()));
		for(int q=Math.min(((Integer)intersectedList.get(0)).intValue(),((Integer)intersectedList.get(2)).intValue());q<Math.max(((Integer)intersectedList.get(0)).intValue(),((Integer)intersectedList.get(2)).intValue());q++){
			RiffToolbox.printDebug("Polygon/removeOverlappingPolygons/heavyDebug", "Removing point...");
			otherRegion.removePoint(2+((Integer)intersectedList.get(0)).intValue());
		}
		RiffToolbox.printDebug("Polygon/removeOverlappingPolygons", "Old region: " + otherRegion);
		RiffPolygonToolbox.optimizePolygon(otherRegion);
		RiffPolygonToolbox.optimizePolygon(newRegion);
		return newRegion;
	}
	public static DiscreteRegion splitPolygonUsingEdge(DiscreteRegion otherRegion, Object pointA, Object pointB, boolean hyperPlane){
		return RiffPolygonToolbox.splitPolygonUsingEdge(otherRegion, (RiffAbsolutePoint)pointA, (RiffAbsolutePoint)pointB, hyperPlane);
	}
	// Using the two given points to create a line, it returns a list of the distribution of points from the polygon. 
	// This list contains two lists, one containing all the points on the left side, and one containing all the points on the right.
	public static List[] getPointSideList(DiscreteRegion region, RiffAbsolutePoint linePointA, RiffAbsolutePoint linePointB){
		List leftPoints = new LinkedList();
		List rightPoints = new LinkedList();
		List indeterminatePoints = new LinkedList();
		List pointList = region.getPoints();
		for(int k=0;k<pointList.size();k++){
			RiffAbsolutePoint testPoint = (RiffAbsolutePoint)pointList.get(k);
			double value = testPointAgainstLine(testPoint, linePointA, linePointB);
			if(RiffToolbox.areEqual(value,0.0d)){
				indeterminatePoints.add(testPoint);
			}else if(RiffToolbox.isGreaterThan(value,0.0d)){
				leftPoints.add(testPoint);
			}else{
				rightPoints.add(testPoint);
			}
		}
		List[] array = new List[3];
		array[0] = leftPoints;
		array[1] = rightPoints;
		array[2] = indeterminatePoints;
		return array;
	}
	public static double testPointAgainstLine(RiffAbsolutePoint testPoint, RiffAbsolutePoint linePointA, RiffAbsolutePoint linePointB){
		return (testPoint.getY() - linePointA.getY())*(linePointB.getX() - linePointA.getX()) - (testPoint.getX() - linePointA.getX())*(linePointB.getY() - linePointA.getY());
	}
	public static List[] getPointSideList(RiffAbsolutePoint linePointA, RiffAbsolutePoint linePointB, RiffAbsolutePoint testPointA, RiffAbsolutePoint testPointB){
		List leftPoints = new LinkedList();
		List rightPoints = new LinkedList();
		List indeterminatePoints = new LinkedList();
		RiffAbsolutePoint testPoint = testPointA;
		double value = testPointAgainstLine(testPoint, linePointA, linePointB);
		if(RiffToolbox.areEqual(value,0.0d)){
			indeterminatePoints.add(testPoint);
		}else if(RiffToolbox.isGreaterThan(value,0.0d)){
			leftPoints.add(testPoint);
		}else{
			rightPoints.add(testPoint);
		}
		testPoint = testPointB;
		value = testPointAgainstLine(testPoint, linePointA, linePointB);
		if(RiffToolbox.areEqual(value,0.0d)){
			indeterminatePoints.add(testPoint);
		}else if(RiffToolbox.isGreaterThan(value,0.0d)){
			leftPoints.add(testPoint);
		}else{
			rightPoints.add(testPoint);
		}
		List[] array = new List[3];
		array[0] = leftPoints;
		array[1] = rightPoints;
		array[2] = indeterminatePoints;
		return array;
	}
	public static List[] getPointSideList(DiscreteRegion region, RiffAbsolutePoint testPoint){
		List leftPoints = new LinkedList();
		List rightPoints = new LinkedList();
		List indeterminatePoints = new LinkedList();
		List pointList = region.getPoints();
		for(int k=0;k<pointList.size();k++){
			RiffAbsolutePoint linePointA = (RiffAbsolutePoint)pointList.get(k);
			RiffAbsolutePoint linePointB = (RiffAbsolutePoint)pointList.get((k+1)%pointList.size());
			double value = testPointAgainstLine(testPoint, linePointA, linePointB);
			if(RiffToolbox.areEqual(value,0.0d)){
				indeterminatePoints.add(testPoint);
			}else if(RiffToolbox.isGreaterThan(value,0.0d)){
				leftPoints.add(testPoint);
			}else{
				rightPoints.add(testPoint);
			}
		}
		List[] array = new List[3];
		array[0] = leftPoints;
		array[1] = rightPoints;
		array[2] = indeterminatePoints;
		return array;
	}
}
