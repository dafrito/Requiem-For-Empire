public class TradeLinkException extends Exception{}
