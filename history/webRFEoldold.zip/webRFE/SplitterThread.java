import java.util.*;
import javax.swing.*;

public class SplitterThread extends Thread{
	private String m_statusText;
	private JPanel m_panel;
	private DiscreteRegionBSPNode m_root;
	private List m_regions;
	private boolean m_recurse;
	public SplitterThread(JPanel panel, DiscreteRegionBSPNode root, DiscreteRegion region, boolean recurse){
		super("Overlapping Splitter Pipeline");
		m_panel=panel;
		m_regions = new LinkedList();
		m_regions.add(region);
		m_root=root;
		m_recurse=recurse;
		m_statusText=new String();
	}
	public SplitterThread(JPanel panel, DiscreteRegionBSPNode root, List regions, boolean recurse){
		super("Overlapping Splitter Pipeline");
		m_panel=panel;
		m_regions=regions;
		m_root=root;
		m_recurse=recurse;
		m_statusText=new String();
	}
	public synchronized DiscreteRegionBSPNode getRoot(){return m_root;}
	public synchronized String getStatusText(){return m_statusText;}
	public synchronized void setStatusText(String text){m_statusText=text;}
	public void run(){
		setStatusText("Process started.");
		long time = System.currentTimeMillis();
		for(int i=0;i<m_regions.size();i++){
			DiscreteRegion region = (DiscreteRegion)m_regions.get(i);
			List regionPoints = region.getPoints();
			if(m_root==null){
				System.out.println("We're sorata here!");
				m_root = new DiscreteRegionBSPNode(regionPoints.get(0), regionPoints.get(1));
				m_root.addRegion(region);
				m_regions.remove(region);
				m_root.addToTempList(m_regions);
			}else{
				System.out.println("We're here!");
				m_root=RiffPolygonToolbox.removeOverlappingPolygons(m_root, region, m_recurse);
			}
			if(!m_recurse){break;}
		}
		time = System.currentTimeMillis() - time;
		setStatusText("Process complete. Time taken: " + ((double)time)/1000.0d + " seconds");
		System.gc();
		System.gc();
		m_panel.repaint();
	}
}
