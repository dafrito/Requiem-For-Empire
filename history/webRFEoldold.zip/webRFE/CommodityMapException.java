public class CommodityMapException extends Exception{}
