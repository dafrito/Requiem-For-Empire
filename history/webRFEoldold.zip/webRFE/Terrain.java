/*brush density
elevation
ground cohesiveness
temperature
water depth*/

public class Terrain extends Asset{
	private double m_brushDensity;
	private double m_elevation;
	private double m_groundCohesion;
	private double m_temperature;
	private double m_waterDepth;
	public static final String m_terrainAssetType = new String("Terrain");
	public Terrain(double brushDensity, double elevation, double temperature, double cohesion, double waterDepth){
		m_brushDensity=brushDensity;
		m_elevation=elevation;
		m_temperature=temperature;
		m_waterDepth=waterDepth;
		m_groundCohesion=cohesion;
	}
	public String getAssetType(){return Terrain.m_terrainAssetType;}
	public void iterate(int iterationTime){}
	public String toString(){
		String string = new String();
		string += "Terrain Asset: ";
		string += "\nElevation: " + m_elevation;
		string += "\nBrush Density: " + m_brushDensity;
		string += "\nTemperature: " + m_temperature;
		string += "\nGround Cohesion: " + m_groundCohesion;
		string += "\nWater Depth: " + m_waterDepth;
		return string;
	}
	public double getBrushDensity(){return m_brushDensity;}
	public void setBrushDensity(double brushDensity){m_brushDensity=brushDensity;}
	public double getElevation(){return m_elevation;}
	public void setElevation(double elevation){m_elevation=elevation;}
	public double getGroundCohesion(){return m_groundCohesion;}
	public void setGroundCohesion(double cohesion){m_groundCohesion=cohesion;}
	public double getTemperature(){return m_temperature;}
	public void setTemperature(double temp){m_temperature=temp;}
	public double getWaterDepth(){return m_waterDepth;}
	public void setWaterDepth(double waterDepth){m_waterDepth=waterDepth;}
}
