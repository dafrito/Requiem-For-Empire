import java.util.*;

public class LogMessageGroup{
	private List m_messages;
	private String m_header;
	public LogMessageGroup(String header){
		m_header = header;
		m_messages = new LinkedList();
	}
	public void addMessage(LogMessage message){
		m_messages.add(message);
	}
	public void addMessage(String message){
		m_messages.add(new LogMessage(message));
	}
	public String toString(){
		String string = new String();
		string += "\n----- " + m_header +  " -----\n";
		int q = string.length() -2;
		for(int i=0;i<m_messages.size();i++){
			string += ((LogMessage)m_messages.get(i)) + "\n";
		}
		string += "\n" + RiffToolbox.printLine("-", --q);
		return string;
	}
}
