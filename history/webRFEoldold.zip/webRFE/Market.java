import java.util.*;

public class Market{
	private Map m_goods;
	private CommodityMapNode m_commodityTree;
	public Market(){
		m_goods = new HashMap();
		m_commodityTree = new CommodityMapNode();
	}
	public void addLot(Lot lot) throws CommodityMapException{
		m_commodityTree.addLot(lot);
	}
	public List getLots(Brand brand) throws CommodityMapException{
		return m_commodityTree.getLotList(brand);
	}
	public Map getBrands(Commodity commodity){
		return m_commodityTree.getBrands(commodity);
	}
	public CommodityMapNode getCommodityNode(Commodity commodity){
		return m_commodityTree.getNode(commodity);
	}
	public String toString(){
		String string = new String();
		string += "Market";
		string += "Commodity Tree: " + m_commodityTree;
		return string;
	}
}
