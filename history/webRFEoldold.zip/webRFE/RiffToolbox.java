import java.lang.Math;
import java.util.Random;
import java.util.*;
import java.io.*;

public class RiffToolbox{
	public final static double DOUBLE_MIN = 1 * Math.pow(10, -10);
	private static Random m_random;
	private static boolean m_toggleDebugSpew;
	/******************************************************************************************/
	/************************ FILE I/0 ********************************************************/
	// Gets a single line from the provided stream. Returns null if at the end of the file.
	public static String getLineFromStream(FileReader stream){
		if(stream==null){return null;}
		String string = new String();
		try{
		while(true){
			int inputNum = stream.read();
			if(inputNum==-1){
				if(string.length()==0){
					return null;
				}else{
					return string;
				}
			}
			char inputChar = (char)inputNum;
			if(Character.isISOControl(inputChar)){
				if(inputChar=='\n'){
					RiffToolbox.printDebug("FileIO/getLineFromStream", "\"" + string + "\"");
					return string;
				}
				continue;
			}
			string += inputChar;
		}
		}catch(IOException e){
			System.out.println(e);
			return null;
		}
	}
	// Parses a file provided by the string and returns a list of DiscreteRegions. Null if file is invalid.
	public static List getDiscreteRegionsFromFile(String fileName){
		List regionList = new LinkedList();
		try{
			
			DiscreteRegion openRegion=null;
			FileReader reader = new FileReader(fileName);
			String string = RiffToolbox.getLineFromStream(reader);
			while(string != null){
				if(string.equals("DiscreteRegion")){
					if(openRegion!=null){regionList.add(openRegion);}
					openRegion = new DiscreteRegion();
				}else{
					String[] pointArray = string.split("\"");
					String name = null;
					if(pointArray.length==3){
						name = pointArray[1];
						string = pointArray[2];
					}
					pointArray = string.split(",");
					openRegion.addPoint(new RiffEuclideanPoint(name,null, Double.parseDouble(pointArray[0]), Double.parseDouble(pointArray[1]), Double.parseDouble(pointArray[2])));
				}
				string = RiffToolbox.getLineFromStream(reader);
			}
			if(openRegion!=null){regionList.add(openRegion);}
			RiffToolbox.printDebug("FileIO/getDiscreteRegionsFromFile", RiffToolbox.displayList(regionList));
			return regionList;
		}catch(IOException ex){
			System.out.println(ex);
			return regionList;
		}
	}
	// Creates a string containing text that is parseable into DiscreteRegions
	public static String getParseableDiscreteRegions(List list){
		String string = new String();
		for(int i=0;i<list.size();i++){
			string += getParseableDiscreteRegion((DiscreteRegion)list.get(i));
		}
		return string;
	}
	// Creates a string containing text that is parseable into a DiscreteRegion
	public static String getParseableDiscreteRegion(DiscreteRegion region){
		String string = new String("DiscreteRegion\n");
		List list = region.getPoints();
		for(int i=0;i<list.size();i++){
			RiffEuclideanPoint point = (RiffEuclideanPoint)list.get(i);
			string += "\"" + point.getName() + "\" " + point.getX() + "," + point.getY() + "," + point.getZ();
			string += "\n";
		}
		return string;
	}
	/******************************************************************************************/
	/************************ STRING FUNCTIONS ************************************************/
	// Prints a debug string.
	public synchronized static void printDebug(String category, Object string){
		if(!RiffToolbox.m_toggleDebugSpew){return;}
		String[] categoryArray = category.split("/");
		if(categoryArray.length>=2&&!categoryArray[1].equals("removeOverlappingPolygons")){return;}
		///if(categoryArray.length>=1&&!categoryArray[1].equals("removeOverlappingPolygons")){return;}
		//if(categoryArray.length>=2&&categoryArray[1].equals("DiscreteRegion")){System.out.println(string);return;}
		//if(categoryArray.length>=3&&categoryArray[2].equals("heavyDebug")){return;}
		System.out.println(string);
	}
	public static void toggleDebugSpew(){
		RiffToolbox.m_toggleDebugSpew = !RiffToolbox.m_toggleDebugSpew;
		if(RiffToolbox.m_toggleDebugSpew){
			System.out.println("Debug spew now displaying.");
		}else{
			System.out.println("Debug spew now not being displayed.");
		}
	}
	// Takes a list and returns a string containing its contents in a readable form.
	public static String displayList(Collection list, String singular, String plural){
		String string = new String();
		if(list==null||list.isEmpty()){
			string += "\nThis list is empty.";
			return string;
		}else if(list.size()==1){
			string += "\nThis list contains one " + singular;
		}else{
			string += "\nThis list contains " + list.size() + " " + plural;
		}
		Iterator iter = list.iterator();
		while(iter.hasNext()){
			string += "\n" + iter.next();
		}
		return string;
	}
	// Helper Function.
	public static String displayList(Collection list){return displayList(list, "item", "items");}
	// Helper Function.
	public static String displayList(Collection list, String singular){return displayList(list, singular, new String(singular + "s"));}
	// Takes a string and creates a new string with a underline beneath the string provided. The underline is formed by a string of the printChar the length of the baseString.
	public static String printUnderline(String baseString, String printChar){
		String string = new String(baseString + "\n");
		for(int i = baseString.length(); i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	// Prints a symbol n times.
	public static String printLine(String symbol, int times){
		String string = new String();
		for(int i=0;i<times;i++){
			string += symbol;
		}
		string += "\n";
		return string;
	}
	// Returns a string with a ASCII border around the baseString. The border consists of the character provided by printChar.
	public static String printBorder(String baseString, String printChar){
		String string = new String();
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n " + baseString + "\n";
		for(int i = baseString.length() + 2; i > 0; i--){
			string += printChar;
		}
		string += "\n";
		return string;
	}
	/******************************************************************************************/
	/************************ MATH FUNCTIONS **************************************************/
	// Converts degress to radians.
	public static double convertDegreesToRadians(double degrees){return degrees * Math.PI/180;}
	// 2-dimensional distance formula for RiffAbsolutePoints (Fallback distance formula when testing Sphere vs. Euclidean)
	public static double getDistance(RiffAbsolutePoint firstPoint, RiffAbsolutePoint secondPoint){
		return Math.sqrt(Math.pow(secondPoint.getX()-firstPoint.getX(), 2) + Math.pow(secondPoint.getY()-firstPoint.getY(),2));
	}
	// Helper function.
	public static double getDistance(RiffDataPoint firstPoint, RiffDataPoint secondPoint){
		return getDistance(firstPoint.getAbsolutePosition(), secondPoint.getAbsolutePosition());
	}
	// Spherical distance formula for RiffSpherePoints
	public static double getDistance(RiffSpherePoint firstPoint, RiffSpherePoint secondPoint){
		Planet planet = (Planet)firstPoint.getReferenceLocation();
		double firstLat = Math.toRadians(firstPoint.getLatitudeDegrees());
		double secondLat = Math.toRadians(secondPoint.getLatitudeDegrees());
		double firstLong = Math.toRadians(firstPoint.getLongitudeDegrees());
		double secondLong = Math.toRadians(secondPoint.getLongitudeDegrees());
		double temp = Math.pow(Math.sin((secondLat - firstLat)/2),2) + Math.cos(firstLat) * Math.cos(secondLat) * Math.pow(Math.sin((secondLong - firstLong)/2),2);
		return planet.getRadius() * 2 * Math.asin(Math.min(1, Math.sqrt(temp)));
	}
	// 3-dimensional distance formula for RiffEuclideanPoints
	public static double getDistance(RiffEuclideanPoint firstPoint, RiffEuclideanPoint secondPoint){
		//( (x-a)2 + (y - b)2 + (z - c)2 )1/2
		double testDouble = Math.sqrt(Math.pow((secondPoint.getX() - firstPoint.getX()), 2) + Math.pow((secondPoint.getY() - firstPoint.getY()), 2) + Math.pow((secondPoint.getZ() - firstPoint.getZ()), 2));
		return testDouble;
	}
	// Returns a static Random class.
	public static Random getRandom(){
		if(RiffToolbox.m_random == null){
			RiffToolbox.m_random = new Random();
		}
		return RiffToolbox.m_random;
	}
	public static boolean areEqual(double a, double b){
		return (Math.abs(a-b)<RiffToolbox.DOUBLE_MIN);
	}
	public static boolean isGreaterThan(double greater, double less){
		return (greater-less>RiffToolbox.DOUBLE_MIN);
	}
	public static boolean isLessThan(double less, double greater){
		return(less-greater<-RiffToolbox.DOUBLE_MIN);
	}
	public static boolean isGreaterThanOrEqualTo(double greater, double less){
		return(isGreaterThan(greater, less)||areEqual(greater,less));
	}
	public static boolean isLessThanOrEqualTo(double less, double greater){
		return(isLessThan(less, greater)||areEqual(less, greater));
	}
	/******************************************************************************************/
	/************************ RANDOM STUFF ****************************************************/
	// Predefined region generator.
	public static DiscreteRegion createRegion(DiscreteRegion region, int regionNum){
		switch(regionNum){
		case 0:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 288,78,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 263,46,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 196,100,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 239,79,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 264,72,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 263,96,0));
			return region;
		case 1:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 516,239,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 488,230,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 502,192,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 456,163,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 456,246,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 384,265,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 460,104,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 523,145,0));
			return region;
		case 2:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 50,50,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 75,75,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 100,100,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 125,125,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 150,150,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 250,50,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 225,50,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 150,125,0));
			region.addPoint(new RiffEuclideanPoint("I", null, 75,50,0));
			return region;
		case 3:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 300,158,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 328,73,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 226,140,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 346,219,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 445,110,0));
			return region;
		case 4:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 583,164,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 542,148,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 515,127,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 529,102,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 547,89,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 545,73,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 525,61,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 493,75,0));
			region.addPoint(new RiffEuclideanPoint("I", null, 471,97,0));
			region.addPoint(new RiffEuclideanPoint("J", null, 448,73,0));
			region.addPoint(new RiffEuclideanPoint("K", null, 508,43,0));
			region.addPoint(new RiffEuclideanPoint("L", null, 576,53,0));
			region.addPoint(new RiffEuclideanPoint("M", null, 608,125,0));
			return region;
		case 5:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 175,150,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 325,125,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 250,200,0));
			return region;
		case 6: 
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("D", null, 150,150,0));
			region.addPoint(new RiffEuclideanPoint("E", null, 375,5,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 200,200,0));
			return region;
		case 7:
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("A", null, 50,50,0));
			region.addPoint(new RiffEuclideanPoint("B", null, 150,50,0));
			region.addPoint(new RiffEuclideanPoint("C", null, 150,550,0));
			region.addPoint(new RiffEuclideanPoint("D", null, 50,550,0));
			return region;
		case 8: 
			region = new DiscreteRegion();
			region.addPoint(new RiffEuclideanPoint("E", null, 50,250,0));
			region.addPoint(new RiffEuclideanPoint("F", null, 150,50,0));
			region.addPoint(new RiffEuclideanPoint("G", null, 150,550,0));
			region.addPoint(new RiffEuclideanPoint("H", null, 50,550,0));
			return region;
		default:
			return null;
		}
	}
	// Prints out memory usage of the program.
	public static void determineMemoryUsage()
	{
		System.gc();
		long free = Runtime.getRuntime().freeMemory();
		long total = Runtime.getRuntime().totalMemory();
		long max = Runtime.getRuntime().maxMemory();
		RiffToolbox.printDebug("determineMemoryUsage", "Free memory in this chunk: " + (total-free));
		RiffToolbox.printDebug("determineMemoryUsage", "Total memory chunk size: " + total);
	    	RiffToolbox.printDebug("determineMemoryUsage", "Percentage used: " + 100*((double)total-(double)free)/(double)total);
		RiffToolbox.printDebug("determineMemoryUsage", "Maximum memory: " + max);
	}
}
