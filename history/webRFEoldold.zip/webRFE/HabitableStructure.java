/*public class HabitableStructure extends Structure{
	Population m_population;
	public HabitableStructure(Population population){
		m_population = population;
	}
	public void iterate(int iterationScale){
		super.iterate(iterationScale);
		m_population.iterate(iterationScale);
	}
}*/
