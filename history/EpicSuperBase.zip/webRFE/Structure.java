import java.util.*;

public class Structure extends Asset{
	protected AssetPoint m_location;
	private Personality m_manager;
	protected AssetMap m_inventory;
	private static final String m_structureTypeString = new String("Structure");
	public Structure(){
		super();
		m_inventory = new AssetMap();
	}
	public Structure(Organization owner, AssetPoint assetPoint, String formal, String adj, String shortName) throws CommodityMapException{	
		super(owner, formal, adj, shortName);
		m_inventory = new AssetMap();
		m_location = assetPoint;
		m_location.addAsset(this);
	}	
	public AssetMap getInventory(){return m_inventory;}
	public void addInventory(Lot lot) throws CommodityMapException{m_inventory.addAsset(lot);}
	public boolean assertInventoryLevel(Commodity comm, double quantity){
		List list = m_inventory.getCommodityMap().getNode(comm).getAllLots();
		for(int i=0;i<list.size();i++){
			quantity -= ((Lot)list.get(i)).getQuantity();
			if(quantity <= 0){return true;}
		}
		return false;
	}
	public AssetPoint getAssetPoint(){return m_location;}
	public AssetPoint getLocation(){ return m_location;}
	public void setLocation(RiffDataPoint point){
		m_location.getAbsolutePosition().setLocation(point);
	}
	public boolean expendInventoryLevel(Commodity comm, double quantity){
		double level = quantity;
		List list = m_inventory.getCommodityMap().getNode(comm).getAllLots();
		if(assertInventoryLevel(comm, quantity) == false){return false;}
		for(int i=0;i<list.size();i++){
			Lot lot = (Lot)list.get(i);
			if(lot.getQuantity() >= level){
				lot.setQuantity(lot.getQuantity() - level);
				return true;
			}
			level -= lot.getQuantity();
		}
		return false;
	}
	public Personality getManager(){return m_manager;}
	public boolean setManager(Personality manager){m_manager = manager;return true;}
	public String toString(){
		String string = new String();
		string += "Manager: " + m_manager + "\n";
		string += "Inventory:\n";
		string += m_inventory;
		return super.toString() + string;
	}
}
