public class CollectResourceAction extends Action{
	private static String m_actionName = new String("Collect Resource");
	public String toString(){return m_actionName;}
	public void execute(Order superOrder){
		CollectResourceOrder order = (CollectResourceOrder)superOrder;
		double resource = order.getResourcePoint().getSlice(order.getIterationTime());
		Lot lot = order.getResourcePoint().getLot(resource * order.getOrganization().getProficiency(this, order.getResourcePoint().getCommodity()));
		lot.setDeFactoOwner(order.getOrganization());
		try{
			order.getOrganization().addAsset(lot);
		}catch(CommodityMapException ex){
			order.setException(ex);
		}
	}
}
