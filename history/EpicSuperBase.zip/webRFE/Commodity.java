import java.util.*;

public class Commodity extends UniqueObject{
	private Map m_prerequisites; // Commodity name, PrerequisiteLevel
	private final String m_name;
	private List m_parents; // list of CommodityConversionEfficiency's
	public Commodity(String name){
		m_name = name;
		m_prerequisites = new HashMap();
		m_parents = new Vector();
		RiffCommodities.addCommodity(this);
	}
	public String getName(){return m_name;}
	public List getAllPrerequisiteLevels(){return new LinkedList(m_prerequisites.values());}
	public PrerequisiteLevel getPrerequisiteLevel(String preString){return (PrerequisiteLevel)m_prerequisites.get(preString);}
	public void addPrerequisiteLevel(Commodity prereq, double quantity){
		m_prerequisites.put(prereq.getName(), new PrerequisiteLevel(prereq, quantity));
	}
	public void addPrerequisiteLevel(String prereq, double quantity){
		addPrerequisiteLevel(RiffCommodities.getCommodity(prereq), quantity);
	}
	public boolean hasParents(){if(m_parents == null || m_parents.size()==0){return false;}return true;}
	public void addParent(Commodity parent, double proficiency){m_parents.add(new CommodityConversionEfficiency(parent, proficiency));}
	public List getParentEfficiencies(){return m_parents;}
	public List getParentCommodities(){
		List list = new LinkedList();
		for(int i=0;i<m_parents.size();i++){
			list.add(((CommodityConversionEfficiency)m_parents.get(i)).getCommodity());
		}
		return list;
	}
	public int hashCode(){return m_name.hashCode();}
	public String toString(){
		String string = new String();
		string += "Commodity: " + m_name + "\n";
		string += "Prerequisites: ";
		Iterator iter = m_prerequisites.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			string += "\n" + ((PrerequisiteLevel)entry.getValue());
		}
		return string;
	}
}
