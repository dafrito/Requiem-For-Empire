import java.util.*;

public class ProductionAction extends Action{
	public static String m_actionName = new String("Production Action");
	public String toString(){return m_actionName;}
	public void execute(Order superOrder){
		QuantityProductionOrder order = (QuantityProductionOrder)superOrder;
		List list = order.getCommodity().getAllPrerequisiteLevels();
		List totalList = new LinkedList();
		double maxQuantity = order.getRemainingQuantity();
		double quantity=0;
		for(int i=0;i<list.size();i++){
			PrerequisiteLevel level = (PrerequisiteLevel)list.get(i);
			List commList;
			if(maxQuantity == -1){
				commList = order.getActiveAsset().getAssetsList(level.getCommodity());
			}else{
				commList = order.getActiveAsset().getAssetsList(level.getCommodity(), level.getQuantity() * maxQuantity);
			}
			if(commList==null){
				return;
			}
			totalList.addAll(commList);
			
			for(int j=0;j<commList.size();j++){
				quantity += ((Lot)commList.get(i)).getQuantity();
			}
			if(maxQuantity == -1){
				maxQuantity = quantity/level.getQuantity();
			}else{
				if(quantity/(level.getQuantity() * maxQuantity) != 1){
					maxQuantity *= quantity/(level.getQuantity() * maxQuantity);
				}
			}
		}
		
		if(order.getTotalQuantity() != -1 && maxQuantity != order.getRemainingQuantity()){
				totalList = new LinkedList();
				for(int i=0;i<list.size();i++){
				PrerequisiteLevel level = (PrerequisiteLevel)list.get(i);
				List commList = order.getActiveAsset().getAssetsList(level.getCommodity(), level.getQuantity() * maxQuantity);
				if(commList==null){return;}
				totalList.addAll(commList);
				for(int j=0;j<commList.size();j++){
					quantity += ((Lot)commList.get(i)).getQuantity();
				}
				if(quantity/(level.getQuantity() * maxQuantity) != 1){
					maxQuantity *= quantity/(level.getQuantity() * maxQuantity);
				}
			}
		}
		order.getActiveAsset().removeAssets(totalList);
		try{
			order.getActiveAsset().addAsset(new Lot(order.getBrand(), 1, maxQuantity));
		}catch(CommodityMapException ex){
			order.setException(new FailedActionException(ex));
		}
	}
}
