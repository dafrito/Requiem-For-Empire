public class AssetPoint extends RiffDataPoint{
	private Asset m_asset;
	public AssetPoint(RiffDataPoint point, Planet planet, Asset asset){
		super(point, planet);
		m_asset=asset;
		planet.addAssetPoint(this);
	}
	public Asset getAsset(){return m_asset;}
	public void setAsset(Asset asset){m_asset=asset;}
	public void iterate(int iterationTime){}
	public String toString(){
		String string = new String();
		string += "AssetPoint:";
		string += "\nAbsolute position: " + getAbsolutePosition(); 
		string += "\nAsset: " + m_asset;
		return string;
	}
}
