public class Lot extends Asset{
	private Brand m_brand;
	private double m_quality;
	private double m_quantity;
	private static final String m_lotAssetType = new String("Lot");
	public Lot(String brandName, double quality, double quantity){
		this(RiffBrands.getBrand(brandName), quality, quantity);
	}
	public Lot(Brand brand, double quality, double quantity){
		m_brand = brand;
		m_quality = quality;
		m_quantity = quantity;
	}
	public Lot(Lot otherLot){
		this(otherLot.getBrand(), otherLot.getQuality(), otherLot.getQuantity());
	}
	public Asset cloneAsset(){return new Lot(this);}
	public boolean mergeAsset(Asset asset){
		if(!asset.getAssetType().equals("Lot")){return false;}
		Lot lot = (Lot)asset;
		if(!lot.getBrand().equals(getBrand())){return false;}
		double grossQuality = m_quantity * m_quality;
		double lotQuality = lot.getQuality() * lot.getQuantity();
		m_quantity = m_quantity + lot.getQuantity();
		m_quality = (grossQuality + lotQuality) / m_quantity;
		return true;
	}
	public String getAssetType(){return m_lotAssetType;}
	public double getQuality(){return m_quality;}
	public double getQuantity(){return m_quantity;}
	public boolean setQuantity(double quantity){m_quantity = quantity;return true;}
	public Commodity getCommodity(){return m_brand.getCommodity();}
	public Brand getBrand(){return m_brand;}
	public void iterate(int iterationTime){}
	public String toString(){
		String string = new String();      
		string += "\n" + RiffToolbox.printUnderline("Lot of " + m_brand.getName(), "-");
		string += "Commodity: " + m_brand.getCommodity().getName() + "\n";
		string += "Quality: " + m_quality + " | Quantity: " + m_quantity;
		return string;
	}
}
