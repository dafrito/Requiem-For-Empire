import java.util.*;

public class RiffCommodities{
	private static Map m_commodityMap = new HashMap(); // Commodity-name, Commodity
	public static void addCommodity(Commodity commodity){
		RiffCommodities.m_commodityMap.put(commodity.getName(), commodity);
	}
	public static Commodity getCommodity(String commodityName){
		return (Commodity)RiffCommodities.m_commodityMap.get(commodityName);
	}
}
