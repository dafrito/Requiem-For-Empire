import java.util.*;

public abstract class ActiveAsset extends Asset{
	public abstract void iterate(int iterationTime);
	private static final String m_ActiveAssetString = "Active Asset";
	protected AssetMap m_assetMap = new AssetMap();
	public ActiveAsset(){
		super();
	}
	public String getAssetType(){return ActiveAsset.m_ActiveAssetString;}
	public String toString(){
		String string = new String();
		string += "Active Asset: ";
		return string;
	}
}
