import java.util.*;

public class Population{
	private Map m_identities;
	private int m_size;
	private Map m_consumptionLevels;
	private HabitableStructure m_housing;
	public Population(){
		m_identities = new HashMap();
		m_consumptionLevels = new HashMap();
	}
	public Population(int size){
		m_size = size;
		m_identities = new HashMap();
		m_consumptionLevels = new HashMap();
	}
	public Map getIdentities(){return m_identities;}
	public Map getConsumptionLevels(){return m_consumptionLevels;}
	public int getSize(){return m_size;}
	public HabitableStructure getHousing(){return m_housing;}
	public boolean setHousing(HabitableStructure housing){m_housing = housing; return true;}
	public boolean addIdentity(Identity ident, Integer loyalty){m_identities.put(ident, loyalty);return true;}
	public Integer getLoyalty(Identity identity){return (Integer)m_identities.get(identity);}
	public Integer getConsumptionLevel(Brand comm){return (Integer)m_consumptionLevels.get(comm);}
	public boolean addConsumptionLevel(Brand comm, Integer level){m_consumptionLevels.put(comm, level);return true;}
	public boolean iterate(int iterationTime){
		return true;
	}
	public String toString(){
		String string = new String();
		string += "Population of " + m_size + " people\n";
		return string;
	}
}
