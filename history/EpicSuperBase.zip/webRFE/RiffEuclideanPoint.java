public class RiffEuclideanPoint extends RiffAbsolutePoint{
	private double m_x, m_y, m_z;
	private static int m_pointNum=0;
	public RiffEuclideanPoint(double x, double y, double z){
		this(null, null, x,y,z);
	}
	public RiffEuclideanPoint(Location referenceLocation, double x, double y, double z){
		this(null, referenceLocation,x,y,z);
	}
	public RiffEuclideanPoint(String name, Location referenceLocation, double x, double y, double z){
		super(null, referenceLocation);
		m_pointName = "P" + m_pointNum;
		m_pointNum++;
		m_x=x;
		m_y=y;
		m_z=z;
	}
	public void duplicate(RiffEuclideanPoint point){
		m_x=point.getX();
		m_y=point.getY();
		m_z=point.getZ();
		m_pointName = point.getName();
	}
	public boolean equals(Object o){
		RiffEuclideanPoint testPoint = (RiffEuclideanPoint)((RiffDataPoint)o).getAbsolutePosition();
		if(RiffToolbox.areEqual(m_x,testPoint.getX())&&RiffToolbox.areEqual(m_y,testPoint.getY())&&RiffToolbox.areEqual(m_z,testPoint.getZ())){
			if(m_referenceLocation!=null){
				if(testPoint.getReferenceLocation()==null){return false;}
				return m_referenceLocation.equals(((RiffAbsolutePoint)o).getReferenceLocation());
			}else{
				if(testPoint.getReferenceLocation()==null){return true;}
				return false;
			}
		}
		return false;
	}
	public int compareTo(Object o){
		RiffEuclideanPoint testPoint = (RiffEuclideanPoint)((RiffDataPoint)o).getAbsolutePosition();
		if(m_x>testPoint.getX()){return 1;}
		if(m_x<testPoint.getX()){return -1;}
		if(m_y>testPoint.getY()){return 1;}
		if(m_y<testPoint.getY()){return -1;}
		if(m_z>testPoint.getZ()){return 1;}
		if(m_z<testPoint.getZ()){return -1;}
		return 0;
	}
	public void setX(double x){m_x=x;}
	public void setY(double y){m_y=y;}
	public void setZ(double z){m_z=z;}
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public String toString(){
		String string = new String();
		if(m_pointName!=null&&m_pointName.length()>0){string += m_pointName;}
		string += "(" + m_x;
		string += ", " + m_y;
		string += ", " + m_z + ")";
		return string;
	}
}
