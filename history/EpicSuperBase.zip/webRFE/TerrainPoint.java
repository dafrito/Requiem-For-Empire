import java.util.*;

public class TerrainPoint extends AssetPoint{
	public TerrainPoint(RiffSurface point, Planet planet, Terrain asset){
		super(point, planet, asset);
	}
	public List getPolygons(double precision){return ((RiffSurface)m_point).getPolygons(precision);}
}
