import javax.swing.*; // For JPanel, etc.
import java.awt.*;           // For Graphics, etc.
import java.awt.geom.*;      // For Ellipse2D, etc.
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import javax.swing.JOptionPane;
import java.lang.Math;
import java.io.*;

public class RiffDeveloper extends JPanel implements KeyListener, MouseListener{
	public RiffDeveloper(){
		setFocusable(true);
		addKeyListener(this);
		addMouseListener(this);
	}
	public void paintComponent(Graphics g){
		clear(g);
	}
	public void mouseClicked(MouseEvent e){}
	public void mousePressed(MouseEvent e){}
	public void mouseReleased(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void keyTyped(KeyEvent keyEvent){}
	public void keyReleased(KeyEvent keyEvent){}
	public void keyPressed(KeyEvent keyEvent){}
	protected void clear(Graphics g){super.paintComponent(g);}
  	public static void main(String[] args) {
	 	JFrame frame = new JFrame("Requiem for Empire - Developer");
	 	frame.setSize(1024, 768);
		frame.setContentPane(new RiffDeveloper());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
