public class LocationType implements Comparable{
	private String m_locationType;
	private final int m_locationTypeDisplay;
	public LocationType(int locationTypeDisplay, String locationTypeName){
		m_locationTypeDisplay = locationTypeDisplay;
		m_locationType = locationTypeName;
	}
	public boolean setName(String newName){m_locationType = newName; return true;}
	public String getName(){return m_locationType;}
	public String formatString(Location location){
		switch(m_locationTypeDisplay){
			case LocationTypeDisplay.LOCATIONTYPE_DONOTDISPLAY:
			return location.getName();
			case LocationTypeDisplay.LOCATIONTYPE_DISPLAYASPREFIX:
			return m_locationType + " " + location.getAdjective();
			case LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX:
			return location.getAdjective() + " " + m_locationType;
			case LocationTypeDisplay.LOCATIONTYPE_DISPLAYPREFIXNAME:
			return m_locationType + " " + location.getName();
			default:
			return location.getName();
		}
	}
	public int compareTo(Object otherLocationType){
		return m_locationType.compareTo(((LocationType)otherLocationType).getName());
	}
	public boolean equals(Object otherLocationType){
		if(compareTo(otherLocationType) != 0){
			return false;
		}
		return true;
	}
}