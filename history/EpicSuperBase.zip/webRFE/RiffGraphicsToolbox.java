import java.awt.Polygon;
import java.awt.geom.Line2D.Double;
import java.awt.Point;
import java.util.*;
import java.awt.Color;
import javax.swing.*;

public class RiffGraphicsToolbox{
	// Creates a Java-displayable polygon from the discreteRegion
	public static Polygon getPolygonFromDiscreteRegion(JPanel panel, DiscreteRegion region){
		Polygon poly = new Polygon();
		List pointList = region.getPoints();
		for(int i=0;i<pointList.size();i++){
			poly.addPoint((int)((RiffAbsolutePoint)pointList.get(i)).getX(),panel.getHeight()-(int)((RiffAbsolutePoint)pointList.get(i)).getY());
		}
		return poly;
	}
	// Converts a Java-point to a RiffPoint
	public static RiffAbsolutePoint convertPointToEuclidean(Point point){
		return new RiffEuclideanPoint(null, point.getX(), point.getY(),0);
	}
	public static Color getDiscreteRegionColor(DiscreteRegion region){
		Iterator iter = region.getAssets().iterator();
		while(iter.hasNext()){
			Asset asset = (Asset)iter.next();
			if(asset.getAssetType().equals("Terrain")){
				Terrain terrain = (Terrain)asset;
				return new Color(0.8f- .7f*(float)terrain.getBrushDensity(), 1.0f, 0.0f);
			}
		}
		return Color.BLUE;
	}
	public static java.awt.geom.Line2D.Double getLineFromPoints(RiffAbsolutePoint pointA, RiffAbsolutePoint pointB){
		return new java.awt.geom.Line2D.Double(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY());
	}
	// Creates a list of lines from the discreteRegion
	public static List getLineListFromDiscreteRegion(DiscreteRegion region){
		List list = new LinkedList();
		for(int i=0;i<region.getPoints().size();i++){
			RiffAbsolutePoint pointA = (RiffAbsolutePoint)region.getPoints().get(i);
			RiffAbsolutePoint pointB = (RiffAbsolutePoint)region.getPoints().get((i+1)%region.getPoints().size());
			list.add(new java.awt.geom.Line2D.Double(pointA.getX(), pointA.getY(), pointB.getX(), pointB.getY()));
		}
		return list;
	}
}
