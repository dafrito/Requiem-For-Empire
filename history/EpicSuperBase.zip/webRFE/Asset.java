import java.util.*;

public abstract class Asset extends UniqueObject implements Comparable{
	protected static final String m_genericAssetType = new String("Asset");
	public String getAssetType(){return Asset.m_genericAssetType;}
	public abstract void iterate(int iterationTime);
	public abstract String toString();
	public abstract boolean mergeAsset(Asset asset);
	public abstract Asset cloneAsset();
	public abstract boolean isUnique();
	public boolean equals(Object obj){
		return (getAssetType() == ((Asset)obj).getAssetType());
	}
	public int compareTo(Object obj){
		return getAssetType().compareTo(((Asset)obj).getAssetType());
	}
}
