public class InvalidScenarioDateRangeException extends Exception{
	private Scenario m_scenario;
	public InvalidScenarioDateRangeException(Scenario scenario){
		m_scenario = scenario;
	}
	public String toString(){
		String string = new String("The following scenario's date range is invalid:\n" + m_scenario);
		return string;
	}
}
