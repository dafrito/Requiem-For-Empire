public abstract class Order{
	protected Exception m_exception;
	public void setException(Exception ex){m_exception = ex;}
	public abstract void execute(int iterationTime) throws OrderException;
	public abstract int getRemainingTime();
	public abstract OrderStatus getStatus();
	public abstract String toString();
}
