import java.util.*;

public class Location extends RiffDataPoint implements Comparable{
	public static final LocationType GALAXY = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX, "Galaxy");
	public static final LocationType CLUSTER = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX, "Cluster");
	public static final LocationType SYSTEM = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYASSUFFIX, "System");
	public static final LocationType PLANET = new LocationType(LocationTypeDisplay.LOCATIONTYPE_DISPLAYPREFIXNAME, "Planet");
	protected String m_name, m_adjective;
	protected LocationType m_locationType;
	protected Map m_children;
	protected Location m_lastChildAdded;
	public Location(LocationType locationType, String name, String adjective, Location absoluteParent, RiffDataPoint offsetPoint, boolean canHaveChildren) throws OverwriteException{
		super(offsetPoint, absoluteParent);
		m_locationType = locationType;
		m_name = name;
		m_adjective = adjective;
		if(canHaveChildren){m_children = new HashMap();}
		if(m_referenceLocation != null){
			m_referenceLocation.addChild(this);
		}
	}
	public String getName(){return m_name;}
	public void setName(String name) throws OverwritingNameChangeException{
		if(m_referenceLocation == null){m_name=name;return;}
		m_referenceLocation.changeName(this.getName(), name);
		m_name = name;
	}
	public void changeName(String oldName, String newName) throws OverwritingNameChangeException{
		if(m_children == null){return;}
		if(m_children.get(newName) != null){throw new OverwritingNameChangeException(this, newName, oldName);}
		m_children.put(newName, m_children.get(oldName));
	}
	public String getFormalName(){return m_locationType.formatString(this);}
	public boolean setAdjective(String adj){m_adjective = adj;return true;}
	public String getAdjective(){return m_adjective;}
	public LocationType getLocationType(){return m_locationType;}
	public int compareTo(Object obj){
		try{
			if(((Location)obj).getReferenceLocation().equals(m_referenceLocation) == false){
				throw(new RiffDifferentParentException(m_referenceLocation, ((Location)obj).getReferenceLocation()));
			}
			return getAbsolutePosition().compareTo(((Location)obj).getAbsolutePosition());
		}catch(LocationException e){
			System.out.println(e);
		}
		return 0;
	}
	public boolean equals(Object obj){
		if(compareTo(obj) == 0){return true;}
		return false;
	}
	public String toString(){
		String string = new String("\n");
		string += super.toString();
		string += "\nFormal Name: " + getFormalName();
		string += "\nName: " + m_name;
		string += "\nAdjective: " + m_adjective;
		
		if(m_children != null){
			if(!m_children.isEmpty()){
				string += "\nChild locations of this location:";
				string += "Children of " + m_locationType.formatString(this) + ":\n";
				Iterator iterator = m_children.entrySet().iterator();
				while(iterator.hasNext()){
					Map.Entry entry = (Map.Entry)iterator.next();
					string += (Location)entry.getValue();
				}
			}
			else{
				string += "\nThis location has no child locations.";
			}
		}else{string += "\nThis location can have no child locations.";}
		return string;
	}
	public Location getLastChild(){return m_lastChildAdded;}
	public Location getChild(String childName){
		if(m_name.equals(childName)){
			return this;
		}
		if(m_children == null || m_children.size() == 0){return null;}
		if(m_children.get(childName) != null){return (Location)m_children.get(childName);}
		Iterator iter = m_children.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry)iter.next();
			Location location = ((Location)entry.getValue()).getChild(childName);
			if(location != null){return location;}
		}
		return null;
	}
	public Location getChild(String childName, LocationType locationType){
		if(m_name.equals(childName) && locationType.equals(m_locationType)){
			return this;
		}
		if(m_children == null || m_children.size() == 0){return null;}
		if(m_children.get(childName) != null && ((Location)m_children.get(childName)).getLocationType().equals(locationType)){
			return (Location)m_children.get(childName);
		}
		
		Iterator iterator = m_children.entrySet().iterator();
		while(iterator.hasNext()){
			Map.Entry entry = (Map.Entry)iterator.next();
			Location location = ((Location)entry.getValue()).getChild(childName, locationType);
			if(location != null){return location;}
		}
		return null;
	}
	public boolean addChild(Location child) throws OverwriteException{
		if(m_children != null){
			if(m_children.get(child.getName()) != null){throw new OverwriteException(this, m_children.get(child.getName()), child);}
			m_children.put(child.getName(), child);
			child.setReferenceLocation(this);
			m_lastChildAdded = child;
			return true;
		}
		return false;
	}
	public boolean iterate(int iterationTime){
		if(m_children == null){return true;}
		Iterator iterator = m_children.entrySet().iterator();
		while(iterator.hasNext()){
			Map.Entry entry = (Map.Entry)iterator.next();
			if(((Location)entry.getValue()).iterate(iterationTime)==false){return false;}
		}
		return true;
	}
}
