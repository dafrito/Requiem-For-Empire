import java.lang.Math;

public class MoveAction extends Action{
	private static String m_actionName = new String("MoveAction");
	public String toString(){return m_actionName;}
	public boolean execute(Order superOrder, int iterationTime){
		MoveOrder order = (MoveOrder)superOrder;
		if( order.getTradeLink().getDistance() - order.getOffsetDistance() >= order.getMobileStructure().getVelocity(iterationTime) * iterationTime){
			order.setOffsetDistance(order.getTradeLink().getDistance() - order.getMobileStructure().getVelocity(iterationTime) * iterationTime);
			order.getMobileStructure().expendFuel(iterationTime);
			return false;
		}else{
			double overage = order.getTradeLink().getDistance() - order.getOffsetDistance() - order.getMobileStructure().getVelocity(iterationTime) * iterationTime * -1;
			double time = order.getMobileStructure().getVelocity(iterationTime) / overage;
			order.getMobileStructure().expendFuel(iterationTime - time);
			order.getMobileStructure().getLocation().getAbsolutePosition().setLocation(order.getTradeLink().getDestination());
			return true;
		}
	}
}
