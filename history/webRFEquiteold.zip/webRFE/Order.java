public abstract class Order{
	protected Organization m_organization;
	public Order(Organization organization){
		m_organization = organization;
	}
	public Organization getOrganization(){return m_organization;}
	public abstract boolean execute(int iterationTime);
	public abstract String toString();
}
