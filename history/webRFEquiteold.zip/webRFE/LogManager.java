import java.util.*;

public class LogManager{
	private static List m_messages = new LinkedList();
	private static LogMessageGroup m_currentGroup;
	public static void openGroup(String header){
		LogManager.openGroup(new LogMessageGroup(header));
	}
	public static void openGroup(LogMessageGroup messageGroup){
		LogManager.m_currentGroup = messageGroup;
		m_messages.add(LogManager.m_currentGroup);
	}
	public static void closeGroup(){m_currentGroup = null;}
	public static void writeDebug(String string){
		LogManager.writeLog(string);
	}
	public static void writeDebug(Object creator, String string){
		LogManager.writeLog(creator, string);
	}
	public static void writeLog(LogMessage logMessage){
		if(m_currentGroup == null){
			m_messages.add(logMessage);
			return;
		}
		LogManager.m_currentGroup.addMessage(logMessage);
	}
	public static void writeLog(String string){
		LogManager.writeLog(new LogMessage(string));
	}
	public static void writeLog(Object creator, String string){
		LogManager.writeLog(new LogMessage(creator, string));
	}
	public static void writeLog(String creatorName, String string){
		LogManager.writeLog(new LogMessage(creatorName, string));
	}
	public static void printMessages(){
		String string = new String();
		for(int i=0;i<LogManager.m_messages.size();i++){
			string += LogManager.m_messages.get(i);
		}
		System.out.println(string);
	}
}
