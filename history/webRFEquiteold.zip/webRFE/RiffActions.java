import java.util.*;

public class RiffActions{
	private static Map m_actions = new HashMap(); // String ActionName, Action
	public static Action getAction(String actionName){
		return (Action)RiffActions.m_actions.get(actionName);
	}
	public static void addAction(Action action){
		RiffActions.m_actions.put(action.toString(), action);
	}
}
