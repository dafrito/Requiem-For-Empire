public class MoveOrder extends Order{
	private RiffDataPoint m_source, m_destination;
	private double m_offsetPercentage, m_offsetDistance;
	private MobileStructure m_structure;
	private TradeLink m_tradeLink;
	public MoveOrder(Organization org, RiffDataPoint source, RiffDataPoint dest){
		super(org);
		m_source = source;
		m_destination = dest;
	}
	public MobileStructure getMobileStructure(){return m_structure;}
	public TradeLink getTradeLink(){return m_tradeLink;}
	public double getOffsetDistance(){return m_offsetDistance;}
	public void setOffsetDistance(double distance){
		double percentage = distance / m_tradeLink.getDistance();
		((RiffSpherePoint)m_structure.getLocation().getAbsolutePosition()).setPosition(((RiffSpherePoint)m_source.getAbsolutePosition()).getLatitudeDegrees() + percentage * (((RiffSpherePoint)m_destination.getAbsolutePosition()).getLatitudeDegrees() - ((RiffSpherePoint)m_source.getAbsolutePosition()).getLatitudeDegrees()),((RiffSpherePoint)m_source.getAbsolutePosition()).getLongitudeDegrees() + percentage * (((RiffSpherePoint)m_destination.getAbsolutePosition()).getLongitudeDegrees() - ((RiffSpherePoint)m_source.getAbsolutePosition()).getLongitudeDegrees()));
		m_offsetDistance = distance;
		m_offsetPercentage = percentage;
	}
	public void setLocation(RiffDataPoint point){
		m_structure.setLocation(point);
	}
	public boolean execute(int iterationTime){
		return true;
	}
	public String toString(){
		return new String("MoveOrder");
	}
}
