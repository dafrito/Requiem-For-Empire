public class HabitableStructure extends Structure{
	Population m_population;
	public HabitableStructure(Population population){
		m_population = population;
	}
	public boolean iterate(int iterationScale){
		if(super.iterate(iterationScale) == false){return false;}
		if(m_population.iterate(iterationScale) == false){return false;}
		return true;
	}
}
