public class MobileStructure extends Structure{
	public MobileStructure(Organization owner, AssetPoint assetPoint, String formal, String adj, String shortName){	
	
	}
	public void expendFuel(double time){
		
	}
	public double getVelocity(double time){
		return 1.0f;
	}
	public void setPosition(double lat, double longit){
		((RiffSpherePoint)m_location.getAbsolutePosition()).setPosition(lat, longit);
	}
}
