public class OverwriteException extends Exception{
	private Object m_parent;
	private Object m_foundChild;
	private Object m_newChild;
	public OverwriteException(Object parent, Object foundChild, Object newChild){
		m_parent = parent;
		m_foundChild = foundChild;
		m_newChild = newChild;
	}
	public String getMessage(){
		String string = new String();
		string += "During an addChild operation to a map, a value was found for the key that was to be added.\n";
		string += "Parent:\n" + m_parent;
		string += "\nChild that was found:\n" + m_foundChild;
		string += "\nChild that was to be added:\n" + m_newChild;
		return string;
	}
}
