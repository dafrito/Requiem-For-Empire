public class CommodityMapAddLotToRootException extends CommodityMapException{
	private CommodityMapNode m_node;
	private Lot m_lot;
	public CommodityMapAddLotToRootException(CommodityMapNode node, Lot lot){
		m_node = node;
		m_lot = lot;
	}
	public String getMessage(){
		String string = new String();
		string += "A lot was trying to be added to the root node of the commodity map.";
		string += "\nOffending node:\n" + m_node;
		string += "\nOffending lot:\n" + m_lot;
		return string;
	}
}
