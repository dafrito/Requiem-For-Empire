public class Point3d extends RiffAbsolutePoint implements Comparable{
	private double m_x;
	private double m_y;
	private double m_z;
	public Point3d(RiffDataPoint point, Location referenceLocation){
		super(point,referenceLocation);
	}
	public Point3d(double x,double y,double z){
		m_x = x;
		m_y = y;
		m_z = z;
	}
	public int compareTo(Object obj){
		Point3d point = (Point3d)((RiffDataPoint)obj).getAbsolutePosition();
		if(point.getX() != getX()){
			return RiffToolbox.compareDoubles(getX(), point.getX());
		}
		if(point.getY() != getY()){
			return RiffToolbox.compareDoubles(getY(), point.getY());
		}
		if(point.getZ() != getZ()){
			return RiffToolbox.compareDoubles(getZ(), point.getZ());
		}
		return 0;
	}
	public boolean equals(Object obj){
		if(compareTo((RiffDataPoint)obj) == 0){
			return true;
		}
		return false;
	}
	public double getX(){return m_x;}
	public double getY(){return m_y;}
	public double getZ(){return m_z;}
	public boolean setX(double x){m_x = x; return true;}
	public boolean setY(double y){m_y = y; return true;}
	public boolean setZ(double z){m_z = z; return true;}
	public RiffAbsolutePoint getAbsolutePosition(){return this;}
	public void setLocation(RiffDataPoint point){
		m_x = ((Point3d)point.getAbsolutePosition()).getX();
		m_y = ((Point3d)point.getAbsolutePosition()).getY();
		m_z = ((Point3d)point.getAbsolutePosition()).getZ();
	}
	public boolean translate(double x, double y, double z){
		m_x += x;
		m_y += y;
		m_z += z;
		return true;
	}
	public boolean translate(RiffDataPoint translatePoint){
		Point3d point = (Point3d)translatePoint.getAbsolutePosition();
		return translate(point.getX(), point.getY(), point.getZ());
	}
	public Object clone(){return new Point3d(m_x, m_y, m_z);}
	public String toString(){
		return new String("(" + m_x + ", " + m_y + ", " + m_z + ")");
	}
}
